/*
  Copyright (C) 2005 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugins/PluginQuote/Quote.cpp,v 1.1.1.1 2005/07/10 18:51:06 rainy Exp $

  $Log: Quote.cpp,v $
  Revision 1.1.1.1  2005/07/10 18:51:06  rainy
  no message

*/

#pragma warning(disable: 4786)
#pragma warning(disable: 4996)

#include <windows.h>
#include <math.h>
#include <string>
#include <map>
#include <vector>
#include <time.h>
#include "..\..\Library\Export.h"	// Rainmeter's exported functions

/* The exported functions */
extern "C"
{
__declspec( dllexport ) UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id);
__declspec( dllexport ) void Finalize(HMODULE instance, UINT id);
__declspec( dllexport ) double Update2(UINT id);
__declspec( dllexport ) LPCTSTR GetString(UINT id, UINT flags);
__declspec( dllexport ) UINT GetPluginVersion();
__declspec( dllexport ) LPCTSTR GetPluginAuthor();
}

struct quoteData
{
	std::wstring pathname;
	std::wstring separator;
	bool pathnameIsFile;
	std::wstring value;
};

static std::map<UINT, quoteData> g_Values;

std::string ConvertToAscii(LPCTSTR str)
{
	std::string szAscii;

	if (str)
	{
		size_t len = (wcslen(str) + 1);
		char* tmpSz = new char[len * 2];
		WideCharToMultiByte(CP_ACP, 0, str, -1, tmpSz, (int)len * 2, NULL, FALSE);
		szAscii = tmpSz;
		delete tmpSz;
	}
	return szAscii;
}

std::wstring ConvertToWide(LPCSTR str)
{
	std::wstring szWide;

	if (str)
	{
		size_t len = strlen(str) + 1;
		WCHAR* wideSz = new WCHAR[len * 2];
		MultiByteToWideChar(CP_ACP, 0, str, (int)len, wideSz, (int)len * 2);
		szWide = wideSz;
		delete wideSz;
	}
	return szWide;
}

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	quoteData qData;
	qData.pathnameIsFile = true;

	/* Read our own settings from the ini-file */
	LPCTSTR data = ReadConfigString(section, L"PathName", L"0");
	if (data)
	{
		qData.pathname = data;

		if (qData.pathname.find(':') == -1)		// Not found
		{
			std::wstring path = iniFile;
			size_t pos = path.rfind('\\');
			if (pos >= 0)
			{
				path.erase(pos + 1);
				qData.pathname = path + qData.pathname;
			}
		}

		if (!qData.pathname.empty() && qData.pathname[qData.pathname.size() -1] == L'\\')
		{
			qData.pathnameIsFile = false;
		}
	}

	data = ReadConfigString(section, L"Separator", L"\n");
	if (data)
	{
		qData.separator = data;
	}
	
	if (!qData.pathname.empty())
	{
		g_Values[id] = qData;
	}

	// TODO: Random=0, load stuff sequentially (store to somewhere)

	srand( (unsigned)time( NULL ) );

	return 0;
}

#define BUFFER_SIZE 4096

/*
This function is called when new value should be measured.
The function returns the new value.
*/
double Update2(UINT id)
{
	std::map<UINT, quoteData>::iterator i = g_Values.find(id);
	if (i != g_Values.end())
	{
		quoteData& qData = (*i).second;

		if (qData.pathnameIsFile)
		{
			BYTE buffer[BUFFER_SIZE + 2];
			buffer[BUFFER_SIZE] = 0;

			// Read the file
			FILE* file = _wfopen(qData.pathname.c_str(), L"r");
			if (file)
			{
				// Check if the file is unicode or ascii
				fread(buffer, sizeof(WCHAR), 1, file);

				fseek(file, 0, SEEK_END);
				int size = ftell(file);

				// Go to a random place
				int pos = rand() % size;
				fseek(file, (pos / 2) * 2, SEEK_SET);

				qData.value.erase();

				if (0xFEFF == *(WCHAR*)buffer) 
				{
					// It's unicode
					WCHAR* wBuffer = (WCHAR*)buffer;

					// Read until we find the first separator
					WCHAR* sepPos1 = NULL;
					WCHAR* sepPos2 = NULL;
					do 
					{
						size_t len = fread(buffer, sizeof(BYTE), BUFFER_SIZE, file);
						buffer[len] = 0;
						buffer[len + 1] = 0;

						sepPos1 = wcsstr(wBuffer, qData.separator.c_str());
						if (sepPos1 == NULL)
						{
							// The separator wasn't found
							if (feof(file))
							{
								// End of file reached -> read from start
								fseek(file, 2, SEEK_SET);
								len = fread(buffer, sizeof(BYTE), BUFFER_SIZE, file);
								buffer[len] = 0;
								buffer[len + 1] = 0;
								sepPos1 = wBuffer;
							}
							// else continue reading
						}
						else
						{
							sepPos1 += qData.separator.size();
						}
					}
					while (sepPos1 == NULL);

					// Find the second separator
					do 
					{
						sepPos2 = wcsstr(sepPos1, qData.separator.c_str());
						if (sepPos2 == NULL)
						{
							// The separator wasn't found
							if (feof(file))
							{
								// End of file reached -> read the rest
								qData.value += sepPos1;
								break;
							}
							else
							{
								qData.value += sepPos1;

								// else continue reading
								size_t len = fread(buffer, sizeof(BYTE), BUFFER_SIZE, file);
								buffer[len] = 0;
								buffer[len + 1] = 0;
								sepPos1 = wBuffer;
							}
						}
						else
						{
							if (sepPos2)
							{
								*sepPos2 = 0;
							}

							// Read until we find the second separator
							qData.value += sepPos1;
						}
					}
					while (sepPos2 == NULL);
				}
				else
				{
					// It's ascii
					char* aBuffer = (char*)buffer;

					// Read until we find the first separator
					char* sepPos1 = NULL;
					char* sepPos2 = NULL;
					do 
					{
						size_t len = fread(buffer, sizeof(char), BUFFER_SIZE, file);
						aBuffer[len] = 0;

						sepPos1 = strstr(aBuffer, ConvertToAscii(qData.separator.c_str()).c_str());
						if (sepPos1 == NULL)
						{
							// The separator wasn't found
							if (feof(file))
							{
								// End of file reached -> read from start
								fseek(file, 0, SEEK_SET);
								len = fread(buffer, sizeof(char), BUFFER_SIZE, file);
								aBuffer[len] = 0;
								sepPos1 = aBuffer;
							}
							// else continue reading
						}
						else
						{
							sepPos1 += qData.separator.size();
						}
					}
					while (sepPos1 == NULL);

					// Find the second separator
					do 
					{
						sepPos2 = strstr(sepPos1, ConvertToAscii(qData.separator.c_str()).c_str());
						if (sepPos2 == NULL)
						{
							// The separator wasn't found
							if (feof(file))
							{
								// End of file reached -> read the rest
								qData.value += ConvertToWide(sepPos1);
								break;
							}
							else
							{
								qData.value += ConvertToWide(sepPos1);

								// else continue reading
								size_t len = fread(buffer, sizeof(char), BUFFER_SIZE, file);
								aBuffer[len] = 0;
								sepPos1 = aBuffer;
							}
						}
						else
						{
							if (sepPos2)
							{
								*sepPos2 = 0;
							}

							// Read until we find the second separator
							qData.value += ConvertToWide(sepPos1);
						}
					}
					while (sepPos2 == NULL);
				}

				fclose(file);
			}
		}
		else
		{
			// Get folder listing
			std::vector<std::wstring> files;
			WIN32_FIND_DATA fileData;      // Data structure describes the file found
			HANDLE hSearch;                // Search handle returned by FindFirstFile

			std::wstring path = qData.pathname + L"*";

			hSearch = FindFirstFile(path.c_str(), &fileData);
			do
			{
				if(hSearch == INVALID_HANDLE_VALUE) break;    // No more files found

				if (wcscmp(fileData.cFileName, L".") != 0 && wcscmp(fileData.cFileName, L"..") != 0)
				{
					files.push_back(qData.pathname + fileData.cFileName);
				}
			}
			while(FindNextFile(hSearch, &fileData));

			// Select the filename
			if (files.size() > 0)
			{
				qData.value = files[rand() % files.size()];
			}
		}
	}
	
	return 0;
}

LPCTSTR GetString(UINT id, UINT flags) 
{
	std::map<UINT, quoteData>::iterator i = g_Values.find(id);
	if (i != g_Values.end())
	{
		return ((*i).second).value.c_str();
	}

	return NULL;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	std::map<UINT, quoteData>::iterator i1 = g_Values.find(id);
	if (i1 != g_Values.end())
	{
		g_Values.erase(i1);
	}
}

UINT GetPluginVersion()
{
	return 1000;
}

LPCTSTR GetPluginAuthor()
{
	return L"Rainy (rainy@iki.fi)";
}