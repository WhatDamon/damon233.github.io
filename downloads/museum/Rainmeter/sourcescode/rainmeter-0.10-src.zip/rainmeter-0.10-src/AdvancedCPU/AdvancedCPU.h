#ifndef __ADVANCEDCPU_H__
#define __ADVANCEDCPU_H__

#include "../PerfMon/titledb.h"
#include "../PerfMon/perfsnap.h"
#include "../PerfMon/objlist.h"
#include "../PerfMon/perfobj.h"
#include "../PerfMon/objinst.h"
#include "../PerfMon/perfcntr.h"

#pragma warning ( disable: 4786 )

/* The exported functions */
extern "C"
{
__declspec( dllexport ) UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id);
__declspec( dllexport ) void Finalize(HMODULE instance, UINT id);
__declspec( dllexport ) UINT Update(UINT id);
__declspec( dllexport ) UINT GetPluginVersion();
__declspec( dllexport ) LPCTSTR GetPluginAuthor();
}

#endif