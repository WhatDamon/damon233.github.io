/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/Measure.cpp,v 1.18 2004/06/05 10:55:54 rainy Exp $

  $Log: Measure.cpp,v $
  Revision 1.18  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.17  2004/03/13 16:15:01  rainy
  GetStats returns only the value

  Revision 1.16  2003/12/05 15:50:09  Rainy
  Multi-instance changes.

  Revision 1.15  2003/02/10 18:13:49  rainy
  Added median filter to max value.

  Revision 1.14  2002/12/23 14:26:21  rainy
  Stats are gathered a bit different way now.

  Revision 1.13  2002/05/05 10:49:16  rainy
  Disabled measures return 0.

  Revision 1.12  2002/05/04 08:12:33  rainy
  Measure update is not tied to the update rate directly anymore.

  Revision 1.11  2002/04/26 18:24:16  rainy
  Modified the Update method to support disabled measures.

  Revision 1.10  2002/04/01 15:39:09  rainy
  Fixed IfBelow and IfAbove actions.
  Added NetTotal measure.

  Revision 1.9  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.8  2001/12/23 10:18:52  rainy
  Added Time and removed Perfmon.

  Revision 1.7  2001/10/28 10:23:59  rainy
  GetStringValue uses consts.
  Added IfAbove/Below actions.
  Added Plugin and Registry Measures.

  Revision 1.6  2001/10/14 07:32:03  rainy
  Minor monifications to remove few warnings with VC.NET.
  In error situations CError is thrown instead just a boolean value.

  Revision 1.5  2001/09/26 16:27:15  rainy
  Changed the interfaces a bit.

  Revision 1.4  2001/09/01 13:00:41  rainy
  Slight changes in the interface. The value is now measured only once if possible.
  Added support for logging the max value.

  Revision 1.3  2001/08/19 09:15:41  rainy
  Invert was moved here from the meter.

  Revision 1.2  2001/08/12 15:47:00  Rainy
  Adjusted Update()'s interface.
  Added GetStringValue() method.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "Measure.h"
#include "MeasureCPU.h"
#include "MeasureMemory.h"
#include "MeasurePhysicalMemory.h"
#include "MeasureVirtualMemory.h"
#include "MeasureNetIn.h"
#include "MeasureNetOut.h"
#include "MeasureNetTotal.h"
#include "MeasureDiskSpace.h"
#include "MeasureUptime.h"
#include "MeasurePlugin.h"
#include "MeasureRegistry.h"
#include "MeasureTime.h"
#include "MeasureCalc.h"
#include "Rainmeter.h"
#include "Error.h"
#include "Litestep.h"
#include <algorithm>

const int MEDIAN_SIZE = 7;

/*
** CMeasure
**
** The constructor
**
*/
CMeasure::CMeasure()
{
	m_Invert = false;
	m_LogMaxValue = false;
	m_MinValue = 0.0;
	m_MaxValue = 1.0;
	m_Value = 0.0;
	m_IfAboveValue = 0.0;
	m_IfBelowValue = 0.0;
	m_IfAboveCommited = false;
	m_IfBelowCommited = false;
	m_Disabled = false;
	m_UpdateDivider = 1;
	m_UpdateCounter = 0;
	m_MedianPos = 0;
	m_AveragePos = 0;
	m_AverageSize = 0;
}

/*
** ~CMeasure
**
** The destructor
**
*/
CMeasure::~CMeasure()
{
}

/*
** ReadConfig
**
** Reads the common configs for all Measures. The inherited classes
** must call the base implementation if they overwrite this method.
** 
*/
void CMeasure::ReadConfig(CConfigParser& parser, const char* section)
{
	m_Invert = 0!=parser.ReadInt(section, "InvertMeasure", 0);
	m_Disabled = 0!=parser.ReadInt(section, "Disabled", 0);
	m_UpdateDivider = parser.ReadInt(section, "UpdateDivider", 1);
	m_UpdateCounter = m_UpdateDivider;

	m_MinValue = parser.ReadFloat(section, "MinValue", m_MinValue);
	m_MaxValue = parser.ReadFloat(section, "MaxValue", m_MaxValue);

	// The ifabove/ifbelow define actions that are ran when the value goes above/below the given number.

	m_IfAboveValue = parser.ReadFloat(section, "IfAboveValue", 0.0);
	m_IfAboveAction = parser.ReadString(section, "IfAboveAction", "");

	m_IfBelowValue = parser.ReadFloat(section, "IfBelowValue", 0.0);
	m_IfBelowAction = parser.ReadString(section, "IfBelowAction", "");

	m_AverageSize = parser.ReadInt(section, "AverageSize", 0);
	
	std::string subs;
	subs = parser.ReadString(section, "Substitute", "");
	if (!ParseSubstitute(subs))
	{
		DebugLog("WebParser: Incorrect substitute string: %s", subs.c_str());
	}
}

/*
** CheckSubstitute
** 
** Substitutes part of the text
*/
const char* CMeasure::CheckSubstitute(const char* buffer)
{
	static std::string str;

	if (!m_Substitute.empty())
	{
		str = buffer;

		std::map<std::string, std::string>::iterator iter = m_Substitute.begin();

		int start = 0;
		for ( ; iter != m_Substitute.end(); iter++)
		{
			std::string::size_type pos = -1;
			do 
			{
				pos = str.find((*iter).first, start);
				if (pos != -1)
				{
					str.replace(str.begin() + pos, str.begin() + pos + (*iter).first.size(), (*iter).second);
					start = pos + (*iter).second.size();
				}
			} while(pos != -1);
		}

		return str.c_str();
	}	
	else
	{
		return buffer;
	}
}

/*
** ParseSubstitute
** 
** Reads the buffer for "Name":"Value"-pairs separated with comma and
** fills the map with the parsed data.
*/
bool CMeasure::ParseSubstitute(std::string buffer)
{
	if (buffer.empty()) return true;	

	// Add quotes since they are removed by the GetProfileString
	buffer = "\"" + buffer + "\"";

	std::string word1;
	std::string word2;
	std::string sep;

	while (!buffer.empty())
	{
		word1 = ExtractWord(buffer);
		sep = ExtractWord(buffer);
		if (sep != ":") return false; 
		word2 = ExtractWord(buffer);
		m_Substitute[word1] = word2;

		sep = ExtractWord(buffer);
		if (!sep.empty() && sep != ",") return false; 
	}

	return true;
}

/*
** ExtractWord
**
** Returns the first word from the buffer. The word can be inside quotes.
** If not, the separators are ' ', '\t', ',' and ':'. Whitespaces are removed 
** and buffer _will_ be modified.
*/
std::string CMeasure::ExtractWord(std::string& buffer)
{
	std::string::size_type end = 0;
	std::string ret;

	if (buffer.empty()) return ret;	

	// Remove whitespaces
	std::string::size_type notwhite = buffer.find_first_not_of(" \t\n");
	buffer.erase(0, notwhite);

	if (buffer[0] == '\"')
	{
		end = 1;	// Skip the '"'
		// Quotes around the word
		while (buffer[end] != '\"' && end < buffer.size()) end++;

		if (buffer[end] == '\"')
		{
			ret = buffer.substr(1, end - 1);
			buffer.erase(0, end + 1);
		}
		else
		{
			// End of string reached
			ret = buffer.substr(end);
			buffer.erase(0, end);
		}
	}
	else
	{
		end = 0;
		while ((buffer[end] != ',') && (buffer[end] != ':') && (buffer[end] != ' ') && (buffer[end] != '\t') && end < buffer.size()) end++;

		if (end == buffer.size())
		{
			// End of line reached
			ret = buffer;
			buffer.erase(0, end);
		}
		else
		{
			ret = buffer.substr(0, end + 1);	// The separator is also returned!
			buffer.erase(0, end + 1);
		}
	}
	return ret;
}


/*
** PreUpdate
**
** The base implementation of the update method. This includes the code
** that is common for all measures. This is called every time the measure 
** is updated. The inherited classes must call the base implementation if 
** they overwrite this method. If this method returns false, the update
** needs not to be done.
** 
*/
bool CMeasure::PreUpdate(CMeterWindow* meterWindow)
{
	if (IsDisabled()) 
	{
		m_Value = 0.0;	// Disable measures return 0 as value
		return false;
	}
	
	// Only update the counter if the divider 
	m_UpdateCounter++;
	if (m_UpdateCounter < m_UpdateDivider) return false;
	m_UpdateCounter = 0;

	// If we're logging the maximum value of the measure, check if
	// the new value is greater than the old one, and update if necessary.
	if(m_LogMaxValue)
	{
		if (m_MedianMaxValues.empty())
		{
			m_MedianMaxValues.resize(MEDIAN_SIZE, 0);
			m_MedianMinValues.resize(MEDIAN_SIZE, 0);
		}

		m_MedianMaxValues[m_MedianPos] = m_Value;
		m_MedianMinValues[m_MedianPos] = m_Value;
		m_MedianPos++;
		m_MedianPos %= MEDIAN_SIZE;

		std::vector<double> medianArray;
		
		medianArray = m_MedianMaxValues;
		std::sort(medianArray.begin(), medianArray.end());
		m_MaxValue = max(m_MaxValue, medianArray[MEDIAN_SIZE / 2]);

		medianArray = m_MedianMinValues;
		std::sort(medianArray.begin(), medianArray.end());
		m_MinValue = min(m_MinValue, medianArray[MEDIAN_SIZE / 2]);
	}

	if (meterWindow)
	{
		// Check the IfAboveValue
		if(!m_IfAboveAction.empty())
		{
			if(m_Value > m_IfAboveValue)
			{
				if(!m_IfAboveCommited)
				{
					meterWindow->ExecuteCommand(m_IfAboveAction.c_str());
					m_IfAboveCommited = true;
				}
			}
			else
			{
				m_IfAboveCommited = false;
			}
		}

		// Check the IfBelowValue
		if(!m_IfBelowAction.empty())
		{
			if(m_Value < m_IfBelowValue)
			{
				if(!m_IfBelowCommited)
				{
					meterWindow->ExecuteCommand(m_IfBelowAction.c_str());
					m_IfBelowCommited = true;
				}
			}
			else
			{
				m_IfBelowCommited = false;
			}
		}
	}

	return true;
}

/*
** PostUpdate
**
** Does post measuring things to the value. All measures must call this
** after they have set the m_Value.
** 
*/
bool CMeasure::PostUpdate(CMeterWindow* meterWindow)
{
	if (m_AverageSize > 0)
	{
		if (m_AverageValues.size() == 0)
		{
			m_AverageValues.resize(m_AverageSize, m_Value);
		}
		m_AverageValues[m_AveragePos] = m_Value;

		m_AveragePos++;
		m_AveragePos %= m_AverageValues.size();

		// Calculate the average value
		m_Value = 0;
		for (int i = 0; i < m_AverageValues.size(); i++)
		{
			m_Value += m_AverageValues[i];
		}
		m_Value = m_Value / (double)m_AverageValues.size();
	}
	return true;
}

/*
** GetValue
**
** Returns the value of the measure. 
** 
*/
double CMeasure::GetValue()
{
	// Invert if so requested
	if (m_Invert)
	{
		return m_MaxValue - m_Value + m_MinValue;
	}

	return m_Value;
}

/*
** GetRelativeValue
**
** Returns the relative value of the measure (0.0 - 1.0). 
** 
*/
double CMeasure::GetRelativeValue()
{
	double value = GetValue();

	value = min(m_MaxValue, value);
	value = max(m_MinValue, value);

	value -= m_MinValue;

	return value / GetValueRange();
}

/*
** GetValueRange
**
** Returns the value range. 
** 
*/
double CMeasure::GetValueRange()
{
	return m_MaxValue - m_MinValue;
}

/*
** GetStringValue
**
** This method returns the value as text string. The actual value is
** get with GetValue() so we don't have to worry about m_Invert.
** 
** autoScale  If true, scale the value automatically to some sensible range.
** scale      The scale to use if autoScale is false.
** decimals   Number of decimals used in the value.
** percentual Return the value as % from the maximum value.
*/
const char* CMeasure::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char buffer[MAX_LINE_LENGTH];
	static char buffer2[MAX_LINE_LENGTH];
	static char format[16];
	double value;
	double theValue = GetValue();

	if(percentual)
	{
		sprintf(buffer, "%i", (UINT)(100.0 * GetRelativeValue()));
	} 
	else if(autoScale)
	{
		if(decimals == 0)
		{
			strcpy(format, "%%.0f ");
		}
		else
		{
			sprintf(format, "%%.%if ", decimals);
		}

		if(theValue > 1000.0 * 1000.0 * 1000.0 * 1000.0)
		{
			strcat(format, "T");
			value = theValue / 1024.0 / 1024.0 / 1024.0 / 1024.0;
		}
		else if(theValue > 1000.0 * 1000.0 * 1000.0)
		{
			strcat(format, "G");
			value = theValue / 1024.0 / 1024.0 / 1024.0;
		}
		else if(theValue > 1000.0 * 1000.0)
		{
			strcat(format, "M");
			value = theValue / 1024.0 / 1024.0;
		}
		else if(theValue > 1000.0)
		{
			strcat(format, "k");
			value = theValue / 1024.0;
		}
		else
		{
			value = theValue;
		}
		sprintf(buffer, format, value);
	}
	else 
	{
		if(decimals == 0)
		{
			sprintf(buffer, "%i", (UINT)(theValue * (1.0 / scale) + 0.5));
		}
		else
		{
			sprintf(buffer2, "%%.%if", decimals);
			sprintf(buffer, buffer2, theValue * (1.0 / scale));
		}
	}

	return CheckSubstitute(buffer);
}

/*
** ReadStats
**
** Base implementation of stats reading. The stats are stored in registry 
** and the key is given as parameter. The stats are measure specific, so
** we do nothing here.
** 
*/
void CMeasure::ReadStats(const std::string& iniFile)
{
	// Do nuthing
}

/*
** WriteStats
**
** Base implementation of stats writing. The stats are stored in registry 
** and the key is given as parameter. The stats are measure specific, so
** we do nothing here.
** 
*/
void CMeasure::WriteStats(const std::string& iniFile)
{
	// Do nuthing
}

/*
** GetStats
**
** Returns the stats as string. The stats are shown in the About dialog.
*/
const char* CMeasure::GetStats()
{
	static std::string value;

	value = GetStringValue(true, 1, 1, false);

	return value.c_str();
}

/*
** Create
**
** Creates the given measure. This is the factory method for the measures.
** If new measures are implemented this method needs to be updated.
** 
*/
CMeasure* CMeasure::Create(const char* measure)
{
	// Comparson is caseinsensitive

	if(_stricmp("", measure) == 0)
	{
		return NULL;
	}
	else if(_stricmp("CPU", measure) == 0)
	{
		return new CMeasureCPU;
	} 
	else if(_stricmp("Memory", measure) == 0)
	{
		return new CMeasureMemory;
	}
	else if(_stricmp("NetIn", measure) == 0)
	{
		return new CMeasureNetIn;
	}
	else if(_stricmp("NetOut", measure) == 0)
	{
		return new CMeasureNetOut;
	}
	else if(_stricmp("NetTotal", measure) == 0)
	{
		return new CMeasureNetTotal;
	}
	else if(_stricmp("PhysicalMemory", measure) == 0)
	{
		return new CMeasurePhysicalMemory;
	}
	else if(_stricmp("SwapMemory", measure) == 0)
	{
		return new CMeasureVirtualMemory;
	}
	else if(_stricmp("FreeDiskSpace", measure) == 0)
	{
		return new CMeasureDiskSpace;
	}
	else if(_stricmp("Uptime", measure) == 0)
	{
		return new CMeasureUptime;
	}
	else if(_stricmp("Time", measure) == 0)
	{
		return new CMeasureTime;
	}
	else if(_stricmp("Plugin", measure) == 0)
	{
		return new CMeasurePlugin;
	}
	else if(_stricmp("Registry", measure) == 0)
	{
		return new CMeasureRegistry;
	}
	else if(_stricmp("Calc", measure) == 0)
	{
		return new CMeasureCalc;
	}

    // Error
    throw CError(std::string("No such measure: ") + measure, __LINE__, __FILE__);

	return NULL;
}
