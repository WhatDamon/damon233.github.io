/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterBitmap.cpp,v 1.10 2004/06/05 10:55:54 rainy Exp $

  $Log: MeterBitmap.cpp,v $
  Revision 1.10  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.9  2003/02/10 18:12:45  rainy
  Now uses GDI+

  Revision 1.8  2002/07/01 15:32:51  rainy
  Removed include to lsapi.h

  Revision 1.7  2002/04/26 18:22:02  rainy
  Added possibility to hide the meter.

  Revision 1.6  2002/03/31 20:32:29  rainy
  Added ZeroFrame, which uses the first frame only for value 0.

  Revision 1.5  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.4  2001/12/23 10:15:04  rainy
  Added one sanity check.

  Revision 1.3  2001/10/14 07:32:33  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.2  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.


*/

#pragma warning(disable: 4786)

#include "MeterBitmap.h"
#include "Measure.h"
#include "Error.h"

using namespace Gdiplus;

/*
** CMeterBitmap
**
** The constructor
**
*/
CMeterBitmap::CMeterBitmap() : CMeter()
{
	m_Bitmap = NULL;
	m_FrameCount = 0;
	m_ZeroFrame = false;
	m_Align = ALIGN_LEFT;
	m_Extend = false;
	m_Separation = 0;
	m_Digits = 0;
	m_Value = 0;
}

/*
** ~CMeterBitmap
**
** The destructor
**
*/
CMeterBitmap::~CMeterBitmap()
{
	if(m_Bitmap != NULL) delete m_Bitmap;
}

/*
** Initialize
**
** Load the image and get the dimensions of the meter from it.
**
*/
void CMeterBitmap::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	// Load the bitmaps if defined
	if(!m_ImageName.empty())
	{
		WCHAR* wideSz = ConvertToWide(m_ImageName.c_str());
		m_Bitmap = new Bitmap(wideSz);
		delete [] wideSz;

		Status status = m_Bitmap->GetLastStatus();
		if(Ok != status)
		{
            throw CError(std::string("Bitmap image not found: ") + m_ImageName, __LINE__, __FILE__);
		}

		m_W = m_Bitmap->GetWidth();
		m_H = m_Bitmap->GetHeight();

		if(m_H > m_W)
		{
			m_H = m_H / m_FrameCount;
		}
		else
		{
			m_W = m_W / m_FrameCount;
		}
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterBitmap::ReadConfig(CMeterWindow& meterWindow, const char* section)
{
	// Read common configs
	CMeter::ReadConfig(meterWindow, section);

	CConfigParser& parser = meterWindow.GetParser();

	m_ImageName = parser.ReadString(section, "BitmapImage", "");
	m_FrameCount = parser.ReadInt(section, "BitmapFrames", 0);
	m_ZeroFrame = 0!=parser.ReadInt(section, "BitmapZeroFrame", 0);

	m_Separation = parser.ReadInt(section, "BitmapSeparation", 0);
	m_Extend = 0!=parser.ReadInt(section, "BitmapExtend", 0);
	m_Digits = parser.ReadInt(section, "BitmapDigits", 0);

	std::string align;
	align = parser.ReadString(section, "BitmapAlign", "LEFT");
	
	if(_stricmp(align.c_str(), "LEFT") == 0)
	{
		m_Align = ALIGN_LEFT;
	}
	else if(_stricmp(align.c_str(), "RIGHT") == 0)
	{
		m_Align = ALIGN_RIGHT;
	}
	else if(_stricmp(align.c_str(), "CENTER") == 0)
	{
		m_Align = ALIGN_CENTER;
	}
	else
	{
        throw CError(std::string("No such BitmapAlign: ") + align, __LINE__, __FILE__);
	}
}

/*
** Update
**
** Updates the value(s) from the measures.
**
*/
bool CMeterBitmap::Update(CMeterWindow& meterWindow)
{
	if (CMeter::Update(meterWindow) && m_Measure)
	{
		if (m_Extend)
		{
			m_Value = m_Measure->GetValue();
		}
		else
		{
			m_Value = m_Measure->GetRelativeValue();
		}
		return true;
	}
	return false;
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
bool CMeterBitmap::Draw(CMeterWindow& meterWindow)
{
	if(!CMeter::Draw(meterWindow)) return false;

	int newY, newX;

	if(m_FrameCount == 0 || m_Bitmap == NULL) return false;	// Unable to continue

	if (m_Extend)
	{
		int value = (int)m_Value;
		value = max(0, value);		// Only positive integers are supported

		int tmpValue = value;
		// Calc the number of numbers
		int numOfNums = 0;

		if (m_Digits > 0)
		{
			numOfNums = m_Digits;
		}
		else
		{
			do
			{
				numOfNums ++;
				if (m_FrameCount == 1)
				{
					tmpValue /= 2;
				}
				else
				{
					tmpValue /= m_FrameCount;
				}
			} while (tmpValue > 0);
		}

		// Blit the images
		int x, y, offset;
		Graphics graphics(meterWindow.GetDoubleBuffer());
		
		if (m_Align == ALIGN_RIGHT)
		{
			offset = 0;
		}
		else if (m_Align == ALIGN_CENTER)
		{
			offset = numOfNums * (m_W + m_Separation) / 2;
		}
		else
		{
			offset = numOfNums * (m_W + m_Separation);
		}

		do
		{
			offset = offset - (m_W + m_Separation);

			Rect r(m_X + offset, m_Y, m_W, m_H);

			if(m_Bitmap->GetHeight() > m_Bitmap->GetWidth())
			{
				x = 0;
				y = m_H * (value % m_FrameCount);
			}
			else
			{
				x = m_W * (value % m_FrameCount);
				y = 0;
			}

			graphics.DrawImage(m_Bitmap, r, x, y, m_W, m_H, UnitPixel);
			if (m_FrameCount == 1)
			{
				value /= 2;
			}
			else
			{
				value /= m_FrameCount;
			}
			numOfNums--;
		} while (numOfNums > 0);
	}
	else
	{
		int frame = 0;

		if (m_ZeroFrame)
		{
			// Use the first frame only if the value is zero
			if (m_Value > 0)
			{
				frame = (int)(m_Value * (m_FrameCount - 1));
			}
		}
		else
		{
			// Select the correct frame linearly
			frame = (int)(m_Value * m_FrameCount);
		}

		if(m_Bitmap->GetHeight() > m_Bitmap->GetWidth())
		{
			newX = 0;
			newY = frame * m_H;
		}
		else
		{
			newX = frame * m_W;
			newY = 0;
		}

		// Blit the image
		Graphics graphics(meterWindow.GetDoubleBuffer());
		Rect r(m_X, m_Y, m_W, m_H);
		graphics.DrawImage(m_Bitmap, r, newX, newY, m_W, m_H, UnitPixel);
	}

	return true;
}

