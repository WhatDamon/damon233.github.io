/*
  Copyright (C) 2002 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterImage.cpp,v 1.5 2004/06/05 10:55:54 rainy Exp $

  $Log: MeterImage.cpp,v $
  Revision 1.5  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.4  2003/12/05 15:50:10  Rainy
  Multi-instance changes.

  Revision 1.3  2003/02/10 18:12:45  rainy
  Now uses GDI+

  Revision 1.2  2002/07/01 15:32:50  rainy
  Removed include to lsapi.h

  Revision 1.1  2002/04/27 10:28:31  rainy
  Intial version.

*/

#pragma warning(disable: 4786)

#include "MeterImage.h"
#include "Measure.h"
#include "Error.h"
#include "Rainmeter.h"

extern CRainmeter* Rainmeter;

using namespace Gdiplus;

/*
** CMeterImage
**
** The constructor
**
*/
CMeterImage::CMeterImage() : CMeter()
{
	m_Bitmap = NULL;
}

/*
** ~CMeterImage
**
** The destructor
**
*/
CMeterImage::~CMeterImage()
{
	if(m_Bitmap != NULL) delete m_Bitmap;
}

/*
** Initialize
**
** Load the image and get the dimensions of the meter from it.
**
*/
void CMeterImage::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	LoadImage();
}

/*
** ReadConfig
**
** Loads the image from disk
**
*/
void CMeterImage::LoadImage()
{
	// Load the bitmap if defined
	if(!m_ImageName.empty())
	{
		std::string filename = m_ImageName;

		// Check extension and if it is missing, add .png
		if (-1 == filename.find_last_of("."))
		{
			filename += ".png";
		}

		WCHAR* wideSz = ConvertToWide(filename.c_str());
		m_Bitmap = new Bitmap(wideSz);
		delete [] wideSz;

		Status status = m_Bitmap->GetLastStatus();
		if(Ok != status)
		{
            throw CError(std::string("Unable to load image: ") + filename, __LINE__, __FILE__);
		}

		m_W = m_Bitmap->GetWidth();
		m_H = m_Bitmap->GetHeight();
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterImage::ReadConfig(CMeterWindow& meterWindow, const char* section)
{
	// Read common configs
	CMeter::ReadConfig(meterWindow, section);

	CConfigParser& parser = meterWindow.GetParser();

	m_ImageName = parser.ReadString(section, "ImageName", "");
}

/*
** Update
**
** Updates the value(s) from the measures.
**
*/
bool CMeterImage::Update(CMeterWindow& meterWindow)
{
	if (CMeter::Update(meterWindow) && m_Measure)
	{
		m_StringValue = m_Measure->GetStringValue(false, 1, 0, false);
		if (!m_StringValue.empty())
		{
			if (m_ImageName != m_StringValue)
			{
				// Load the new image
				m_ImageName = m_StringValue;

				char currentDir[MAX_LINE_LENGTH];
				GetCurrentDirectory(MAX_LINE_LENGTH, currentDir);

				// Set the current directory so that the graphics can be found
				std::string path = Rainmeter->GetSkinPath();
				path += meterWindow.GetSkinName();

				SetCurrentDirectory(path.c_str());

				LoadImage();

				// Make the current folder like it was before so that we don't break anything
				SetCurrentDirectory(currentDir);
			}
		}
		return true;
	}
	return false;
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
bool CMeterImage::Draw(CMeterWindow& meterWindow)
{
	if(!CMeter::Draw(meterWindow)) return false;

	if (m_Bitmap != NULL)
	{
		Graphics graphics(meterWindow.GetDoubleBuffer());

		// Copy the image over the doublebuffer
		graphics.DrawImage(m_Bitmap, m_X, m_Y, m_W, m_H);
	}

	return true;
}

/*
** BindMeasure
**
** Overridden method. The Image meters need not to be bound on anything
**
*/
void CMeterImage::BindMeasure(std::list<CMeasure*>& measures)
{
	try
	{
		CMeter::BindMeasure(measures);
	}
	catch(CError)
	{
		// Do nothing (ignore errors)
	}
}

