/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterLine.cpp,v 1.4 2004/06/05 10:55:54 rainy Exp $

  $Log: MeterLine.cpp,v $
  Revision 1.4  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.3  2004/03/13 16:18:16  rainy
  Limits negative coords

  Revision 1.2  2003/02/10 18:12:44  rainy
  Now uses GDI+

  Revision 1.1  2002/07/01 15:35:54  rainy
  Intial version


*/

#pragma warning(disable: 4786)

#include "MeterLine.h"
#include "Measure.h"
#include "Error.h"
#include <crtdbg.h>
#include <gdiplus.h>

using namespace Gdiplus;

/*
** CMeterLine
**
** The constructor
**
*/
CMeterLine::CMeterLine() : CMeter()
{
	m_Autoscale = false;
	m_AntiAlias = false;
	m_HorizontalLines = false;
	m_HorizontalColor = 0;
	m_CurrentPos = 0;
	m_Flip = false;
	m_LineWidth = 1.0;
}

/*
** ~CMeterLine
**
** The destructor
**
*/
CMeterLine::~CMeterLine()
{
}

/*
** Initialize
**
** create the buffer for the lines
**
*/
void CMeterLine::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	std::vector<Color>::iterator i = m_Colors.begin();
	for ( ; i != m_Colors.end(); i++)
	{
		m_AllValues.push_back(std::vector<double>());
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterLine::ReadConfig(CMeterWindow& meterWindow, const char* section)
{
	int i;
	char tmpName[256];

	// Read common configs
	CMeter::ReadConfig(meterWindow, section);

	CConfigParser& parser = meterWindow.GetParser();

	int lineCount = parser.ReadInt(section, "LineCount", 1);

	for (i = 0; i < lineCount; i++)
	{
		if (i == 0)
		{
			strcpy(tmpName, "LineColor");
		}
		else
		{
			sprintf(tmpName, "LineColor%i", i + 1);
		}

		m_Colors.push_back(parser.ReadColor(section, tmpName, Color::White));

		if (i == 0)
		{
			strcpy(tmpName, "Scale");
		}
		else
		{
			sprintf(tmpName, "Scale%i", i + 1);
		}

		m_ScaleValues.push_back(parser.ReadFloat(section, tmpName, 1.0));

		if (i != 0)
		{
			sprintf(tmpName, "MeasureName%i", i + 1);
			m_MeasureNames.push_back(parser.ReadString(section, tmpName, ""));
		}
	}

	m_Flip = 0!=parser.ReadInt(section, "Flip", 0);
	m_Autoscale = 0!=parser.ReadInt(section, "AutoScale", 0);
	m_AntiAlias = 0!=parser.ReadInt(section, "AntiAlias", 0);
	m_LineWidth = parser.ReadFloat(section, "LineWidth", 1.0);
	m_HorizontalLines = 0!=parser.ReadInt(section, "HorizontalLines", 0);
	m_HorizontalColor = parser.ReadColor(section, "HorizontalColor", Color::Black);
}

/*
** Update
**
** Updates the value(s) from the measures.
**
*/
bool CMeterLine::Update(CMeterWindow& meterWindow)
{
	if (CMeter::Update(meterWindow) && m_Measure)
	{
		// Collect the values
		if (!m_Measure->IsDisabled())
		{
			double value = m_Measure->GetValue();

			if (m_AllValues[0].size() < m_W)
			{
				m_AllValues[0].push_back(value);
			}
			else
			{
				m_AllValues[0][m_CurrentPos] = value;
			}
		}

		int counter = 1;
		std::vector<CMeasure*>::iterator i = m_Measures.begin();
		for ( ; i != m_Measures.end(); i++)
		{
			unsigned int value = (*i)->GetValue();

			if (m_AllValues[counter].size() < m_W)
			{
				m_AllValues[counter].push_back(value);
			}
			else
			{
				m_AllValues[counter][m_CurrentPos] = value;
			}
			counter++;
		}

		m_CurrentPos++;
		if (m_CurrentPos >= m_W)
		{
			m_CurrentPos = 0;
		}
		return true;
	}
	return false;
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
bool CMeterLine::Draw(CMeterWindow& meterWindow)
{
	if(!CMeter::Draw(meterWindow)) return false;

	double maxValue = 0.0;
	int counter = 0;

	// Find the maximum value
	if (m_Autoscale)
	{
		double newValue = 0;
		std::vector< std::vector<double> >::iterator i = m_AllValues.begin();
		counter = 0;
		for (; i != m_AllValues.end(); i++)
		{
			std::vector<double>::iterator j = (*i).begin();
			for (; j != (*i).end(); j++)
			{
				newValue = max(newValue, (*j) * m_ScaleValues[counter]);
			}
			counter++;
		}

		// Scale the value up to nearest power of 2
		maxValue = 2;
		while(maxValue < newValue && maxValue != 0)
		{
			maxValue *= 2;
		}
	}
	else
	{
		maxValue = m_Measure->GetMaxValue();

		std::vector<CMeasure*>::iterator i = m_Measures.begin();
		for (; i != m_Measures.end(); i++)
		{
			maxValue = max(maxValue, (*i)->GetMaxValue());
		}
	}

	Graphics graphics(meterWindow.GetDoubleBuffer());		//GDI+
	if (m_AntiAlias)
	{
		graphics.SetSmoothingMode(SmoothingModeAntiAlias);
	}

	// Draw the horizontal lines
	if (m_HorizontalLines)
	{
		// Calc the max number of lines we should draw
		int maxLines = m_H / 4;	// one line per 4 pixels is max
		int numOfLines;

		// Check the highest power of 2 that fits in maxLines
		int power = 2;
		while(power < maxLines)
		{
			power *= 2;
		}

		numOfLines = ((int)maxValue % power) + 1;

		Pen pen(m_HorizontalColor);

		REAL Y;
		for (int j = 0; j < numOfLines; j++)
		{
			Y = (j + 1) * m_H / (numOfLines + 1);
			Y = m_Y + m_H - Y - 1;
			graphics.DrawLine(&pen, (REAL)m_X, Y, (REAL)(m_X + m_W - 1), Y);	// GDI+
		}
	}

	// Draw all the lines
	counter = 0;
	std::vector< std::vector<double> >::iterator i = m_AllValues.begin();
	for (; i != m_AllValues.end(); i++)
	{
		// Draw a line
		int X = m_X;
		REAL Y = 0;
		REAL oldY = 0;
		int pos = m_CurrentPos;
		if (pos >= m_W) pos = 0;
		
		Pen pen(m_Colors[counter], m_LineWidth);

		for (int j = 0; j < m_W; j++)
		{
			if (pos < (*i).size())
			{
				Y = (*i)[pos] * m_ScaleValues[counter] * (m_H - 1) / maxValue;
				Y = min(Y, m_H - 1);
				Y = max(Y, 0);
			}
			else
			{
				Y = 0;			
			}

			if (m_Flip)
			{
				Y = m_Y + Y;
			}
			else
			{
				Y = m_Y + m_H - Y - 1;
			}

			if (j != 0)
			{
				graphics.DrawLine(&pen, (REAL)X - 1, oldY, (REAL)X, Y);	// GDI+
			}
			oldY = Y;

			X++;
			pos++;
			if (pos >= m_W) pos = 0;
		}

		counter++;
	}

	return true;
}

/*
** BindMeasure
**
** Overwritten method to handle the other measure bindings.
**
*/
void CMeterLine::BindMeasure(std::list<CMeasure*>& measures)
{
	CMeter::BindMeasure(measures);

	std::vector<std::string>::iterator j = m_MeasureNames.begin();
	for (; j != m_MeasureNames.end(); j++)
	{
		// Go through the list and check it there is a secondary measure for us
		std::list<CMeasure*>::iterator i = measures.begin();
		for( ; i != measures.end(); i++)
		{
			if(_stricmp((*i)->GetName(), (*j).c_str()) == 0)
			{
				m_Measures.push_back(*i);
				break;
			}
		}
		
		if (i == measures.end())
		{
	        throw CError(std::string("The meter [") + m_Name + "] cannot be bound with [" + (*j) + "]!", __LINE__, __FILE__);
		}
	}
}
