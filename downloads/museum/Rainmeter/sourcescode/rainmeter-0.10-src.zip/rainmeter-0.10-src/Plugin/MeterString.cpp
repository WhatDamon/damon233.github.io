/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterString.cpp,v 1.10 2004/06/05 10:55:54 rainy Exp $

  $Log: MeterString.cpp,v $
  Revision 1.10  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.9  2003/02/10 18:12:44  rainy
  Now uses GDI+

  Revision 1.8  2002/07/01 15:32:20  rainy
  Added NumOfDecimals

  Revision 1.7  2002/04/26 18:22:02  rainy
  Added possibility to hide the meter.

  Revision 1.6  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.5  2001/12/23 10:14:33  rainy
  Hex color values are now also supported.

  Revision 1.4  2001/10/14 07:32:32  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.3  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.2  2001/09/01 12:57:33  rainy
  Added support for percentual measuring.

  Revision 1.1  2001/08/12 15:35:08  Rainy
  Inital Version

*/

#pragma warning(disable: 4786)

#include "MeterString.h"
#include "Rainmeter.h"
#include "Measure.h"
#include "Error.h"

using namespace Gdiplus;

/*
** CMeterString
**
** The constructor
**
*/
CMeterString::CMeterString() : CMeter()
{
	m_Color = RGB(255, 255, 255);
	m_AutoScale = true;
	m_Align = ALIGN_LEFT;
	m_Font = NULL;
	m_FontFamily = NULL;
	m_Style = NORMAL;
	m_FontSize = 10;
	m_Scale = 1.0;
	m_NoDecimals = true;
	m_Percentual = true;
	m_AntiAlias = false;
	m_ClipString = false;
	m_NumOfDecimals = -1;
}

/*
** ~CMeterString
**
** The destructor
**
*/
CMeterString::~CMeterString()
{
	if(m_Font) delete m_Font;
	if(m_FontFamily) delete m_FontFamily;
}

/*
** Initialize
**
** Create the font that is used to draw the text.
**
*/
void CMeterString::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	WCHAR* wideSz = ConvertToWide(m_FontFace.c_str());
	m_FontFamily = new FontFamily(wideSz);
	delete [] wideSz;

	Status status = m_FontFamily->GetLastStatus();
	if(Ok != status)
	{
		delete m_FontFamily;
		m_FontFamily = NULL;
	}

	FontStyle style = FontStyleRegular;

	switch(m_Style)
	{
	case ITALIC:
		style = FontStyleItalic;
		break;

	case BOLD:
		style = FontStyleBold;
		break;

	case BOLDITALIC:
		style = FontStyleBoldItalic;
		break;
	}

	if (m_FontFamily)
	{
		m_Font = new Font(m_FontFamily, m_FontSize, style);
	}
	else
	{
		m_Font = new Font(FontFamily::GenericSansSerif(), m_FontSize, style);
	}

	status = m_Font->GetLastStatus();
	if(Ok != status)
	{
	    throw CError(std::string("Unable to create font: ") + m_FontFace, __LINE__, __FILE__);
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterString::ReadConfig(CMeterWindow& meterWindow, const char* section)
{
	char tmpName[256];

	// Read common configs
	CMeter::ReadConfig(meterWindow, section);

	CConfigParser& parser = meterWindow.GetParser();

	// Check for extra measures
	int i = 2;
	bool loop = true;
	do 
	{
		sprintf(tmpName, "MeasureName%i", i);
		std::string measure = parser.ReadString(section, tmpName, "");
		if (!measure.empty())
		{
			m_MeasureNames.push_back(measure);
		}
		else
		{
			loop = false;
		}
		i++;
	} while(loop);

	m_Color = parser.ReadColor(section, "FontColor", Color::Black);

	m_Prefix = parser.ReadString(section, "Prefix", "");
	m_Postfix = parser.ReadString(section, "Postfix", "");
	m_Text = parser.ReadString(section, "Text", "");

	m_AntiAlias = 0!=parser.ReadInt(section, "AntiAlias", 0);
	m_Percentual = 0!=parser.ReadInt(section, "Percentual", 0);
	m_AutoScale = 0!=parser.ReadInt(section, "AutoScale", 0);
	m_ClipString = 0!=parser.ReadInt(section, "ClipString", 0);

	m_FontSize = parser.ReadInt(section, "FontSize", 10);
	m_NumOfDecimals = parser.ReadInt(section, "NumOfDecimals", -1);

	std::string scale;
	scale = parser.ReadString(section, "Scale", "1");

	if(strchr(scale.c_str(), '.') == NULL)
	{
		m_NoDecimals = true;
	}
	else
	{
		m_NoDecimals = false;
	}
	m_Scale = atof(scale.c_str());

	m_FontFace = parser.ReadString(section, "FontFace", "Arial");

	std::string align;
	align = parser.ReadString(section, "StringAlign", "LEFT");

	if(_stricmp(align.c_str(), "LEFT") == 0)
	{
		m_Align = ALIGN_LEFT;
	}
	else if(_stricmp(align.c_str(), "RIGHT") == 0)
	{
		m_Align = ALIGN_RIGHT;
	}
	else if(_stricmp(align.c_str(), "CENTER") == 0)
	{
		m_Align = ALIGN_CENTER;
	}
	else
	{
        throw CError(std::string("No such StringAlign: ") + align, __LINE__, __FILE__);
	}

	std::string style;
	style = parser.ReadString(section, "StringStyle", "NORMAL");

	if(_stricmp(style.c_str(), "NORMAL") == 0)
	{
		m_Style = NORMAL;
	}
	else if(_stricmp(style.c_str(), "BOLD") == 0)
	{
		m_Style = BOLD;
	}
	else if(_stricmp(style.c_str(), "ITALIC") == 0)
	{
		m_Style = ITALIC;
	}
	else if(_stricmp(style.c_str(), "BOLDITALIC") == 0)
	{
		m_Style = BOLDITALIC;
	}
	else
	{
        throw CError(std::string("No such StringStyle: ") + style, __LINE__, __FILE__);
	}
}

/*
** Update
**
** Updates the value(s) from the measures.
**
*/
bool CMeterString::Update(CMeterWindow& meterWindow)
{
	if (CMeter::Update(meterWindow) && m_Measure)
	{
		int decimals = (m_NoDecimals && !m_AutoScale) ? 0 : 1;
		if (m_NumOfDecimals != -1) decimals = m_NumOfDecimals;

		m_StringValues.clear();
		if (m_Measure) m_StringValues.push_back(m_Measure->GetStringValue(m_AutoScale, m_Scale, decimals, m_Percentual));

		// Get the values for the other measures
		for (int i = 0; i < m_Measures.size(); i++)
		{
			m_StringValues.push_back(m_Measures[i]->GetStringValue(m_AutoScale, m_Scale, decimals, m_Percentual));
		}
		return true;
	}
	return false;
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
bool CMeterString::Draw(CMeterWindow& meterWindow)
{
	if(!CMeter::Draw(meterWindow)) return false;
		
	Graphics graphics(meterWindow.GetDoubleBuffer());
	StringFormat stringFormat;
	
	if (m_AntiAlias)
	{
		graphics.SetTextRenderingHint(TextRenderingHintAntiAlias);
	}
	else
	{
		graphics.SetTextRenderingHint(TextRenderingHintSystemDefault);
	}

	switch(m_Align)
	{
	case ALIGN_CENTER:
		stringFormat.SetAlignment(StringAlignmentCenter);
		break;

	case ALIGN_RIGHT:
		stringFormat.SetAlignment(StringAlignmentFar);
		break;

	case ALIGN_LEFT:
		stringFormat.SetAlignment(StringAlignmentNear);
		break;
	}

	std::string text;


	text = m_Prefix;
	if (m_Text.empty())
	{
		if (m_StringValues.size() > 0)
		{
			text += m_StringValues[0]; 
		}
	}
	else
	{
		char buffer[256];
		// Create the actual text (i.e. replace %1, %2, .. with the measure texts)
		std::string tmpText = m_Text;

		for (int i = 0; i < m_StringValues.size(); i++)
		{
			sprintf(buffer, "%%%i", i + 1);

			int start = 0;
			int pos = -1;

			do 
			{
				pos = tmpText.find(buffer, start);
				if (pos != -1)
				{
					tmpText.replace(tmpText.begin() + pos, tmpText.begin() + pos + strlen(buffer), m_StringValues[i]);
					start = pos + m_StringValues[i].length();
				}
			} while(pos != -1);
		}

		text += tmpText;
	}
	text += m_Postfix;

	PointF point(m_X, m_Y);
	SolidBrush solidBrush(m_Color);

	WCHAR* wideSz = ConvertToWide(text.c_str());

	if (m_ClipString)
	{
		RectF rc(m_X, m_Y, m_W, m_H);
		stringFormat.SetTrimming(StringTrimmingEllipsisCharacter);
		graphics.DrawString(wideSz, -1, m_Font, rc, &stringFormat, &solidBrush);
	}
	else
	{
		graphics.DrawString(wideSz, -1, m_Font, point, &stringFormat, &solidBrush);
	}

	delete [] wideSz;

	return true;
}

/*
** BindMeasure
**
** Overridden method. The string meters need not to be bound on anything
**
*/
void CMeterString::BindMeasure(std::list<CMeasure*>& measures)
{
	if (m_MeasureName.empty()) return;	// Allow NULL measure binding

	CMeter::BindMeasure(measures);

	std::vector<std::string>::iterator j = m_MeasureNames.begin();
	for (; j != m_MeasureNames.end(); j++)
	{
		// Go through the list and check it there is a secondary measures for us
		std::list<CMeasure*>::iterator i = measures.begin();
		for( ; i != measures.end(); i++)
		{
			if(_stricmp((*i)->GetName(), (*j).c_str()) == 0)
			{
				m_Measures.push_back(*i);
				break;
			}
		}
		
		if (i == measures.end())
		{
	        throw CError(std::string("The meter [") + m_Name + "] cannot be bound with [" + (*j) + "]!", __LINE__, __FILE__);
		}
	}
}
