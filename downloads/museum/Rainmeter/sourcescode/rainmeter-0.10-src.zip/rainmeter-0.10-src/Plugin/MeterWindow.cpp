/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterWindow.cpp,v 1.24 2004/06/05 10:55:54 rainy Exp $

  $Log: MeterWindow.cpp,v $
  Revision 1.24  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.23  2004/03/13 16:19:17  rainy
  Added support for multiple configs

  Revision 1.22  2003/12/05 15:50:10  Rainy
  Multi-instance changes.

  Revision 1.21  2003/02/10 18:11:33  rainy
  Too much changes to mention :-)

  Revision 1.20  2002/12/23 14:25:21  rainy
  Separated skin and other settings.
  Stats are now written in ini file.

  Revision 1.19  2002/07/01 15:27:36  rainy
  AlwaysOnTop gets now three values.
  Added Toggle().
  Added RainmeterCurrentConfig and RainmeterCurrentConfigIni.
  The ini file's timestamp is checked before it is overwritten.
  AboutBox is now in separate source file.
  Added SnapEdges.

  Revision 1.18  2002/05/05 10:48:56  rainy
  Fixed few bugs.

  Revision 1.17  2002/05/04 08:16:35  rainy
  There can be any number of ini files in the config folders.
  WM_COPYDATA can be used to deliver the bangs.
  Added support for per meter actions.

  Revision 1.16  2002/04/27 10:27:42  rainy
  Added hide/show to meters and enable/disable to measures

  Revision 1.15  2002/04/01 15:36:10  rainy
  Added PLAY, PLAYSTOP and PLAYLOOP build-in commands.

  Revision 1.14  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.13  2002/03/29 16:32:58  rainy
  Fixed a typo

  Revision 1.12  2002/01/16 16:06:29  rainy
  The file doesn't need to be named Rainmeter.ini anymore.
  If the old config doesn't exist, we'll yse the first one instead.

  Revision 1.11  2001/12/23 10:14:09  rainy
  Added support for different configs.
  The position of the window is now remembered.

  Revision 1.10  2001/10/28 10:15:21  rainy
  Added left and right mouse up actions.
  IsNT() can now identify different OS more precisely.

  Revision 1.9  2001/10/14 07:27:58  rainy
  Changed the errorhandling.
  Stats now include the date when they were started to collect.

  Revision 1.8  2001/09/26 16:25:44  rainy
  Added support for statistics.
  Meters and Measures are now stored here.

  Revision 1.7  2001/09/01 12:57:13  rainy
  Added support for Bar and Bitmap meters.

  Revision 1.6  2001/08/25 18:08:34  rainy
  Added mousebutton actions.
  The About dialog has now the build date.

  Revision 1.5  2001/08/25 17:15:52  rainy
  Added context menu, which can show the about dialog, refresh the configuration or quit the program.
  The ini-file can be defined in the step.rc also.

  Revision 1.4  2001/08/19 09:43:29  rainy
  Mouse over hid the window even if it was not wanted.

  Revision 1.3  2001/08/19 09:12:12  rainy
  Added support for GetRevID.
  Added StartHidden.

  Revision 1.2  2001/08/12 15:36:55  Rainy
  The ini-file's exsistance is checked.
  Added String meter.
  Improved mouse over hiding.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#pragma warning(disable: 4786)

#include <windows.h>
#include <gdiplus.h>
#include "MeterWindow.h"
#include "Rainmeter.h"
#include "Error.h"
#include <math.h>
#include <time.h>
#include "Meter.h"
#include "Measure.h"
#include "AboutDialog.h"
#include "resource.h"
#include "Litestep.h"
#include <Mmsystem.h>
#include <assert.h>
#include <tchar.h>
#include "MeasureCalc.h"
#include "MeasureNet.h"

using namespace Gdiplus;

#define ULW_ALPHA               0x00000002
#define WS_EX_LAYERED           0x00080000

#define METERTIMER 1
#define MOUSETIMER 2

#define SNAPDISTANCE 10

int CMeterWindow::m_InstanceCount = 0;

/* 
** CMeterWindow
**
** Constructor
**
*/
CMeterWindow::CMeterWindow(std::string& config, std::string& iniFile)
{
	m_Background = NULL;
	m_DoubleBuffer = NULL;
	m_Window = NULL;

	m_WindowX = 0;
	m_WindowY = 0;
	m_WindowW = 0;
	m_WindowH = 0;
	m_WindowZPosition = ZPOSITION_NORMAL;
	m_WindowDraggable = false;
	m_WindowUpdate = 1000;
	m_WindowHide = false;
	m_Hidden = false;
	m_WindowStartHidden = false;
	m_SnapEdges = true;
	m_Rainmeter = NULL;
	m_ResetRegion = false;
	m_Refreshing = false;
	m_NativeTransparency = true;
	m_MeasuresToVariables = false;
	m_AllowNegativeCoordinates = true;
	m_SavePosition = false;
	m_AlphaValue = 255;
	m_ClickThrough = false;

	m_MouseOver = false;

	m_BackgroundMode = BGMODE_IMAGE;
	m_SolidBevel = BEVELTYPE_NONE;

	m_SkinName = config;
	m_SkinIniFile = iniFile;

	m_User32Library = LoadLibrary("user32.dll");

	m_InstanceCount++;
}

/* 
** ~CMeterWindow
**
** Destructor
**
*/
CMeterWindow::~CMeterWindow()
{
	WriteConfig();

	// Destroy the measures
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		delete (*i);
	}

	// Destroy the meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		delete (*j);
	}

	if(m_Background) delete m_Background;
	if(m_DoubleBuffer) delete m_DoubleBuffer;

	if(m_Window) DestroyWindow(m_Window);

	FreeLibrary(m_User32Library);

	m_InstanceCount--;

	if (m_InstanceCount == 0)
	{
		BOOL Result;
		int counter = 0;
		do {
			// Wait for the window to die
			Result = UnregisterClass("RainmeterMeterWindow", m_Rainmeter->GetInstance());
			Sleep(100);
			counter += 1;
		} while(!Result && counter < 10);
	}
}

/* 
** Initialize
**
** Initializes the window, creates the class and the window.
**
*/
int CMeterWindow::Initialize(CRainmeter& Rainmeter, HWND Parent)
{
	int flags;
	WNDCLASSEX wc;

	m_Rainmeter = &Rainmeter;

	// Register the windowclass
	memset(&wc, 0, sizeof(WNDCLASSEX));
	wc.style = CS_NOCLOSE;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.lpfnWndProc = WndProc;
	wc.hInstance = m_Rainmeter->GetInstance();
	wc.lpszClassName = "RainmeterMeterWindow";
	
	if(!RegisterClassEx(&wc))
	{
		if (ERROR_CLASS_ALREADY_EXISTS != GetLastError())
		{
			throw CError(CError::ERROR_REGISTER_WINDOWCLASS, __LINE__, __FILE__);
		}
	}

	if(Rainmeter.IsWharfData())
	{
		// If we're in lsBox or in wharf, this is a childwindow
		flags = WS_CHILD;
	}
	else
	{
		// ... otherwise this is normal popup window
		flags = WS_POPUP;
		Parent = NULL;
	}

	m_Window = CreateWindowEx(WS_EX_TOOLWINDOW,
							"RainmeterMeterWindow", 
							NULL, 
							flags,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							Parent,
							NULL,
							m_Rainmeter->GetInstance(),
							this);

	if(m_Window == NULL) 
	{ 
		throw CError(CError::ERROR_CREATE_WINDOW, __LINE__, __FILE__);
	}

	SetWindowLong(m_Window, GWL_USERDATA, magicDWord);

	setlocale(LC_NUMERIC, "C");

	Refresh(true);

	LSLog(LOG_DEBUG, "Rainmeter", "Initialization successful.");

	return 0;
}

/*
** Refresh
**
** This deletes everything and rebuilds the config again.
**
*/
void CMeterWindow::Refresh(bool init)
{
	assert(m_Rainmeter != NULL);

	m_Rainmeter->SetCurrentParser(&m_Parser);

	std::string dbg = "Refreshing (Name: " + m_SkinName;
	dbg += " �ni: " + m_SkinIniFile; 
	dbg += ")"; 
	LSLog(LOG_DEBUG, "Rainmeter", dbg.c_str());
	
	m_Refreshing = true;

	if(!init)
	{
		// First destroy everything
		WriteConfig();

		ShowWindow(m_Window, SW_HIDE);
		
		KillTimer(m_Window, METERTIMER);	// Kill the timer
		KillTimer(m_Window, MOUSETIMER);	// Kill the timer

		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			delete (*i);
		}
		m_Measures.clear();

		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			delete (*j);
		}
		m_Meters.clear();

		if(m_Background) delete m_Background;
		m_Background = NULL;
		if(m_DoubleBuffer) delete m_DoubleBuffer;
		m_DoubleBuffer = NULL;

		m_BackgroundName.erase();
	}

	ReadConfig();	// Read the general settings

	char currentDir[MAX_LINE_LENGTH];
	GetCurrentDirectory(MAX_LINE_LENGTH, currentDir);

	// Set the current directory so that the graphics can be found
	std::string skinPath = m_Rainmeter->GetSkinPath().c_str() + m_SkinName;
	SetCurrentDirectory(skinPath.c_str());

	ReadSkin();

	InitializeMeters();

	// Make the current folder like it was before so that we don't break anything
	SetCurrentDirectory(currentDir);

	ChangeZPos(m_WindowZPosition);

	LONG style = GetWindowLong(m_Window, GWL_EXSTYLE);
	if (m_ClickThrough)
	{
		SetWindowLong(m_Window, GWL_EXSTYLE, style | WS_EX_TRANSPARENT);
	}
	else
	{
		SetWindowLong(m_Window, GWL_EXSTYLE, style & ~WS_EX_TRANSPARENT);
	}

	UINT flags;
	if(m_WindowStartHidden && init)
	{
		flags = 0;
	}
	else
	{
		flags = SWP_NOACTIVATE | SWP_SHOWWINDOW;
	}

	flags |= SWP_NOZORDER;

	SetWindowPos(m_Window, NULL, m_WindowX, m_WindowY, m_WindowW, m_WindowH, flags);

	// Set the window region
	CreateRegion(true);	// Clear the region
	Redraw();
	CreateRegion(false);

	// Start the timers
	if(0 == SetTimer(m_Window, METERTIMER, m_WindowUpdate, NULL))
	{
		throw CError("Unable to create a timer!", __LINE__, __FILE__);
	}

	if (m_WindowHide || m_WindowZPosition == ZPOSITION_ONTOPMOST || !m_MouseLeaveAction.empty() || !m_MouseOverAction.empty())
	{
		if(0 == SetTimer(m_Window, MOUSETIMER, 500, NULL))	// Mouse position is checked twice per sec
		{
			throw CError("Unable to create a timer!", __LINE__, __FILE__);
		}
	}

	UpdateTransparency(true);

	m_Rainmeter->SetCurrentParser(NULL);

	m_Refreshing = false;
}

/*
** MoveWindow
**
** Moves the window to a new place
**
*/
void CMeterWindow::MoveWindow(int x, int y)
{
	if (!m_AllowNegativeCoordinates)
	{
		RECT r;
		GetClientRect(GetDesktopWindow(), &r); 
		if(x < 0) x += r.right;
		if(y < 0) y += r.bottom;
	}

	SetWindowPos(m_Window, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);

	if (m_SavePosition)
	{
		WriteConfig();
	}
}

/*
** ChangeZPos
**
** Sets the window's z-position
**
*/
void CMeterWindow::ChangeZPos(ZPOSITION zPos)
{
	if(!m_Rainmeter->IsWharfData())
	{
		HWND parent = GetParent(m_Window);
		HWND winPos = HWND_NOTOPMOST;
		m_WindowZPosition = zPos;

		switch (zPos)
		{
		case ZPOSITION_ONTOPMOST:
		case ZPOSITION_ONTOP:
			winPos = HWND_TOPMOST;
 			break;

		case ZPOSITION_ONBOTTOM:
			 winPos = HWND_BOTTOM;
			 break;

		case ZPOSITION_ONDESKTOP:
			// Set the window's parent to progman, so it stays always on desktop
			HWND ProgmanHwnd = FindWindow("Progman", "Program Manager");
			if (ProgmanHwnd && (parent != ProgmanHwnd))
			{
				SetParent(m_Window, ProgmanHwnd);
			}
			else
			{
				return;		// The window is already on desktop
			}
			break;
		}

		if (zPos != ZPOSITION_ONDESKTOP && (parent != NULL))
		{
			SetParent(m_Window, NULL);
		}

		SetWindowPos(m_Window, winPos, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	}
}

void CMeterWindow::RunBang(BANGCOMMAND bang, const char* arg)
{
	char* pos = NULL;
	char* pos2 = NULL;

	if (!m_Window) return;

	switch(bang) 
	{
	case BANG_REFRESH:
		Refresh(false);
		break;

	case BANG_REDRAW:
		Redraw();
		break;

	case BANG_TOGGLEMETER:
		ToggleMeter(arg);
		break;

	case BANG_SHOWMETER:
		ShowMeter(arg);
		break;

	case BANG_HIDEMETER:
		HideMeter(arg);
		break;

	case BANG_TOGGLEMEASURE:
		ToggleMeasure(arg);
		break;

	case BANG_ENABLEMEASURE:
		EnableMeasure(arg);
		break;

	case BANG_DISABLEMEASURE:
		DisableMeasure(arg);
		break;

	case BANG_SHOW:
		ShowWindow(m_Window, SW_SHOWNOACTIVATE);
		break;

	case BANG_HIDE:
		ShowWindow(m_Window, SW_HIDE);
		break;

	case BANG_TOGGLE:
		if (IsWindowVisible(m_Window))
		{
			ShowWindow(m_Window, SW_HIDE);
		}
		else
		{
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
		}
		break;

	case BANG_MOVE:
		pos = strchr(arg, ' ');
		if (pos != NULL)
		{
			MoveWindow(atoi(arg), atoi(pos));
		}
		else
		{
			DebugLog("Cannot parse parameters for !RainmeterMove");
		}
		break;

	case BANG_ZPOS:
		ChangeZPos((ZPOSITION)atoi(arg));
		break;

	case BANG_LSHOOK:
		{
			HWND hWnd = (HWND)atoi(arg);
			if (hWnd) 
			{
				// Disable native transparency
				m_NativeTransparency = false;
				UpdateTransparency(true);
				SetWindowLong(m_Window, GWL_STYLE, (GetWindowLong(m_Window, GWL_STYLE) &~ WS_POPUP) | WS_CHILD);
				SetParent(m_Window, hWnd);
			}
		}
		break;

	case BANG_ABOUT:
		OpenAboutDialog(m_Window, m_Rainmeter->GetInstance());
		break;

	case BANG_MOVEMETER:
		pos = strchr(arg, ' ');
		if (pos != NULL)
		{
			pos2 = strchr(pos + 1, ' ');
			if (pos2 != NULL)
			{
				MoveMeter(atoi(arg), atoi(pos), pos2 + 1);
			}
			else
			{
				DebugLog("Cannot parse the for !RainmeterMoveMeter");
			}
		}
		else
		{
			DebugLog("Cannot parse the coordinates for !RainmeterMoveMeter");
		}
		break;
	}
}

/*
** ShowMeter
**
** Shows the given meter
**
*/
void CMeterWindow::ShowMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->Show();
			m_ResetRegion = true;	// Need to recalculate the window region
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** HideMeter
**
** Hides the given meter
**
*/
void CMeterWindow::HideMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->Hide();
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** ToggleMeter
**
** Toggles the given meter
**
*/
void CMeterWindow::ToggleMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			if ((*j)->IsHidden())
			{
				(*j)->Show();
			}
			else
			{
				(*j)->Hide();
			}
			m_ResetRegion = true;	// Need to recalculate the window region
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** MoveMeter
**
** Moves the given meter
**
*/
void CMeterWindow::MoveMeter(int x, int y, const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->SetX(x);
			(*j)->SetY(y);
			m_ResetRegion = true;
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}
/*
** EnableMeasure
**
** Enables the given measure
**
*/
void CMeterWindow::EnableMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			(*i)->Enable();
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** DisableMeasure
**
** Disables the given measure
**
*/
void CMeterWindow::DisableMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			(*i)->Disable();
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** ToggleMeasure
**
** Toggless the given measure
**
*/
void CMeterWindow::ToggleMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			if ((*i)->IsDisabled())
			{
				(*i)->Enable();
			}
			else
			{
				(*i)->Disable();
			}
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** ReadConfig
**
** Reads the current config
**
*/
void CMeterWindow::ReadConfig()
{
	std::string iniFile = m_Rainmeter->GetIniFile();
	const char* section = "Rainmeter";

	CConfigParser parser;
	parser.Initialize(iniFile.c_str());

	for (int i = 0; i < 2; i++)
	{
		m_WindowX = parser.ReadInt(section, "WindowX", m_WindowX);
		m_WindowY = parser.ReadInt(section, "WindowY", m_WindowY);

		if (!m_Rainmeter->GetDummyLitestep())
		{
			// Check if step.rc has overrides these values
			m_WindowX = GetRCInt("RainmeterWindowX", m_WindowX);
			m_WindowY = GetRCInt("RainmeterWindowY", m_WindowY);
		}

		if(m_WindowX != 0 || m_WindowY != 0)
		{
			// TODO: check that pt is somewhere on screen
		}

		int zPos = parser.ReadInt(section, "AlwaysOnTop", m_WindowZPosition);
		if (zPos == -1)
		{
			m_WindowZPosition = ZPOSITION_ONBOTTOM;
		}
		else if (zPos == 1)
		{
			m_WindowZPosition = ZPOSITION_ONTOP;
		}
		else if (zPos == 2)
		{
			m_WindowZPosition = ZPOSITION_ONTOPMOST;
		}
		else
		{
			m_WindowZPosition = ZPOSITION_NORMAL;
		}


		m_WindowDraggable = 0!=parser.ReadInt(section, "Draggable", m_WindowDraggable);
		m_WindowHide = 0!=parser.ReadInt(section, "HideOnMouseOver", m_WindowHide);
		m_WindowStartHidden = 0!=parser.ReadInt(section, "StartHidden", m_WindowStartHidden);
		m_SavePosition = 0!=parser.ReadInt(section, "SavePosition", m_SavePosition);
		m_SnapEdges = 0!=parser.ReadInt(section, "SnapEdges", m_SnapEdges);
		m_MeasuresToVariables = 0!=parser.ReadInt(section, "MeasuresToVariables", m_MeasuresToVariables);
		m_AllowNegativeCoordinates = 0!=parser.ReadInt(section, "AllowNegativeCoordinates", m_AllowNegativeCoordinates);
		m_NativeTransparency = 0!=parser.ReadInt(section, "NativeTransparency", m_NativeTransparency);
		m_ClickThrough = 0!=parser.ReadInt(section, "ClickThrough", m_ClickThrough);

		m_AlphaValue = parser.ReadInt(section, "AlphaValue", m_AlphaValue);
		m_AlphaValue = min(255, m_AlphaValue);
		m_AlphaValue = max(0, m_AlphaValue);

		// Disable native transparency if not 2K/XP
		if(CRainmeter::IsNT() == PLATFORM_9X || CRainmeter::IsNT() == PLATFORM_NT4)
		{
			m_NativeTransparency = 0;
		}

		// On the second loop override settings from the skin's section
		section = m_SkinName.c_str();
	}
}

/*
** WriteConfig
**
** Writes the new settings to the config
**
*/
void CMeterWindow::WriteConfig()
{
	char buffer[256];
	std::string iniFile = m_Rainmeter->GetIniFile();
	const char* section = m_SkinName.c_str();

	if(!iniFile.empty())
	{
		// If position needs to be save, do so.
		if(m_SavePosition)
		{
			int x = m_WindowX, y = m_WindowY;
			if (!m_AllowNegativeCoordinates)
			{
				x = max(0, x);
				y = max(0, y);
			}

			sprintf(buffer, "%i", x);
			WritePrivateProfileString(section, "WindowX", buffer, iniFile.c_str());
			WritePrivateProfileString("Rainmeter", "WindowX", buffer, iniFile.c_str());
			sprintf(buffer, "%i", y);
			WritePrivateProfileString(section, "WindowY", buffer, iniFile.c_str());
			WritePrivateProfileString("Rainmeter", "WindowY", buffer, iniFile.c_str());
		}

		sprintf(buffer, "%i", m_AlphaValue);
		WritePrivateProfileString(section, "AlphaValue", buffer, iniFile.c_str());
		
		sprintf(buffer, "%i", m_ClickThrough);
		WritePrivateProfileString(section, "ClickThrough", buffer, iniFile.c_str());
		sprintf(buffer, "%i", m_WindowDraggable);
		WritePrivateProfileString(section, "Draggable", buffer, iniFile.c_str());
		sprintf(buffer, "%i", m_WindowHide);
		WritePrivateProfileString(section, "HideOnMouseOver", buffer, iniFile.c_str());
		sprintf(buffer, "%i", m_SavePosition);
		WritePrivateProfileString(section, "SavePosition", buffer, iniFile.c_str());
		sprintf(buffer, "%i", m_SnapEdges);
		WritePrivateProfileString(section, "SnapEdges", buffer, iniFile.c_str());

		sprintf(buffer, "%i", m_WindowZPosition);
		WritePrivateProfileString(section, "AlwaysOnTop", buffer, iniFile.c_str());
	}
}


/*
** ReadSkin
**
** Reads the skin config, creates the meters and measures and does the bindings.
**
*/
void CMeterWindow::ReadSkin()
{
	char buffer[MAX_LINE_LENGTH];

	std::string iniFile = m_Rainmeter->GetSkinPath();
	iniFile += m_SkinName;
	iniFile += "\\";
	iniFile += m_SkinIniFile;

	m_Parser.Initialize(iniFile.c_str());

	// Global settings

	// Check the version 
	int appVersion = m_Parser.ReadInt("Rainmeter", "AppVersion", 0);
	if (appVersion > RAINMETER_VERSION)
	{
		char buffer[256];
		std::string text;
		sprintf(buffer, "%i.%i", appVersion / 1000, appVersion % 1000);
		text = "This skin needs Rainmeter version 0.";
		text += buffer;
		text += " or newer.\nIt might not function as well as it should.\nYou should get an updated version or Rainmeter\nfrom http://www.iki.fi/rainy";
		MessageBox(m_Window, text.c_str(), "Rainmeter", MB_OK);
	}

	m_Author = m_Parser.ReadString("Rainmeter", "Author", "");
	m_BackgroundName = m_Parser.ReadString("Rainmeter", "Background", "");

	m_BackgroundMode = (BGMODE)m_Parser.ReadInt("Rainmeter", "BackgroundMode", 0);
	m_SolidBevel = (BEVELTYPE)m_Parser.ReadInt("Rainmeter", "BevelType", m_SolidBevel);

	m_SolidColor = m_Parser.ReadColor("Rainmeter", "SolidColor", Color::Gray);

	if (m_BackgroundMode == BGMODE_IMAGE && m_BackgroundName.empty())
	{
		m_BackgroundMode = BGMODE_COPY;
	}

	m_RightMouseDownAction = m_Parser.ReadString("Rainmeter", "RightMouseDownAction", "");
	m_LeftMouseDownAction = m_Parser.ReadString("Rainmeter", "LeftMouseDownAction", "");
	m_RightMouseUpAction = m_Parser.ReadString("Rainmeter", "RightMouseUpAction", "");
	m_LeftMouseUpAction = m_Parser.ReadString("Rainmeter", "LeftMouseUpAction", "");
	m_MouseOverAction = m_Parser.ReadString("Rainmeter", "MouseOverAction", "");
	m_MouseLeaveAction = m_Parser.ReadString("Rainmeter", "MouseLeaveAction", "");

	m_WindowUpdate = m_Parser.ReadInt("Rainmeter", "Update", m_WindowUpdate);

	// Create the meters and measures

	// Get all the sections (i.e. different meters)
	GetPrivateProfileString( NULL, NULL, NULL, buffer, MAX_LINE_LENGTH, iniFile.c_str());
	char* pos = buffer;
	while(strlen(pos) > 0)
	{
		if(stricmp("Rainmeter", pos) != 0 && stricmp("Variables", pos) != 0)
		{
			std::string meterName, measureName;

			// Check if the item is a meter or a measure (or perhaps something else)
			measureName = m_Parser.ReadString(pos, "Measure", "");
			meterName = m_Parser.ReadString(pos, "Meter", "");
			if (measureName.length() > 0)
			{
				try
				{
					// It's a measure
					CMeasure* measure = CMeasure::Create(measureName.c_str());
					measure->SetName(pos);
					measure->ReadConfig(m_Parser, pos);
					m_Measures.push_back(measure);
				}
				catch (CError& error)
				{
					MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
				}
			}
			else if (meterName.length() > 0)
			{
				try
				{
					// It's a meter
					CMeter* meter = CMeter::Create(meterName.c_str());
					meter->SetName(pos);
					meter->ReadConfig(*this, pos);
					m_Meters.push_back(meter);
				}
				catch (CError& error)
				{
					MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
				}
			} 
			else
			{
				// It's something else
                throw CError(std::string("Section [") + pos + "] is not a meter or a measure!", __LINE__, __FILE__);
            }
		}
		pos = pos + strlen(pos) + 1;
	}

	if (m_Meters.empty())
	{
		MessageBox(m_Window, "Your configuration file doesn't contain any meters!\nYour skin's ini-file might be out of date.", APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}
	else
	{
		// Bind the meters to the measures
		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			try
			{
				(*j)->BindMeasure(m_Measures);
			}
			catch (CError& error)
			{
				MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
			}
		}
	}
}

/*
** InitializeMeters
**
** Initializes all the meters and the background
**
*/
void CMeterWindow::InitializeMeters()
{
	// Initalize all meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Initialize(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	// Handle negative coordinates
	if (!m_AllowNegativeCoordinates)
	{
		RECT r;
		GetClientRect(GetDesktopWindow(), &r); 
		if(m_WindowX < 0) m_WindowX += r.right;
		if(m_WindowY < 0) m_WindowY += r.bottom;
	}

	// Reset size (this is calculated below)
	m_WindowW = 0;
	m_WindowH = 0;

	if (m_BackgroundMode == BGMODE_IMAGE && !m_BackgroundName.empty())
	{
		// Load the background
		WCHAR* wideSz = CMeter::ConvertToWide(m_BackgroundName.c_str());
		m_Background = new Bitmap(wideSz);
		delete [] wideSz;

		Status status = m_Background->GetLastStatus();
		if(Ok != status)
		{
			throw CError(std::string("Unable to load background: ") + m_BackgroundName, __LINE__, __FILE__);
		}

		// Calculate the window dimensions
		if(m_Background)
		{
			// Get the size form the background bitmap
			m_WindowW = m_Background->GetWidth();
			m_WindowH = m_Background->GetHeight();

			if (!m_NativeTransparency)
			{
				// Graph the desktop and place the background on top of it
				Bitmap* desktop = GrabDesktop(m_WindowX, m_WindowY, m_WindowW, m_WindowH);
				Graphics graphics(desktop);
				Rect r(0, 0, m_WindowW, m_WindowH);
				graphics.DrawImage(m_Background, r, 0, 0, m_WindowW, m_WindowH, UnitPixel);
				delete m_Background;
				m_Background = desktop;
			}
		} 
	} 
	else
	{
		// No background -> Get the largest meter point
		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			m_WindowW = max(m_WindowW, (*j)->GetX() + (*j)->GetW());
			m_WindowH = max(m_WindowH, (*j)->GetY() + (*j)->GetH());
		}
	}

	if(m_WindowW == 0 || m_WindowH == 0)
	{
		throw CError("The window's dimensions are zero.", __LINE__, __FILE__);
	}

	// Create the double buffer (32 bit)
	m_DoubleBuffer = new Bitmap(m_WindowW, m_WindowH, PixelFormat32bppARGB);

	// If Background is not set, take a copy from the desktop
	if(m_Background == NULL) 
	{
		if (m_BackgroundMode == BGMODE_COPY)
		{
			if (m_NativeTransparency)
			{
				// Create a transparent background
				m_Background = new Bitmap(m_WindowW, m_WindowH, PixelFormat32bppARGB);
				Graphics graphics(m_Background);
				graphics.Clear(Color(0, 0, 0, 0));
			}
			else
			{
				m_Background = GrabDesktop(m_WindowX, m_WindowY, m_WindowW, m_WindowH);
			}
		}
		else
		{
			// Create a solid color bitmap for the background
			m_Background = new Bitmap(m_WindowW, m_WindowH, PixelFormat32bppARGB);
			Graphics graphics(m_Background);
			graphics.Clear(m_SolidColor);

			if (m_SolidBevel != BEVELTYPE_NONE)
			{
				Pen light(Color(255, 255, 255, 255));
				Pen dark(Color(255, 0, 0, 0));

				if (m_SolidBevel == BEVELTYPE_DOWN)
				{
					light.SetColor(Color(255, 0, 0, 0));
					dark.SetColor(Color(255, 255, 255, 255));
				}
				Rect rect(0, 0, m_WindowW, m_WindowH);	
				CMeter::DrawBevel(graphics, rect, light, dark);
			}
		}
	}
}

/*
** GrabDesktop
** 
** Grabs a part of the desktop
*/
Bitmap* CMeterWindow::GrabDesktop(int x, int y, int w, int h)
{
	// If the new way fails, use the old way
	HDC winDC = GetWindowDC(GetDesktopWindow());
	HDC tmpDC = CreateCompatibleDC(winDC);

	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = x;
	bmi.bmiHeader.biHeight = y;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = w * h * 4;
	
	// create our DIB section and select the bitmap into the dc
	VOID* bits;
	HBITMAP wallpaper = CreateDIBSection(winDC, &bmi, DIB_RGB_COLORS, &bits, NULL, 0x0);

	// Fetch the background
	HBITMAP OldBitmap = (HBITMAP)SelectObject(tmpDC, wallpaper);
	BitBlt(tmpDC, 0, 0, w, h, winDC, x, y, SRCCOPY);
	
	ReleaseDC(GetDesktopWindow(), winDC);

	SelectObject(tmpDC, OldBitmap);
	DeleteDC(tmpDC);

	Bitmap* tmpBitmap = new Bitmap(wallpaper, NULL);
	Bitmap* background = new Bitmap(w, h, PixelFormat32bppARGB);
	Graphics graphics(background);
	Rect r(0, 0, w, h);
	graphics.DrawImage(tmpBitmap, r, 0, 0, w, h, UnitPixel);
	delete tmpBitmap;
	DeleteObject(wallpaper);

	return background;
}

/*
** CreateRegion
**
** Creates/Clears a window region
**
*/
void CMeterWindow::CreateRegion(bool clear)
{
	if (clear)
	{
		SetWindowRgn(m_Window, NULL, TRUE);
	}
	else
	{
		// Set window region if needed
		if(!m_BackgroundName.empty()) 
		{
			HBITMAP bitmap;
			m_DoubleBuffer->GetHBITMAP(Color(255, 255, 255, 255), &bitmap);
			HRGN region = BitmapToRegion(bitmap, RGB(255,0,255), 0x101010, 0, 0);
			SetWindowRgn(m_Window, region, TRUE);
			DeleteObject(bitmap);
		}
	}
}

/*
** Redraw
**
** Redraws the meters and paints the window
**
*/
void CMeterWindow::Redraw() 
{
	if (m_ResetRegion) CreateRegion(true);

	Graphics graphics(m_DoubleBuffer);
	graphics.SetCompositingMode(CompositingModeSourceCopy);

	// Copy the background over the doublebuffer
	Rect r(0, 0, m_WindowW, m_WindowH);
	graphics.DrawImage(m_Background, r, 0, 0, m_WindowW, m_WindowH, UnitPixel);

	// Draw the meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Draw(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}
	
	if (m_ResetRegion) CreateRegion(false);
	m_ResetRegion = false;

	UpdateTransparency(false);

	if (!m_NativeTransparency)
	{
		// Just blit the doublebuffer to the window
		HDC winDC = GetWindowDC(m_Window);
		Graphics graphics2(winDC);
		graphics2.DrawImage(m_DoubleBuffer, 0, 0);
		ReleaseDC(m_Window, winDC);
	}
}

/*
** Update
**
** Updates all the measures and redraws the meters
**
*/
void CMeterWindow::Update()
{
	// Pre-updates
	CMeasureNet::UpdateIFTable();
	CMeasureCalc::UpdateVariableMap(*this);

	// Update all measures
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		try
		{
			(*i)->Update(this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	// Update the meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Update(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	// Statistics
	CMeasureNet::UpdateStats();

	Redraw();

//	if (m_MeasuresToVariables)	// BUG: LSSetVariable doens't seem to work for some reason.
//	{
//		std::list<CMeasure*>::iterator i = m_Measures.begin();
//		for( ; i != m_Measures.end(); i++)
//		{
//			const char* sz = (*i)->GetStringValue(true, 1, 1, false);
//			if (sz && strlen(sz) > 0)
//			{
//				WCHAR* wideSz = CMeter::ConvertToWide(sz);
//				WCHAR* wideName = CMeter::ConvertToWide((*i)->GetName());
//				LSSetVariable(wideName, wideSz);
//				delete [] wideSz;
//				delete [] wideName;
//			}
//		}
//	}
}

/*
** UpdateTransparency
**
** Updates the native Windows transparency
*/
void CMeterWindow::UpdateTransparency(bool reset)
{
	if (m_NativeTransparency)
	{
		if (reset)
		{
			// Add the window flag
			LONG style = GetWindowLong(m_Window, GWL_EXSTYLE);
			SetWindowLong(m_Window, GWL_EXSTYLE, style | WS_EX_LAYERED);
		}

		RECT r;
		GetWindowRect(m_Window, &r);

		typedef BOOL (WINAPI * FPUPDATELAYEREDWINDOW)(HWND hWnd, HDC hdcDst, POINT *pptDst, SIZE *psize, HDC hdcSrc, POINT *pptSrc, COLORREF crKey, BLENDFUNCTION *pblend, DWORD dwFlags);
		FPUPDATELAYEREDWINDOW UpdateLayeredWindow = (FPUPDATELAYEREDWINDOW)GetProcAddress(m_User32Library, "UpdateLayeredWindow");

		BLENDFUNCTION blendPixelFunction= {AC_SRC_OVER, 0, m_AlphaValue, AC_SRC_ALPHA};
		POINT ptWindowScreenPosition = {r.left, r.top};
		POINT ptSrc = {0, 0};
		SIZE szWindow = {m_WindowW, m_WindowH};
		
		HDC dcScreen = GetDC(GetDesktopWindow());
		HDC dcMemory = CreateCompatibleDC(dcScreen);

		HBITMAP dbBitmap;
		m_DoubleBuffer->GetHBITMAP(Color(0, 0, 0, 0), &dbBitmap);
		HBITMAP oldBitmap = (HBITMAP)SelectObject(dcMemory, dbBitmap);
		UpdateLayeredWindow(m_Window, dcScreen, &ptWindowScreenPosition, &szWindow, dcMemory, &ptSrc, 0, &blendPixelFunction, ULW_ALPHA);
		ReleaseDC(GetDesktopWindow(), dcScreen);
		SelectObject(dcMemory, oldBitmap);
		DeleteDC(dcMemory);
		DeleteObject(dbBitmap);
	}
	else
	{
		if (reset)
		{
			// Remove the window flag
			LONG style = GetWindowLong(m_Window, GWL_EXSTYLE);
			SetWindowLong(m_Window, GWL_EXSTYLE, style & ~WS_EX_LAYERED);
		}
	}
}

/*
** OnPaint
**
** Repaints the window. This does not cause update of the measures.
**
*/
LRESULT CMeterWindow::OnPaint(WPARAM wParam, LPARAM lParam) 
{
	PAINTSTRUCT ps;
	HDC winDC = BeginPaint(m_Window, &ps);

	Graphics graphics(winDC);
	graphics.DrawImage(m_DoubleBuffer, 0, 0);

	EndPaint(m_Window, &ps);
	return 0;
}

/*
** OnTimer
**
** Handles the timers. The METERTIMER updates all the measures 
** MOUSETIMER is used to hide/show the window.
**
*/
LRESULT CMeterWindow::OnTimer(WPARAM wParam, LPARAM lParam) 
{
	static int Count=1;

	if(wParam == METERTIMER) 
	{
		Update();
		UpdateAboutStatistics();
	}
	else if(wParam == MOUSETIMER)
	{
		ShowWindowIfAppropriate();

		// Check mouse leave actions
		POINT pos;
		GetCursorPos(&pos);
		MapWindowPoints(NULL, m_Window, &pos, 1);
		DoAction(pos.x, pos.y, MOUSE_LEAVE, false);

		if (m_WindowZPosition == ZPOSITION_ONTOPMOST)
		{
			ChangeZPos(ZPOSITION_ONTOPMOST);
		}
	}

	return 0;
}

/*
** ShowWindowIfAppropriate
**
** Show the window if it is temporarily hidden.
**
*/
void CMeterWindow::ShowWindowIfAppropriate()
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not show the window
			return;
		}

		bool inside = false;
		POINT pos;
		RECT rect;

		GetCursorPos(&pos);
		GetWindowRect(m_Window, &rect);

		if(rect.left <= pos.x && rect.right >= pos.x &&
		   rect.top <= pos.y && rect.bottom >= pos.y) inside = true;

		if(m_Hidden && !inside)
		{
			// Show window
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
			m_Hidden = false;
		}
	}
}

/*
** CheckMouseLeave
**
** Show the window if it is temporarily hidden.
**
*/
void CMeterWindow::CheckMouseLeave()
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not show the window
			return;
		}

		bool inside = false;
		POINT pos;
		RECT rect;

		GetCursorPos(&pos);
		GetWindowRect(m_Window, &rect);

		if(rect.left <= pos.x && rect.right >= pos.x &&
		   rect.top <= pos.y && rect.bottom >= pos.y) inside = true;

		if(m_Hidden && !inside)
		{
			// Show window
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
			m_Hidden = false;
		}
	}
}

/*
** OnMouseMove
**
** When we get WM_MOUSEMOVE messages, hide the window as the mouse is over it.
**
*/
LRESULT CMeterWindow::OnMouseMove(WPARAM wParam, LPARAM lParam) 
{
	if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
	{
		// If Alt, shift or control is down, do not hide the window
		return 0;
	}

	if(m_WindowHide)
	{
		// Hide window if it is visible
		if(IsWindowVisible(m_Window))
		{
			ShowWindow(m_Window, SW_HIDE);
			m_Hidden = true;
		}
	}

	POINT pos;
	pos.x = LOWORD(lParam);
	pos.y = HIWORD(lParam);

	// Map to local window
	MapWindowPoints(GetDesktopWindow(), m_Window, &pos, 1);
	
	DoAction(pos.x, pos.y, MOUSE_OVER, false);

	return 0;
}

/*
** OnCreate
**
** During window creation we do nothing.
**
*/
LRESULT CMeterWindow::OnCreate(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/*
** OnCommand
**
** Handle the menu commands.
**
*/
LRESULT CMeterWindow::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	try 
	{
		if(wParam == ID_CONTEXT_SKINMENU_EDITSKIN)
		{
			std::string command = m_Rainmeter->GetConfigEditor();
			command += " \"";
			command += m_Rainmeter->GetSkinPath() + "\\" + m_SkinName + "\\" + m_SkinIniFile + "\"";
			ExecuteCommand(command.c_str());
		}
		else if(wParam == ID_CONTEXT_SKINMENU_REFRESH)
		{
			Refresh(false);
		} 
		else if(wParam == ID_CONTEXT_SKINMENU_VERYTOPMOST)
		{
			ChangeZPos(ZPOSITION_ONTOPMOST);
			WriteConfig();
			Refresh(false);		// This needs the timer
		}
		else if(wParam == ID_CONTEXT_SKINMENU_TOPMOST)
		{
			ChangeZPos(ZPOSITION_ONTOP);
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_BOTTOM)
		{
			ChangeZPos(ZPOSITION_ONBOTTOM);
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_NORMAL)
		{
			ChangeZPos(ZPOSITION_NORMAL);
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_ONDESKTOP)
		{
			ChangeZPos(ZPOSITION_ONDESKTOP);
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_CLICKTHROUGH)
		{
			m_ClickThrough = !m_ClickThrough;
			WriteConfig();
			Refresh(false);
		}
		else if(wParam == ID_CONTEXT_SKINMENU_DRAGGABLE)
		{
			m_WindowDraggable = !m_WindowDraggable;
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_HIDEONMOUSE)
		{
			m_WindowHide = !m_WindowHide;
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_REMEMBERPOSITION)
		{
			m_SavePosition = !m_SavePosition;
			WriteConfig();
		}
		else if(wParam == ID_CONTEXT_SKINMENU_SNAPTOEDGES)
		{
			m_SnapEdges = !m_SnapEdges;
			WriteConfig();
		}
		else if(wParam >= ID_CONTEXT_SKINMENU_TRANSPARENCY_0 && wParam <= ID_CONTEXT_SKINMENU_TRANSPARENCY_90)
		{
			m_AlphaValue = 255.0 - 230.0 * (double)(wParam - ID_CONTEXT_SKINMENU_TRANSPARENCY_0) / (double)(ID_CONTEXT_SKINMENU_TRANSPARENCY_90 - ID_CONTEXT_SKINMENU_TRANSPARENCY_0);
			Refresh(false);
		}
		else if(wParam == ID_CONTEXT_CLOSESKIN)
		{
			const std::vector<CRainmeter::CONFIG>& configs = m_Rainmeter->GetAllConfigs();

			for (int i = 0; i < configs.size(); i++)
			{
				if (configs[i].config == m_SkinName)
				{
					m_Rainmeter->DeactivateConfig(this, i);
					break;
				}
			}
		}
		else
		{
			// Forward to tray window, which handles all the other commands
			SendMessage(m_Rainmeter->GetTrayWindow()->GetWindow(), WM_COMMAND, wParam, lParam);
		}
	} 
    catch(CError& error) 
    {
		MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return 0;
}

/*
** OnNcHitTest
**
** This is overwritten so that the window can be dragged
**
*/
LRESULT CMeterWindow::OnNcHitTest(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowDraggable)
	{
		return HTCAPTION;
	}
	return HTCLIENT;
}

/*
** OnWindowPosChanging
**
** Called when windows position is about to change
**
*/
LRESULT CMeterWindow::OnWindowPosChanging(WPARAM wParam, LPARAM lParam) 
{
	LPWINDOWPOS wp=(LPWINDOWPOS)lParam;

	if(m_WindowZPosition == ZPOSITION_ONBOTTOM && !m_Refreshing)
	{
		// do not change the z-order. This keeps the window on bottom.
		wp->flags|=SWP_NOZORDER;
	}

	if (m_SnapEdges && !(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000))
	{
		RECT workArea;
		GetClientRect(GetDesktopWindow(), &workArea);

		// only process movement (ignore anything without winpos values)
		if(wp->cx != 0 && wp->cy != 0)
		{
			typedef HMONITOR (WINAPI * FPMONITORFROMWINDOW)(HWND wnd, DWORD dwFlags);
			typedef BOOL (WINAPI * FPGETMONITORINFO)(HMONITOR hMonitor, LPMONITORINFO lpmi);
			FPMONITORFROMWINDOW fpMonitorFromWindow;
			FPGETMONITORINFO fpGetMonitorInfo;

			HINSTANCE lib = LoadLibrary("user32.dll");
			
			fpMonitorFromWindow = (FPMONITORFROMWINDOW)GetProcAddress(lib, "MonitorFromWindow");
			fpGetMonitorInfo = (FPGETMONITORINFO)GetProcAddress(lib, "GetMonitorInfoA");

			if (fpMonitorFromWindow && fpGetMonitorInfo)
			{
				HMONITOR hMonitor;
				MONITORINFO mi;

				hMonitor = fpMonitorFromWindow(m_Window, MONITOR_DEFAULTTONULL);

				if(hMonitor != NULL)
				{
					mi.cbSize = sizeof(mi);
					fpGetMonitorInfo(hMonitor, &mi);
					workArea = mi.rcWork;
				}
			}

			FreeLibrary(lib);

			int w = workArea.right - m_WindowW;
			int h = workArea.bottom - m_WindowH;

			if((wp->x < SNAPDISTANCE + workArea.left) && (wp->x > workArea.left - SNAPDISTANCE)) wp->x = workArea.left;
			if((wp->y < SNAPDISTANCE + workArea.top) && (wp->y > workArea.top - SNAPDISTANCE)) wp->y = workArea.top;
			if ((wp->x < SNAPDISTANCE + w) && (wp->x > -SNAPDISTANCE + w)) wp->x = w;
			if ((wp->y < SNAPDISTANCE + h) && (wp->y > -SNAPDISTANCE + h)) wp->y = h;
		}
	}

	return DefWindowProc(m_Window, m_Message, wParam, lParam);
}

/*
** OnDestroy
**
** During destruction of the window do nothing.
**
*/
LRESULT CMeterWindow::OnDestroy(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/*
** ExecuteCommand
**
** Runs the given command or bang
**
*/
void CMeterWindow::ExecuteCommand(const char* command) 
{
	if (command == NULL) return;

	// Check for build-ins
	if (strncmp("PLAY ", command, 5) == 0)
	{
		BOOL ret = PlaySound(command + 5, NULL, SND_FILENAME);
		return;
	}
	else if (strncmp("PLAYSTOP", command, 8) == 0)
	{
		PlaySound(NULL, NULL, SND_PURGE);
		return;
	}
	else if (strncmp("PLAYLOOP ", command, 9) == 0)
	{
		PlaySound(command + 9, NULL, SND_ASYNC | SND_FILENAME | SND_LOOP | SND_NODEFAULT);
		return;
	}
	
	// Run the command
	if(command[0] == '!' && m_Rainmeter->GetDummyLitestep())
	{
		// Fake WM_COPY to deliver bangs
		COPYDATASTRUCT CopyDataStruct;
		CopyDataStruct.cbData = strlen(command) + 1;
		CopyDataStruct.dwData = 1;
		CopyDataStruct.lpData = (void*)command;
		OnCopyData(NULL, (LPARAM)&CopyDataStruct);
	}
	else
	{
		// This can run bangs also
		LSExecute(NULL, command, SW_SHOWNORMAL);
	}
}

/*
** OnLeftButtonDown
**
** Runs the action when left mouse button is down
**
*/
LRESULT CMeterWindow::OnLeftButtonDown(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCLBUTTONDOWN)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	if(!DoAction(x, y, MOUSE_LMB_DOWN, false))
	{
		// Run the DefWindowProc so the dragging works
		return DefWindowProc(m_Window, m_Message, wParam, lParam);
	}

	return 0;
}

/*
** OnLeftButtonUp
**
** Runs the action when left mouse button is up
**
*/
LRESULT CMeterWindow::OnLeftButtonUp(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCLBUTTONUP)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	DoAction(x, y, MOUSE_LMB_UP, false);

	return 0;
}

/*
** OnRightButtonDown
**
** Runs the action when right mouse button is down
**
*/
LRESULT CMeterWindow::OnRightButtonDown(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCRBUTTONDOWN)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	DoAction(x, y, MOUSE_RMB_DOWN, false);

	return 0;
}

/*
** OnRightButtonUp
**
** Runs the action when right mouse button is up
**
*/
LRESULT CMeterWindow::OnRightButtonUp(WPARAM wParam, LPARAM lParam) 
{
	if (!DoAction(LOWORD(lParam), HIWORD(lParam), MOUSE_RMB_UP, false))
	{
		// Run the DefWindowProc so the contextmenu works
		return DefWindowProc(m_Window, WM_RBUTTONUP, wParam, lParam);
	}

	return 0;
}

/*
** OnContextMenu
**
** Handles the context menu. The menu is recreated every time it is shown.
**
*/
LRESULT CMeterWindow::OnContextMenu(WPARAM wParam, LPARAM lParam) 
{
	int xPos = (short int)LOWORD(lParam); 
	int yPos = (short int)HIWORD(lParam); 

	// Transform the point to client rect
	int x = (INT)(SHORT)LOWORD(lParam); 
	int y = (INT)(SHORT)HIWORD(lParam); 
	RECT rect;
	GetWindowRect(m_Window, &rect);
	x = x - rect.left;
	y = y - rect.top;

	// If RMB up or RMB down cause actions, do not show the menu!
	if (DoAction(x, y, MOUSE_RMB_UP, false) || DoAction(x, y, MOUSE_RMB_DOWN, true))
	{
		return 0;
	}

	POINT pos;
	pos.x = xPos;
	pos.y = yPos;
	m_Rainmeter->ShowContextMenu(pos, this);

	return 0;
}

/*
** DoAction
**
** Executes the action if such are defined. Returns true, if action was executed.
** If the test is true, the action is not executed.
**
*/
bool CMeterWindow::DoAction(int x, int y, MOUSE mouse, bool test) 
{
	// Check if the hitpoint was over some meter
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		// Hidden meters are ignored
		if ((*j)->IsHidden()) continue;

		if (x >= (*j)->GetX() && x <= (*j)->GetX() + (*j)->GetW() &&
			y >= (*j)->GetY() && y <= (*j)->GetY() + (*j)->GetH())
		{
			switch (mouse)
			{
			case MOUSE_LMB_DOWN:
				if (!((*j)->GetLeftMouseDownAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetLeftMouseDownAction().c_str());
					return true;
				}
				break;

			case MOUSE_LMB_UP:
				if (!((*j)->GetLeftMouseUpAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetLeftMouseUpAction().c_str());
					return true;
				}
				break;

			case MOUSE_RMB_DOWN:
				if (!((*j)->GetRightMouseDownAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetRightMouseDownAction().c_str());
					return true;
				}
				break;

			case MOUSE_RMB_UP:
				if (!((*j)->GetRightMouseUpAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetRightMouseUpAction().c_str());
					return true;
				}
				break;

			case MOUSE_OVER:
				if (!(*j)->IsMouseOver())
				{
					(*j)->SetMouseOver(true);

					if (!((*j)->GetMouseOverAction().empty()))
					{
						m_MouseOver = true;		// If the mouse is over a meter it's also over the main window
						if (!test) ExecuteCommand((*j)->GetMouseOverAction().c_str());
						return true;
					}
				}
				break;
			}
		}
		else
		{
			if (mouse == MOUSE_LEAVE || mouse == MOUSE_OVER)
			{
				if ((*j)->IsMouseOver())
				{
					(*j)->SetMouseOver(false);

					if (!((*j)->GetMouseLeaveAction().empty()))
					{
						if (!test) ExecuteCommand((*j)->GetMouseLeaveAction().c_str());
						return true;
					}
				}
			}
		}
	}

	if (x >= 0 && y >= 0 && x < m_WindowW && y < m_WindowH)
	{
		// If no meters caused actions, do the default actions
		switch (mouse)
		{
		case MOUSE_LMB_DOWN:
			if (!m_LeftMouseDownAction.empty())
			{
				if (!test) ExecuteCommand(m_LeftMouseDownAction.c_str());
				return true;
			}
			break;

		case MOUSE_LMB_UP:
			if (!m_LeftMouseUpAction.empty())
			{
				if (!test) ExecuteCommand(m_LeftMouseUpAction.c_str());
				return true;
			}
			break;

		case MOUSE_RMB_DOWN:
			if (!m_RightMouseDownAction.empty())
			{
				if (!test) ExecuteCommand(m_RightMouseDownAction.c_str());
				return true;
			}
			break;

		case MOUSE_RMB_UP:
			if (!m_RightMouseUpAction.empty())
			{
				if (!test) ExecuteCommand(m_RightMouseUpAction.c_str());
				return true;
			}
			break;

		case MOUSE_OVER:
			if (!m_MouseOver)
			{
				m_MouseOver = true;
				if (!m_MouseOverAction.empty())
				{
					if (!test) ExecuteCommand(m_MouseOverAction.c_str());
					return true;
				}
			}
			break;
		}
	}
	else
	{
		// Mouse leave happens when the mouse is outside the window
		if (mouse == MOUSE_LEAVE)
		{
			if (m_MouseOver)
			{
				m_MouseOver = false;
				if (!m_MouseLeaveAction.empty())
				{
					if (!test) ExecuteCommand(m_MouseLeaveAction.c_str());
					return true;
				}
			}
		}
	}

	return false;
}


/*
** OnMove
**
** Stores the new place of the window so that it can be written in the config file.
**
*/
LRESULT CMeterWindow::OnMove(WPARAM wParam, LPARAM lParam) 
{
	// Store the new window position
	m_WindowX = (short int)LOWORD(lParam);
	m_WindowY = (short int)HIWORD(lParam);

	if (m_SavePosition)
	{
		WriteConfig();
	}

	return 0;
}

/* 
** WndProc
**
** The window procedure for the Meter
**
*/
LRESULT CALLBACK CMeterWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	CMeterWindow* Window = NULL;

	if(uMsg == WM_CREATE) 
	{
		// Fetch this window-object from the CreateStruct
		Window=(CMeterWindow*)((LPCREATESTRUCT)lParam)->lpCreateParams;

		SetProp(hWnd, "RAINMETER", Window);
	}
	else if(uMsg == WM_DESTROY) 
	{
		RemoveProp(hWnd, "RAINMETER");
	}
	else
	{
		Window = (CMeterWindow*)GetProp(hWnd, "RAINMETER");
	}

	if (Window) Window->m_Message = uMsg;

	BEGIN_MESSAGEPROC
	MESSAGE(OnPaint, WM_PAINT)
	MESSAGE(OnMove, WM_MOVE)
	MESSAGE(OnCreate, WM_CREATE)
	MESSAGE(OnDestroy, WM_DESTROY)
	MESSAGE(OnTimer, WM_TIMER)
	MESSAGE(OnCommand, WM_COMMAND)
	MESSAGE(OnNcHitTest, WM_NCHITTEST)
	MESSAGE(OnMouseMove, WM_MOUSEMOVE)
	MESSAGE(OnMouseMove, WM_NCMOUSEMOVE)
	MESSAGE(OnContextMenu, WM_CONTEXTMENU)
	MESSAGE(OnRightButtonDown, WM_NCRBUTTONDOWN)
	MESSAGE(OnRightButtonDown, WM_RBUTTONDOWN)
	MESSAGE(OnRightButtonUp, WM_RBUTTONUP)
	MESSAGE(OnContextMenu, WM_NCRBUTTONUP)
	MESSAGE(OnLeftButtonDown, WM_NCLBUTTONDOWN)
	MESSAGE(OnLeftButtonDown, WM_LBUTTONDOWN)
	MESSAGE(OnLeftButtonUp, WM_LBUTTONUP)
	MESSAGE(OnLeftButtonUp, WM_NCLBUTTONUP)
	MESSAGE(OnWindowPosChanging, WM_WINDOWPOSCHANGING)
	MESSAGE(OnCopyData, WM_COPYDATA)
	END_MESSAGEPROC
}

/*
** OnCopyData
**
** Handles bangs from the exe
**
*/
LRESULT CMeterWindow::OnCopyData(WPARAM wParam, LPARAM lParam)
{
	COPYDATASTRUCT* pCopyDataStruct = (COPYDATASTRUCT*) lParam;

	if (pCopyDataStruct && (pCopyDataStruct->dwData == 1) && (pCopyDataStruct->cbData > 0))
	{
		std::string str = (const char*)pCopyDataStruct->lpData;
		std::string bang;
		std::string arg;

		// Find the first space
		std::string::size_type pos = str.find(' ');
		if (pos != -1)
		{
			bang = str.substr(0, pos);
			str.erase(0, pos + 1);
			arg = str;
		}
		else
		{
			bang = str;
		}

		// Add the current config name to the args. If it's not defined already
		// the bang only affects this config, if there already is a config defined
		// another one doesn't matter.
		arg += " ";
		arg += m_SkinName.c_str();

		if (stricmp(bang.c_str(), "!RainmeterRefresh") == 0)
		{
			RainmeterRefresh(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterRedraw") == 0)
		{
			RainmeterRedraw(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterHide") == 0)
		{
			RainmeterHide(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterShow") == 0)
		{
			RainmeterShow(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterToggle") == 0)
		{
			RainmeterToggle(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterHideMeter") == 0)
		{
			RainmeterHideMeter(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterShowMeter") == 0)
		{
			RainmeterShowMeter(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterToggleMeter") == 0)
		{
			RainmeterToggleMeter(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterDisableMeasure") == 0)
		{
			RainmeterDisableMeasure(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterEnableMeasure") == 0)
		{
			RainmeterEnableMeasure(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterToggleMeasure") == 0)
		{
			RainmeterToggleMeasure(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterActivateConfig") == 0)
		{
			RainmeterActivateConfig(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterDeactivateConfig") == 0)
		{
			RainmeterDeactivateConfig(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterMove") == 0)
		{
			RainmeterMove(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterChangeZPos") == 0)	// For backwards combatibility
		{
			RainmeterZPos(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterZPos") == 0)
		{
			RainmeterZPos(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterAbout") == 0)
		{
			RainmeterAbout(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterResetStats") == 0)
		{
			RainmeterResetStats(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterMoveMeter") == 0)
		{
			RainmeterMoveMeter(m_Window, arg.c_str());
		}
		else if (stricmp(bang.c_str(), "!RainmeterLsBoxHook") == 0)
		{
			// Nothing to do here (this works only with Litestep)
		}
		else if (stricmp(bang.c_str(), "!Execute") == 0)
		{
			// Special case for multibang execution
			while (true)
			{
				std::string::size_type start = arg.find('[');
				std::string::size_type end = arg.find(']');
				if (start != -1 && end != -1 && start < end)
				{
					std::string command = arg.substr(start + 1, end - (start + 1));
					// trim leading whitespace
					std::string::size_type notwhite = command.find_first_not_of(" \t\n");
					command.erase(0, notwhite);
					ExecuteCommand(command.c_str());
				}
				else
				{
					break;	// No more commands
				}
				arg = arg.substr(end + 1);
			}
		}
		else
		{
			std::string error = "Unknown !bang: ";
			error += bang;
			MessageBox(m_Window, error.c_str(), "Rainmeter", MB_OK);
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
	
	return TRUE;
}


