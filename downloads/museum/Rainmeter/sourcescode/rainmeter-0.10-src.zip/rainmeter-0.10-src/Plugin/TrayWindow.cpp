/*
  Copyright (C) 2004 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/TrayWindow.cpp,v 1.1 2004/06/05 10:55:54 rainy Exp $

  $Log: TrayWindow.cpp,v $
  Revision 1.1  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

*/

#include "TrayWindow.h"
#include "Resource.h"
#include "Litestep.h"
#include "Rainmeter.h"
#include "AboutDialog.h"
#include <HtmlHelp.h>

#define TRAYTIMER 3

extern CRainmeter* Rainmeter;

using namespace Gdiplus;

CTrayWindow::CTrayWindow(HINSTANCE instance)
{
	WNDCLASS  wc;

	wc.style = 0;
	wc.lpfnWndProc = (WNDPROC)WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = instance;
	wc.hIcon = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	wc.lpszMenuName =  NULL;
	wc.lpszClassName = "RainmeterTrayClass";

	RegisterClass(&wc);
	
	m_Window = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		"RainmeterTrayClass",
		NULL,
		WS_POPUP,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		NULL,
		instance,
		this);

	m_Instance = instance;
	m_Measure = NULL;
	m_TrayIcon = NULL;

	SetWindowLong(m_Window, GWL_USERDATA, magicDWord);

	m_TrayPos = 0;
	memset(m_TrayValues, 0, sizeof(double) * TRAYICON_SIZE);

	if (Rainmeter->IsTrayIcon())
	{
		AddTrayIcon();
		SetTimer(m_Window, TRAYTIMER, 1000, NULL);		// Update the tray once per sec
	}
}

CTrayWindow::~CTrayWindow()
{
	KillTimer(m_Window, TRAYTIMER);
	if (Rainmeter->IsTrayIcon())
	{
		RemoveTrayIcon();
	}
	if (m_Measure) delete m_Measure;

	if (m_Window) DestroyWindow(m_Window);
}

BOOL CTrayWindow::AddTrayIcon() 
{ 
    BOOL res = FALSE; 
    NOTIFYICONDATA tnid; 
	
	if (m_TrayIcon)
	{
		DestroyIcon(m_TrayIcon);
		m_TrayIcon = NULL;
	}

	m_TrayIcon = CreateTrayIcon(0);

	if (m_TrayIcon)
	{
		tnid.cbSize = sizeof(NOTIFYICONDATA); 
		tnid.hWnd = m_Window; 
		tnid.uID = IDI_TRAY;
		tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
		tnid.uCallbackMessage = WM_NOTIFYICON; 
		tnid.hIcon = m_TrayIcon;
		lstrcpyn(tnid.szTip, "Rainmeter", sizeof(tnid.szTip)); 
		
		res = Shell_NotifyIcon(NIM_ADD, &tnid); 
	}
    return res; 
}

BOOL CTrayWindow::RemoveTrayIcon() 
{ 
    BOOL res; 
    NOTIFYICONDATA tnid; 
	
    tnid.cbSize = sizeof(NOTIFYICONDATA); 
    tnid.hWnd = m_Window; 
    tnid.uID = IDI_TRAY; 
	tnid.uFlags = 0; 
	
    res = Shell_NotifyIcon(NIM_DELETE, &tnid);

	if (m_TrayIcon)
	{
		DestroyIcon(m_TrayIcon);
		m_TrayIcon = NULL;
	}

    return res; 
}

BOOL CTrayWindow::ModifyTrayIcon(double value) 
{ 
    BOOL res = FALSE; 
    NOTIFYICONDATA tnid; 

	if (m_TrayIcon)
	{
		DestroyIcon(m_TrayIcon);
		m_TrayIcon = NULL;
	}

	m_TrayIcon = CreateTrayIcon(value);
	
	tnid.cbSize = sizeof(NOTIFYICONDATA); 
	tnid.hWnd = m_Window; 
	tnid.uID = IDI_TRAY;
	tnid.uFlags = NIF_ICON; 
	tnid.hIcon = m_TrayIcon;

    res = Shell_NotifyIcon(NIM_MODIFY, &tnid); 
    return res; 
}

HICON CTrayWindow::CreateTrayIcon(double value)
{
	if (m_Measure == NULL)
	{
		return LoadIcon(m_Instance, MAKEINTRESOURCE(IDI_TRAY));
	}
	else
	{
		m_TrayValues[m_TrayPos] = value;
		m_TrayPos = (m_TrayPos + 1) % TRAYICON_SIZE;

		Bitmap trayBitmap(TRAYICON_SIZE, TRAYICON_SIZE);
		Graphics graphics(&trayBitmap);
		graphics.SetSmoothingMode(SmoothingModeAntiAlias);

		Point points[TRAYICON_SIZE + 2];
		points[0].X = 0;
		points[0].Y = TRAYICON_SIZE;
		points[TRAYICON_SIZE + 1].X = TRAYICON_SIZE - 1;
		points[TRAYICON_SIZE + 1].Y = TRAYICON_SIZE;

		for (int i = 0; i < TRAYICON_SIZE; i++)
		{
			points[i + 1].X = i;
			points[i + 1].Y = (TRAYICON_SIZE * (1.0 - m_TrayValues[(m_TrayPos + i) % TRAYICON_SIZE]));
		}

		SolidBrush brush(Color(0, 100, 0));
		graphics.FillRectangle(&brush, 0, 0, TRAYICON_SIZE, TRAYICON_SIZE);

		SolidBrush brush2(Color(0, 255, 0));
		graphics.FillPolygon(&brush2, points, TRAYICON_SIZE + 2);

		HICON icon;
		trayBitmap.GetHICON(&icon);
		return icon;
	}

	return NULL;
}

void CTrayWindow::ReadConfig(CConfigParser& parser)
{
	std::string measureName = parser.ReadString("TrayMeasure", "Measure", "");

	if (!measureName.empty())
	{
		m_Measure = CMeasure::Create(measureName.c_str());
		m_Measure->SetName("TrayMeasure");
		m_Measure->ReadConfig(parser, "TrayMeasure");
	}
}

LRESULT CALLBACK CTrayWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static CTrayWindow* tray = NULL;

	if(uMsg == WM_CREATE) 
	{
		tray=(CTrayWindow*)((LPCREATESTRUCT)lParam)->lpCreateParams;
	}

	switch(uMsg) 
	{
	case WM_COMMAND:
		if (Rainmeter && tray)
		{
			if(wParam == ID_CONTEXT_ABOUT)
			{
				OpenAboutDialog(tray->GetWindow(), Rainmeter->GetInstance());
			} 
			else if(wParam == ID_CONTEXT_SHOW_HELP)
			{
				std::string help = Rainmeter->GetPath();
				help += "Rainmeter.chm";
				HtmlHelp(GetDesktopWindow(), help.c_str(), HH_DISPLAY_TOPIC, 0);
			}
			else if(wParam == ID_CONTEXT_REFRESH)
			{
				// Refresh all
				RainmeterRefresh(tray->GetWindow(), NULL);
			} 
			else if(wParam == ID_CONTEXT_EDITCONFIG)
			{
				std::string command = Rainmeter->GetConfigEditor();
				command += " \"";
				command += Rainmeter->GetIniFile();
				LSExecute(tray->GetWindow(), command.c_str(), SW_SHOWNORMAL);
			}
			else if(wParam == ID_CONTEXT_QUIT)
			{
				if (Rainmeter->GetDummyLitestep()) PostQuitMessage(0);
				quitModule(Rainmeter->GetInstance());
			}
			else if((wParam & 0x0ffff) >= ID_CONFIG_FIRST)
			{
				wParam = wParam & 0x0ffff;

				// Check which config was selected
				int index = 0;
				
				const std::vector<CRainmeter::CONFIG>& configs = Rainmeter->GetAllConfigs();

				for (int i = 0; i < configs.size(); i++)
				{
					for (int j = 0; j < configs[i].iniFiles.size(); j++)
					{
						if (index == wParam - ID_CONFIG_FIRST)
						{
							if (configs[i].active == j + 1)
							{
								CMeterWindow* meterWindow = Rainmeter->GetMeterWindow(configs[i].config);
								Rainmeter->DeactivateConfig(meterWindow, i);
							}
							else
							{
								if (configs[i].active != 0)
								{
									CMeterWindow* meterWindow = Rainmeter->GetMeterWindow(configs[i].config);
									if (meterWindow)
									{
										Rainmeter->DeactivateConfig(meterWindow, i);
									}
								}
								Rainmeter->ActivateConfig(i, j);
							}
						}
						index++;
					}
				}
			}
			else
			{
				// Forward the message to correct window
				int index = wParam >> 16;
				std::map<std::string, CMeterWindow*>& windows = Rainmeter->GetAllMeterWindows();

				if (index < windows.size())
				{
					std::map<std::string, CMeterWindow*>::iterator iter = windows.begin();
					for( ; iter != windows.end(); iter++)
					{
						index--;
						if (index < 0)
						{
							CMeterWindow* meterWindow = (*iter).second;
							SendMessage(meterWindow->GetWindow(), WM_COMMAND, wParam & 0x0FFFF, NULL);
							break;
						}
					}
				}
			}
		}
		break;

	case WM_NOTIFYICON:
		{
			UINT uMouseMsg = (UINT)lParam;
			
			if(uMouseMsg == WM_RBUTTONDOWN)
			{
				if (Rainmeter)
				{
					POINT point;
					GetCursorPos(&point);
					SetForegroundWindow(tray->m_Window);
					Rainmeter->ShowContextMenu(point, NULL);
					SetForegroundWindow(tray->m_Window);
				}
			}
		}
		break;

	case WM_TIMER:
		if (tray && tray->m_Measure)
		{
			tray->m_Measure->Update(NULL);
			tray->ModifyTrayIcon(tray->m_Measure->GetRelativeValue());
		}
		break;

	case WM_DESTROY:
		if (Rainmeter->GetDummyLitestep())PostQuitMessage(0);
		break;

	case LM_GETREVID:
		if(lParam != NULL)
		{
			char* Buffer=(char*)lParam;
			if(wParam==0) 
			{
				sprintf(Buffer, "Rainmeter.dll: %s", APPVERSION);
			} 
			else if(wParam==1) 
			{
				sprintf(Buffer, "Rainmeter.dll: %s %s, Rainy", APPVERSION, __DATE__);
			} 
			else
			{
				Buffer[0] = 0;
			}

			return strlen(Buffer);
		}
		return 0;

	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
