/*
  Copyright (C) 2004 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/TrayWindow.h,v 1.1 2004/06/05 10:55:54 rainy Exp $

  $Log: TrayWindow.h,v $
  Revision 1.1  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

*/

#ifndef __TRAYWINDOW_H__
#define __TRAYWINDOW_H__

#pragma warning(disable: 4786)

#include <windows.h>
#include "Measure.h"

#define WM_NOTIFYICON WM_USER + 101
#define TRAYICON_SIZE 16

class CTrayWindow
{
public:
	CTrayWindow(HINSTANCE instance);
	~CTrayWindow();

	void ReadConfig(CConfigParser& parser);
	HWND GetWindow() { return m_Window; }

protected:
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	BOOL AddTrayIcon();
	BOOL RemoveTrayIcon();
	BOOL ModifyTrayIcon(double value);
	HICON CreateTrayIcon(double value);

	HICON m_TrayIcon;
	HWND m_Window;
	HINSTANCE m_Instance;
	CMeasure* m_Measure;

	double m_TrayValues[TRAYICON_SIZE];
	int m_TrayPos;
};

#endif
