                                       /*
  $Header: /home/cvsroot/Rainmeter/WebParser/WebParser.cpp,v 1.3 2004/06/05 10:57:13 rainy Exp $

  $Log: WebParser.cpp,v $
  Revision 1.3  2004/06/05 10:57:13  rainy
  Added new interface.
  Uses config parser.

  Revision 1.2  2003/03/22 20:38:59  rainy
  Should work now.

  Revision 1.1  2003/03/14 10:19:51  rainy
  Initial version

*/

// Note: To compile this you need the PCRE library (http://www.pcre.org/).
// See: http://www.perldoc.com/perl5.8.0/pod/perlre.html

#pragma warning(disable: 4786)

#include <windows.h>
#include <math.h>
#include <string>
#include <map>
#include <vector>
#include <Wininet.h>
#include <pcre/include/pcre.h>
#include "../Plugin/Export.h"

/* The exported functions */
extern "C"
{
__declspec( dllexport ) UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id);
__declspec( dllexport ) double Update2(UINT id);
__declspec( dllexport ) LPCTSTR GetString(UINT id, UINT flags);
__declspec( dllexport ) void Finalize(HMODULE instance, UINT id);
__declspec( dllexport ) UINT GetPluginVersion();
__declspec( dllexport ) LPCTSTR GetPluginAuthor();
}

char* DownloadUrl(std::string& url);
void ShowError(int lineNumber, char* errorMsg = NULL);
DWORD WINAPI NetworkThreadProc(LPVOID pParam);
void Log(const char* string);
bool ParseSubstitute(std::string buffer, std::map<std::string, std::string>& substitute);

struct UrlData
{
	std::string url;
	std::string regExp;
	std::string resultString;
	UINT stringIndex;
	UINT updateRate;
	UINT updateCounter;
	std::string section;
	std::string finishAction;
	bool debug;
	HANDLE threadHandle;
	std::map<std::string, std::string> substitute;
};

CRITICAL_SECTION g_CriticalSection; 
bool g_Initialized = false;

static std::map<UINT, UrlData*> g_UrlData;
static bool g_Debug = false;
static HINTERNET hRootHandle = NULL;

#define OVECCOUNT 300    // should be a multiple of 3
#define MUTEX_ERROR "Unable to obtain the mutex."

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	LPCSTR tmpSz; 

	if (!g_Initialized)
	{
		InitializeCriticalSection(&g_CriticalSection);
		g_Initialized = true;
	}

	UrlData* data = new UrlData;
	data->section = section;
	data->updateRate = 1;
	data->updateCounter = 0;

	/* Read our own settings from the ini-file */

	data->url = ReadConfigString(section, "Url", "");
	data->regExp = ReadConfigString(section, "RegExp", "");
	data->finishAction = ReadConfigString(section, "FinishAction", "");

	tmpSz = ReadConfigString(section, "StringIndex", "0");
	if (tmpSz)
	{
		data->stringIndex = atoi(tmpSz);
	}

	tmpSz = ReadConfigString(section, "UpdateRate", "1");
	if (tmpSz)
	{
		data->updateRate = atoi(tmpSz);
	}

	tmpSz = ReadConfigString(section, "Debug", "0");
	if (tmpSz)
	{
		data->debug = strcmp(tmpSz, "1") == 0;
	}

	if (hRootHandle == NULL)
	{
		hRootHandle = InternetOpen("Rainmeter WebParser plugin",
									INTERNET_OPEN_TYPE_PRECONFIG,
									NULL,
									NULL,
									0);
		if (hRootHandle == NULL)
		{
			ShowError(__LINE__);
			return NULL;
		}
	}

	data->threadHandle = 0;

	// During initialization there is no threads yet so no need to do any locking
	g_UrlData[id] = data;

	return 1;
}

/*
  Returns the first word from the buffer. The word can be inside quotes.
  If not, the separators are ' ', '\t', ',' and ':'. Whitespaces are removed 
  and buffer will be modified.
*/
std::string ExtractWord(std::string& buffer)
{
	std::string::size_type end = 0;
	std::string ret;

	if (buffer.empty()) return ret;	

	// Remove whitespaces
	std::string::size_type notwhite = buffer.find_first_not_of(" \t\n");
	buffer.erase(0, notwhite);

	if (buffer[0] == '\"')
	{
		end = 1;	// Skip the '"'
		// Quotes around the word
		while (buffer[end] != '\"' && end < buffer.size()) end++;

		if (buffer[end] == '\"')
		{
			ret = buffer.substr(1, end - 1);
			buffer.erase(0, end + 1);
		}
		else
		{
			// End of string reached
			ret = buffer.substr(end);
			buffer.erase(0, end);
		}
	}
	else
	{
		end = 0;
		while ((buffer[end] != ',') && (buffer[end] != ':') && (buffer[end] != ' ') && (buffer[end] != '\t') && end < buffer.size()) end++;

		if (end == buffer.size())
		{
			// End of line reached
			ret = buffer;
			buffer.erase(0, end);
		}
		else
		{
			ret = buffer.substr(0, end + 1);	// The separator is also returned!
			buffer.erase(0, end + 1);
		}
	}
	return ret;
}

/*
  Reads the buffer for "Name":"Value"-pairs separated with comma and
  fills the map with the parsed data.
*/
bool ParseSubstitute(std::string buffer, std::map<std::string, std::string>& substitute)
{
	if (buffer.empty()) return true;	

	// Add quotes since they are removed by the GetProfileString
	buffer = "\"" + buffer + "\"";

	std::string word1;
	std::string word2;
	std::string sep;

	while (!buffer.empty())
	{
		word1 = ExtractWord(buffer);
		sep = ExtractWord(buffer);
		if (sep != ":") return false; 
		word2 = ExtractWord(buffer);
		substitute[word1] = word2;

		sep = ExtractWord(buffer);
		if (!sep.empty() && sep != ",") return false; 
	}

	return true;
}

/*
  This function is called when new value should be measured.
  The function returns the new value.
*/
double Update2(UINT id)
{
	double value = 0;
	UrlData* urlData = NULL;

	// Find the data for this instance (the data structure is not changed by anyone so this should be safe)
	std::map<UINT, UrlData*>::iterator urlIter = g_UrlData.find(id);
	if(urlIter != g_UrlData.end())
	{
		urlData = (*urlIter).second;
	}

	if (urlData) 
	{
		// Make sure that the thread is not writing to the result at the same time
		EnterCriticalSection(&g_CriticalSection);
		
		if (!urlData->resultString.empty())
		{
			value = atof(urlData->resultString.c_str());
		}

		LeaveCriticalSection(&g_CriticalSection);

		if (urlData->url.size() > 0 && urlData->url[0] != '[')
		{
			// This is not a reference; need to update.
			if (urlData->threadHandle != 0)
			{
				Log("WebParser: The thread has not finished yet.");
			}
			else
			{
				if (urlData->updateCounter == 0)
				{
					// Launch a new thread to fetch the web data
					DWORD id;
					urlData->threadHandle = CreateThread(NULL, 0, NetworkThreadProc, urlData, 0, &id);
				}

				urlData->updateCounter++;
				if (urlData->updateCounter >= urlData->updateRate)
				{
					urlData->updateCounter = 0;
				}
			}
		}
	}

	return value;
}

/*
  Thread that fetches the data from the net and parses the page.
*/
DWORD WINAPI NetworkThreadProc(LPVOID pParam)
{
	UrlData* urlData = (UrlData*)pParam;

	char* data = DownloadUrl(urlData->url);

	if (data)
	{
		// Parse the value from the data
		pcre* re;
		const char* error;
		int erroffset;
		int ovector[OVECCOUNT];
		int rc;
		// Compile the regular expression in the first argument
		
		re = pcre_compile(
			urlData->regExp.c_str(),   // the pattern
			0,					  // default options
			&error,               // for error message
			&erroffset,           // for error offset
			NULL);                // use default character tables
		
		if (re != NULL)
		{
			// Compilation succeeded: match the subject in the second argument
			
			rc = pcre_exec(
				re,                   // the compiled pattern
				NULL,                 // no extra data - we didn't study the pattern
				data,		          // the subject string
				(int)strlen(data),    // the length of the subject
				0,                    // start at offset 0 in the subject
				0,                    // default options
				ovector,              // output vector for substring information
				OVECCOUNT);           // number of elements in the output vector
			
			
			if (rc >= 0)
			{
				if (rc == 0)
				{
					// The output vector wasn't big enough
					Log("WebParser: Too many substrings!");
				}
				else
				{
					if (urlData->stringIndex < rc)
					{
						if (urlData->debug)
						{
							for (int i = 0; i < rc; i++)
							{
								char buffer[1024];
								char* substring_start = data + ovector[2 * i];
								int substring_length = ovector[2 * i + 1] - ovector[2 * i];
								substring_length = min(substring_length, 256);
								sprintf(buffer, "WebParser: (Index %2d) %.*s", i, substring_length, substring_start);
								Log(buffer);
							}
						}

						char* substring_start = data + ovector[2 * urlData->stringIndex];
						int substring_length = ovector[2 * urlData->stringIndex + 1] - ovector[2 * urlData->stringIndex];

						std::string strResult = std::string(substring_start, substring_length);

						// Check for substitutes
						std::map<std::string, std::string>::iterator subsIter = urlData->substitute.find(strResult);
						if (subsIter != urlData->substitute.end())
						{
							strResult = (*subsIter).second;
						}

						EnterCriticalSection(&g_CriticalSection);
						urlData->resultString = strResult;
						LeaveCriticalSection(&g_CriticalSection);
					}
					else
					{
						Log("WebParser: Not enough substrings!");
					}

					// Update the references
					std::map<UINT, UrlData*>::iterator i = g_UrlData.begin();
					std::string compareStr = "[";
					compareStr += urlData->section;
					compareStr += "]";
					for ( ; i != g_UrlData.end(); i++)
					{
						if (compareStr == ((*i).second)->url)
						{
							if (((*i).second)->stringIndex < rc)
							{
								char* substring_start = data + ovector[2 * ((*i).second)->stringIndex];
								int substring_length = ovector[2 * ((*i).second)->stringIndex + 1] - ovector[2 * ((*i).second)->stringIndex];

								std::string strResult = std::string(substring_start, substring_length);

								// Check for substitutes
								std::map<std::string, std::string>::iterator subsIter = ((*i).second)->substitute.find(strResult);
								if (subsIter != ((*i).second)->substitute.end())
								{
									strResult = (*subsIter).second;
								}

								EnterCriticalSection(&g_CriticalSection);
								((*i).second)->resultString = strResult;
								LeaveCriticalSection(&g_CriticalSection);
							}
							else
							{
								Log("WebParser: Not enough substrings!");
							}
						}
					}
				}
			}
			else
			{
				// Matching failed: handle error cases
				Log("WebParser: Matching error!");
			}

			delete [] data;
		}
		else
		{
			// Compilation failed: print the error message and exit
			char buffer[1024];
			sprintf(buffer, "WebParser: PCRE compilation failed at offset %d: %s\n", erroffset, error);
			Log(buffer);
		}
	}

	if (!urlData->finishAction.empty()) 
	{
		HWND wnd = FindWindow("RainmeterMeterWindow", NULL);

		if (wnd != NULL)
		{
			COPYDATASTRUCT copyData;

			copyData.dwData = 1;
			copyData.cbData = urlData->finishAction.size() + 1;
			copyData.lpData = (void*)urlData->finishAction.c_str();

			// Send the bang to the Rainlendar window
			SendMessage(wnd, WM_COPYDATA, (WPARAM)NULL, (LPARAM)&copyData);
		}
	}

	CloseHandle(urlData->threadHandle);

	EnterCriticalSection(&g_CriticalSection);
	urlData->threadHandle = 0;
	LeaveCriticalSection(&g_CriticalSection);

    return 0;   // thread completed successfully
}

/*
  This function is called when the value should be
  returned as a string.
*/
LPCTSTR GetString(UINT id, UINT flags) 
{
	static std::string resultString;

	std::map<UINT, UrlData*>::iterator urlIter = g_UrlData.find(id);

	if(urlIter != g_UrlData.end())
	{
		EnterCriticalSection(&g_CriticalSection);
		resultString = ((*urlIter).second)->resultString;
		LeaveCriticalSection(&g_CriticalSection);

		return resultString.c_str();
	}

	return NULL;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	std::map<UINT, UrlData*>::iterator urlIter = g_UrlData.find(id);

	if(urlIter != g_UrlData.end())
	{
		if (((*urlIter).second)->threadHandle)
		{
			// Thread is killed inside critical section so that itself is not inside one when it is terminated
			EnterCriticalSection(&g_CriticalSection);

			TerminateThread(((*urlIter).second)->threadHandle, 0);
			(*urlIter).second->threadHandle = NULL;
			
			LeaveCriticalSection(&g_CriticalSection);
		}
		delete (*urlIter).second;
		g_UrlData.erase(urlIter);
	}

	if (g_UrlData.empty())
	{
		// Last one, close all handles
		if (hRootHandle)
		{
			InternetCloseHandle(hRootHandle);
			hRootHandle = NULL;
		}

		// Last instance deletes the critical section
		DeleteCriticalSection(&g_CriticalSection);
		g_Initialized = false;
	}
}

/*
	Downloads the given url and returns the webpage as dynamically allocated string.
	You need to delete the returned string after use!
*/
char* DownloadUrl(std::string& url)
{
	HINTERNET hUrlDump;
	DWORD dwSize = TRUE;
	LPSTR lpszData;
	LPSTR lpszOutPut;
	LPSTR lpszHolding = NULL;
	int nCounter = 1;
	int nBufferSize;
	DWORD BigSize = 8000;

	std::string err = "WebParser: Fetching URL: ";
	err += url;
	Log(err.c_str());
	
	hUrlDump = InternetOpenUrl(hRootHandle, url.c_str(), NULL, NULL, INTERNET_FLAG_RESYNCHRONIZE, 0);
	if (hUrlDump == NULL)
	{
		ShowError(__LINE__);
		return NULL;
	}

	do
	{
		// Allocate the buffer.
		lpszData = new char[BigSize + 1];
		
		// Read the data.
		if (!InternetReadFile(hUrlDump, (LPVOID)lpszData, BigSize, &dwSize))
		{
			ShowError(__LINE__);
			delete [] lpszData;
			break;
		}
		else
		{
			// Add a null terminator to the end of the buffer.
			lpszData[dwSize] = '\0';
			
			// Check if all of the data has been read.  This should
			// never get called on the first time through the loop.
			if (dwSize == 0)
			{
				// Delete the existing buffers.
				delete [] lpszData;
				break;
			}
			
			// Determine the buffer size to hold the new data and the data
			// already written to the textbox (if any).
			nBufferSize = (nCounter * BigSize) + 1;
			
			// Increment the number of buffers read.
			nCounter++;               
			
			// Allocate the output buffer.
			lpszOutPut = new char[nBufferSize];
			
			// Make sure the buffer is not the initial buffer.
			if (nBufferSize != int(BigSize + 1))
			{
				// Copy the data in the holding buffer.
				strcpy(lpszOutPut, lpszHolding);
				
				// Concatenate the new buffer with the output buffer.
				strcat(lpszOutPut, lpszData);
				
				// Delete the holding buffer.
				delete [] lpszHolding;
			}
			else
			{
				// Copy the data buffer.
				strcpy(lpszOutPut, lpszData);
			}
			
			// Allocate a holding buffer.
			lpszHolding = new char[nBufferSize]; 
			
			// Copy the output buffer into the holding buffer.
			memcpy(lpszHolding, lpszOutPut, nBufferSize);
			
			// Delete the other buffers.
			delete [] lpszData;
			delete [] lpszOutPut;
		}
	} while (TRUE);
	
	// Close the HINTERNET handle.
	InternetCloseHandle(hUrlDump);

	err = "WebParser: Finished URL: ";
	err += url;
	Log(err.c_str());

	// Return.
	return lpszHolding;
}

/*
  Writes the last error to log.
*/
void ShowError(int lineNumber, char* errorMsg)
{
	LPVOID lpMsgBuf = NULL;

	if (errorMsg == NULL)
	{
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);

		if (lpMsgBuf == NULL) lpMsgBuf = "Unknown error!";

		errorMsg = (LPTSTR)lpMsgBuf;
	}

	char buffer[16];
	sprintf(buffer, "%i", lineNumber);

	std::string err = "WebParser (";
	err += buffer;
	err += ") ";
	err += errorMsg;
	Log(err.c_str());

	if (lpMsgBuf) LocalFree(lpMsgBuf);
}

/*
  Writes the log to a file (logging is thread safe (I think...)).
*/
void Log(const char* string)
{
	// Todo: put logging into critical section
	LSLog(LOG_DEBUG, "Rainmeter", string);
}

UINT GetPluginVersion()
{
	return 1001;
}

LPCTSTR GetPluginAuthor()
{
	return "Rainy (rainy@iki.fi)";
}