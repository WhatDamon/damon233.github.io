#include <windows.h>
#include "AdvancedCPU.h"
#include <string>
#include <vector>
#include <map>
#include "..\Plugin\Export.h"	// Rainmeter's exported functions

ULONGLONG GetPerfData(PCTSTR ObjectName, PCTSTR InstanceName, PCTSTR CounterName);

struct CPUMeasure
{
	std::vector< std::string > includes;
	std::vector< std::string > excludes;
	ULONGLONG oldValue;
};

static CPerfTitleDatabase g_CounterTitles( PERF_TITLE_COUNTER );
static std::map<UINT, CPUMeasure*> g_CPUMeasures;

void SplitName(char* names, std::vector< std::string >& splittedNames)
{
	char* token;
	
	token = strtok(names, ";");
	while(token != NULL)
	{
		splittedNames.push_back(token);
		token = strtok(NULL, ";");
	}
}

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	char buffer[4096];
	CPUMeasure* measure = new CPUMeasure;
	measure->oldValue = 0;

	LPCTSTR data = ReadConfigString(section, "CPUInclude", "");
	if (data)
	{
		strncpy(buffer, data, 4096);
		buffer[4095] = 0;
		SplitName(buffer, measure->includes);
	}

	data = ReadConfigString(section, "CPUExclude", "");
	if (data)
	{
		strncpy(buffer, data, 4096);
		buffer[4095] = 0;
		SplitName(buffer, measure->excludes);
	}

	g_CPUMeasures[id] = measure;

	return 10000000;	// The values are 100 * 100000
}

/*
  This function is called when new value should be measured.
  The function returns the new value.
*/
UINT Update(UINT id)
{
	int value = 0;

	std::map<UINT, CPUMeasure*>::iterator i = g_CPUMeasures.find(id);
	if(i != g_CPUMeasures.end())
	{
		CPUMeasure* measure = (*i).second;

		if(measure)
		{
			// Check the platform
			OSVERSIONINFO osvi;
			ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
			osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
			if(GetVersionEx((OSVERSIONINFO*)&osvi) && osvi.dwPlatformId == VER_PLATFORM_WIN32_NT && osvi.dwMajorVersion > 4)
			{
				LONGLONG newValue = 0;
				ULONGLONG longvalue = 0;

				if (measure->includes.empty())
				{
					// First get the total CPU value
					longvalue = GetPerfData("Processor", "_Total", "% Processor Time");
					newValue = longvalue;


					// Then substract the excluded processes
					std::vector< std::string >::iterator j = measure->excludes.begin();
					for( ; j != measure->excludes.end(); j++)
					{
						longvalue = GetPerfData("Process", (*j).c_str(), "% Processor Time");
						newValue += longvalue;		// Adding means actually substraction
					}

					// Compare with the old value
					if(measure->oldValue != 0) 
					{
						int val = 10000000 - (UINT)(newValue - measure->oldValue);
						if (val < 0) val = 0;
						value = val;
					}
					measure->oldValue = newValue;
				}
				else
				{
					// Add the included processes
					std::vector< std::string >::iterator j = measure->includes.begin();
					for( ; j != measure->includes.end(); j++)
					{
						longvalue = GetPerfData("Process", (*j).c_str(), "% Processor Time");
						newValue += longvalue;
					}

					// Compare with the old value
					if(measure->oldValue != 0) 
					{
						value = (UINT)(newValue - measure->oldValue);
					}
					measure->oldValue = newValue;

				}

			}
			else
			{
				MessageBox(NULL, "AdvancedCPU works only in Win2K/XP.", "Rainmeter AdvancedCPU", MB_OK);
			}
		}
	}

	return value;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	// delete the measure
	std::map<UINT, CPUMeasure*>::iterator i = g_CPUMeasures.find(id);
	if(i != g_CPUMeasures.end())
	{
		delete (*i).second;
		g_CPUMeasures.erase(i);
	}

	CPerfSnapshot::CleanUp();
}

/*
  This method gets value of the given perfmon counter.
*/
ULONGLONG GetPerfData(PCTSTR ObjectName, PCTSTR InstanceName, PCTSTR CounterName)
{
	CPerfObject* pPerfObj;
	CPerfObjectInstance* pObjInst;
	CPerfCounter* pPerfCntr;
	BYTE data[256];
	char name[256];
	ULONGLONG value = 0;

	if(ObjectName == NULL || CounterName == NULL || strlen(ObjectName) == 0 || strlen(CounterName) == 0)
	{
		// Unable to continue
		return 0;
	}


	CPerfSnapshot snapshot(&g_CounterTitles);
	CPerfObjectList objList(&snapshot, &g_CounterTitles);

	if(snapshot.TakeSnapshot(ObjectName))
	{
		pPerfObj = objList.GetPerfObject(ObjectName);

		if(pPerfObj)
		{
			for(pObjInst = pPerfObj->GetFirstObjectInstance();
				pObjInst != NULL;
				pObjInst = pPerfObj->GetNextObjectInstance())
			{
				if (InstanceName != NULL && strlen(InstanceName) > 0)
				{
					if(pObjInst->GetObjectInstanceName(name, 256))
					{
						if(_stricmp(InstanceName, name) != 0) 
						{
							delete pObjInst;
							continue;
						}
					}
					else
					{
						delete pObjInst;
						continue;
					}
				}

				pPerfCntr = pObjInst->GetCounterByName(CounterName);
				if(pPerfCntr != NULL)
				{
					pPerfCntr->GetData(data, 256, NULL);
					
					if(pPerfCntr->GetSize() == 1)
					{
						value = *(BYTE*)data;
					} 
					else if(pPerfCntr->GetSize() == 2)
					{
						value = *(WORD*)data;
					}
					else if(pPerfCntr->GetSize() == 4)
					{
						value = *(DWORD*)data;
					}
					else if(pPerfCntr->GetSize() == 8)
					{
						value = *(ULONGLONG*)data;
					}

					delete pPerfCntr;
					delete pObjInst;
					break;	// No need to continue
				}
				delete pObjInst;
			}
			delete pPerfObj;
		}
	}

	return value;
}

UINT GetPluginVersion()
{
	return 1002;
}

LPCTSTR GetPluginAuthor()
{
	return "Rainy (rainy@iki.fi)";
}

