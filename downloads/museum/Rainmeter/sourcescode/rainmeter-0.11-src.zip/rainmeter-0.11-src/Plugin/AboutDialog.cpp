/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/AboutDialog.cpp,v 1.5 2004/06/05 10:55:54 rainy Exp $

  $Log: AboutDialog.cpp,v $
  Revision 1.5  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.4  2004/03/13 16:13:50  rainy
  Added support for multiple configs.

  Revision 1.3  2003/12/05 15:50:09  Rainy
  Multi-instance changes.

  Revision 1.2  2002/12/23 14:26:33  rainy
  Made the dialog resizable.

  Revision 1.1  2002/07/01 15:35:55  rainy
  Intial version

*/

#pragma warning(disable: 4786)

#include "Rainmeter.h"
#include "MeterWindow.h"
#include "Measure.h"
#include "resource.h"
#include "AboutDialog.h"
#include <commctrl.h>

extern CRainmeter* Rainmeter;

INT_PTR CALLBACK AboutProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam);
HWND g_DialogWin = NULL;

struct PLUGIN_INFO
{
	std::string name;
	UINT version;
	std::string author;
};
std::vector<PLUGIN_INFO> g_Plugins;

HWND OpenAboutDialog(HWND hwndOwner, HINSTANCE instance)
{
	if (g_DialogWin == NULL)
	{
		g_DialogWin = CreateDialog(instance, MAKEINTRESOURCE(IDD_ABOUT_DIALOG), hwndOwner, AboutProc);
	}
	ShowWindow(g_DialogWin, SW_SHOWNORMAL);
	UpdateAboutStatistics();

	return g_DialogWin;
}

void UpdateAboutStatistics()
{
	if (g_DialogWin != NULL && IsWindowVisible(g_DialogWin))
	{
		HWND widget;
		widget = GetDlgItem(g_DialogWin, IDC_CONFIG_TAB);
		int selected = TabCtrl_GetCurSel(widget);
		int current = 0;
	
		widget = GetDlgItem(g_DialogWin, IDC_STATISTICS);
		SendMessage(widget, WM_SETREDRAW, 0, 0);

		std::map<std::string, CMeterWindow*>& windows = Rainmeter->GetAllMeterWindows();

		std::map<std::string, CMeterWindow*>::iterator iter = windows.begin();
		for( ; iter != windows.end(); iter++)
		{
			if (current == selected)
			{
				ListView_DeleteAllItems(widget);

				CMeterWindow* meterWindow = (*iter).second;
				std::list<CMeasure*>& measures = meterWindow->GetMeasures();

				std::list<CMeasure*>::iterator i = measures.begin();
				for( ; i != measures.end(); i++)
				{
					const char* name = (*i)->GetName();
					const char* val = (*i)->GetStats();
					
					LVITEM vitem;
					vitem.mask = LVIF_TEXT;
					vitem.iItem = 0; 

					if (name && strlen(name) > 0)
					{
						vitem.iSubItem = 0;
						vitem.pszText = (char*)name;
						ListView_InsertItem(widget, &vitem);

						if (val && strlen(val) > 0)
						{
							ListView_SetItemText(widget, 0, 1, (char*)val);
						}
					}
				}

				HWND author = GetDlgItem(g_DialogWin, IDC_AUTHOR_STRING);
				std::string authorString = "Author: ";
				authorString += meterWindow->GetSkinAuthor();
				SetWindowText(author, authorString.c_str());
				break;
			}
			current++;
		}

		SendMessage(widget, WM_SETREDRAW, 1, 0);
	}
}

void UpdateWidgets(HWND window) 
{
	HWND widget;
	widget = GetDlgItem(g_DialogWin, IDC_CONFIG_TAB);
	int selected = TabCtrl_GetCurSel(widget);
	int count = TabCtrl_GetItemCount(widget);

	widget = GetDlgItem(g_DialogWin, IDC_STATISTICS);
	ListView_DeleteAllItems(widget);

	if (count == selected + 1)
	{
		LVCOLUMN lvc; 
		lvc.mask = LVCF_TEXT; 
		lvc.pszText = "Plugin";
		ListView_SetColumn(widget, 0, &lvc);
		lvc.pszText = "Version";
		ListView_SetColumn(widget, 1, &lvc);

		// Update the list of plugins
		std::vector<PLUGIN_INFO>::iterator iter = g_Plugins.begin();
		LVITEM vitem;
		vitem.mask = LVIF_TEXT;

		int i = 0;
		for ( ; iter != g_Plugins.end(); iter++)
		{
			if (!(*iter).name.empty())
			{
				vitem.iItem = i;
				vitem.iSubItem = 0;
				vitem.pszText = (char*)(*iter).name.c_str();
				ListView_InsertItem(widget, &vitem);
			}

			if ((*iter).version != 0)
			{
				char buffer[256];
				sprintf(buffer, "%i.%i", (*iter).version / 1000, (*iter).version % 1000);
				ListView_SetItemText(widget, i, 1, buffer);
			}
			i++;
		}

		if (g_Plugins.size() > 0)
		{
			ListView_SetItemState(widget, 0, LVIS_SELECTED, LVIS_SELECTED);
		}

		widget = GetDlgItem(g_DialogWin, IDC_AUTHOR_STRING);
		SetWindowText(widget, "");	
	}
	else
	{
		LVCOLUMN lvc; 
		lvc.mask = LVCF_TEXT; 
		lvc.pszText = "Measure";
		ListView_SetColumn(widget, 0, &lvc);
		lvc.pszText = "Value";
		ListView_SetColumn(widget, 1, &lvc);
	}
}

typedef LPCTSTR (*GETPLUGINAUTHOR)();
typedef UINT (*GETPLUGINVERSION)();

void ScanPlugins()
{
	std::string files = Rainmeter->GetPath();
	files += "Plugins\\*.dll";

    WIN32_FIND_DATA fileData;      // Data structure describes the file found
    HANDLE hSearch;                // Search handle returned by FindFirstFile

	g_Plugins.clear();

    // Start searching for .ini files in the given directory.
    hSearch = FindFirstFile(files.c_str(), &fileData);
	do
	{
		if(hSearch == INVALID_HANDLE_VALUE) break;    // No more files found

		PLUGIN_INFO info;
		info.name = fileData.cFileName;
		info.version = 0;

		// Try to get the version and author
		std::string tmpSz = Rainmeter->GetPath();
		tmpSz += "Plugins\\";
		tmpSz += fileData.cFileName;
		HMODULE dll = LoadLibrary(tmpSz.c_str());
		if (dll)
		{
			GETPLUGINAUTHOR GetAuthorFunc = (GETPLUGINAUTHOR)GetProcAddress(dll, "GetPluginAuthor");
			if (GetAuthorFunc)
			{
				LPCSTR author = GetAuthorFunc();
				if (author && strlen(author) > 0)
				{
					info.author = author;
				}
			}
			
			GETPLUGINVERSION GetVersionFunc = (GETPLUGINVERSION)GetProcAddress(dll, "GetPluginVersion");
			if (GetVersionFunc)
			{
				info.version = GetVersionFunc();
			}
			FreeLibrary(dll);
		}

		g_Plugins.push_back(info);
	}
	while(FindNextFile(hSearch, &fileData));

    FindClose(hSearch);
}

BOOL OnInitAboutDialog(HWND window) 
{
	char tmpSz[256];
	HWND widget;

	widget = GetDlgItem(window, IDC_VERSION_STRING);
	sprintf(tmpSz, "%s version %s", APPNAME, APPVERSION);
	SetWindowText(widget, tmpSz);

	widget = GetDlgItem(window, IDC_BUILD_STRING);
	sprintf(tmpSz, "Build on %s", __DATE__);
	SetWindowText(widget, tmpSz);

	// Add tabs for each config
	widget = GetDlgItem(window, IDC_CONFIG_TAB);
	TCITEM tie; 
	tie.mask = TCIF_TEXT; 
	std::map<std::string, CMeterWindow*>& windows = Rainmeter->GetAllMeterWindows();
	std::map<std::string, CMeterWindow*>::iterator iter = windows.begin();
	int i = 0;
	for( ; iter != windows.end(); iter++)
	{
		CMeterWindow* meterWindow = (*iter).second;

		tie.pszText = (char*)meterWindow->GetSkinName().c_str();
		TabCtrl_InsertItem(widget, i++, &tie);
	}
	tie.pszText = "Plugins";
	TabCtrl_InsertItem(widget, i, &tie);

	// Add columns to the list view
	widget = GetDlgItem(window, IDC_STATISTICS);

	ListView_SetExtendedListViewStyleEx(widget, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);

    LVCOLUMN lvc; 
    lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 
    lvc.iSubItem = 0;
    lvc.pszText = "Measure";
    lvc.cx = 150;
    lvc.fmt = LVCFMT_LEFT;  // left-aligned column
    ListView_InsertColumn(widget, 0, &lvc);
    lvc.iSubItem = 1;
    lvc.cx = 130;
    lvc.pszText = "Value";	
    ListView_InsertColumn(widget, 1, &lvc);

	ScanPlugins();
	UpdateWidgets(window);

	g_DialogWin = window;

	return TRUE;
}

INT_PTR CALLBACK AboutProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam) 
{
    switch (message) 
    { 
        case WM_INITDIALOG:
			return OnInitAboutDialog(hwndDlg);

		case WM_WINDOWPOSCHANGING:
			{
				WINDOWPOS* pos = (WINDOWPOS*)lParam;

				pos->cx = max(280, pos->cx);
				pos->cy = max(280, pos->cy);
			}
			break;

		case WM_SIZE:
			{
				RECT r, br, ar, sr;
				HWND widget;

				GetClientRect(hwndDlg, &r);
				GetClientRect(GetDlgItem(hwndDlg, IDOK), &br);
				GetClientRect(GetDlgItem(hwndDlg, IDC_STATIC_ABOUT), &ar);
				GetClientRect(GetDlgItem(hwndDlg, IDC_VERSION_STRING), &sr);

				// Reposition the statistics widgets
				widget = GetDlgItem(hwndDlg, IDC_STATIC_ABOUT);
				SetWindowPos(widget, NULL, 0, 0, r.right - 22, ar.bottom, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDC_VERSION_STRING);
				SetWindowPos(widget, NULL, 0, 0, r.right - 44, sr.bottom, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDC_BUILD_STRING);
				SetWindowPos(widget, NULL, 0, 0, r.right - 44, sr.bottom, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDC_URL_STRING);
				SetWindowPos(widget, NULL, 0, 0, r.right - 44, sr.bottom, SWP_NOMOVE | SWP_NOZORDER);

				widget = GetDlgItem(hwndDlg, IDC_CONFIG_TAB);
				SetWindowPos(widget, NULL, 0, 0, r.right - 22, r.bottom - 150, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDC_AUTHOR_STRING);
				SetWindowPos(widget, NULL, 0, 0, r.right - 44, sr.bottom, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDC_STATISTICS);
				SetWindowPos(widget, NULL, 0, 0, r.right - 44, r.bottom - 210, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDOK);
				SetWindowPos(widget, NULL, (r.right - br.right) / 2, r.bottom - br.bottom - 11, br.right, br.bottom, SWP_NOZORDER);
			}
			break;

		case WM_NOTIFY:
			{
			    LPNMHDR lpnmhdr = (LPNMHDR)lParam; 
				if (lpnmhdr->code == TCN_SELCHANGE)
				{
					UpdateWidgets(hwndDlg);
					UpdateAboutStatistics();
				} 
				else if (lpnmhdr->code == NM_CLICK)
				{
					HWND widget;
					widget = GetDlgItem(g_DialogWin, IDC_CONFIG_TAB);
					int selected = TabCtrl_GetCurSel(widget);
					int count = TabCtrl_GetItemCount(widget);
				    LPNMITEMACTIVATE lpnmitem = (LPNMITEMACTIVATE)lParam;
					int item = lpnmitem->iItem;

					if (count == selected + 1)
					{
						if (item >= 0 && item < g_Plugins.size())
						{
							widget = GetDlgItem(g_DialogWin, IDC_AUTHOR_STRING);
							std::string author = "Author: ";
							author += g_Plugins[item].author;

							SetWindowText(widget, author.c_str());
						}
					}
				}
			}
			break;

		case WM_CLOSE:
			DestroyWindow(hwndDlg);
			g_DialogWin = NULL;
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
				DestroyWindow(hwndDlg);
				g_DialogWin = NULL;
				return TRUE;
			}
			break;
	}
    return FALSE;
}

