/*
  Copyright (C) 2002 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterRoundLine.cpp,v 1.4 2004/07/11 17:18:07 rainy Exp $

  $Log: MeterRoundLine.cpp,v $
  Revision 1.4  2004/07/11 17:18:07  rainy
  Relative coordinate support.

  Revision 1.3  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.2  2003/02/10 18:12:44  rainy
  Now uses GDI+

  Revision 1.1  2002/12/26 18:15:41  rainy
  Initial version

*/

#include "MeterRoundLine.h"
#include "Measure.h"
#include "Error.h"
#include <crtdbg.h>
#include <math.h>
#include <gdiplus.h>

using namespace Gdiplus;
#define PI 3.14159265

/*
** CMeterRoundLine
**
** The constructor
**
*/
CMeterRoundLine::CMeterRoundLine() : CMeter()
{
	m_AntiAlias = false;
	m_LineWidth = 1.0;
	m_LineLength = 20;
	m_StartAngle = 0.0;
	m_RotationAngle = 0.0;
	m_ValueReminder = 0;
	m_Solid = false;
	m_Value = 0.0;
}

/*
** ~CMeterRoundLine
**
** The destructor
**
*/
CMeterRoundLine::~CMeterRoundLine()
{
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterRoundLine::ReadConfig(CMeterWindow& meterWindow, const char* section)
{
	// Read common configs
	CMeter::ReadConfig(meterWindow, section);

	CConfigParser& parser = meterWindow.GetParser();

	m_LineWidth = parser.ReadFloat(section, "LineWidth", 1.0);
	m_LineLength = parser.ReadFloat(section, "LineLength", 20.0);
	m_StartAngle = parser.ReadFloat(section, "StartAngle", 0.0);
	m_RotationAngle = parser.ReadFloat(section, "RotationAngle", 6.2832);
	m_AntiAlias = 0!=parser.ReadInt(section, "AntiAlias", 0);
	m_ValueReminder = parser.ReadInt(section, "ValueReminder", 0);
	m_LineColor = parser.ReadColor(section, "LineColor", Color::Black);
	m_Solid = 0!=parser.ReadInt(section, "Solid", 0);
}

/*
** Update
**
** Updates the value(s) from the measures.
**
*/
bool CMeterRoundLine::Update(CMeterWindow& meterWindow)
{
	if (CMeter::Update(meterWindow) && m_Measure)
	{
		if (m_ValueReminder > 0)
		{
			m_Value = (UINT)m_Measure->GetValue() % m_ValueReminder;
			m_Value /= (double)m_ValueReminder;
		}
		else
		{
			m_Value = m_Measure->GetRelativeValue();
		}
		return true;
	}

	return false;
}


/*
** Draw
**
** Draws the meter on the double buffer
**
*/
bool CMeterRoundLine::Draw(CMeterWindow& meterWindow)
{
	if(!CMeter::Draw(meterWindow)) return false;

	Graphics graphics(meterWindow.GetDoubleBuffer());		//GDI+
	if (m_AntiAlias)
	{
		graphics.SetSmoothingMode(SmoothingModeAntiAlias);
	}

	// Calculate the center of for the line
	int x = GetX();
	int y = GetY();
	REAL cx = x + m_W / 2.0;
	REAL cy = y + m_H / 2.0;

	if (m_Solid)
	{
		// Calculate the center of for the line

		SolidBrush solidBrush(m_LineColor);
		graphics.FillPie(&solidBrush, (REAL)(cx - m_LineLength), (REAL)(cy - m_LineLength), m_LineLength * 2.0, m_LineLength * 2.0, m_StartAngle * 180.0 / PI, m_RotationAngle * m_Value * 180.0 / PI);
	}
	else
	{
		REAL x, y;

		Pen pen(m_LineColor, m_LineWidth);

		// Calculate the end point of the line
		double angle = m_RotationAngle * m_Value + m_StartAngle;

		y = sin(angle);
		x = cos(angle);

		// Set the length
		x = x * m_LineLength + cx;
		y = y * m_LineLength + cy;

		graphics.DrawLine(&pen, cx, cy, x, y);
	}

	return true;
}
