/*
  Copyright (C) 2004 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/ConfigParser.cpp,v 1.1 2004/06/05 10:55:54 rainy Exp $

  $Log: ConfigParser.cpp,v $
  Revision 1.1  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

*/

#pragma warning(disable: 4786)

#include "ConfigParser.h"
#include "Litestep.h"
#include "Rainmeter.h"

extern CRainmeter* Rainmeter;

using namespace Gdiplus;

/*
** CConfigParser
**
** The constructor
**
*/
CConfigParser::CConfigParser()
{
}

/*
** ~CConfigParser
**
** The destructor
**
*/
CConfigParser::~CConfigParser()
{
}

/*
** Initialize
**
**
*/
CConfigParser::Initialize(LPCTSTR filename)
{
	m_Filename = filename;
	ReadVariables();
}

/*
** ReadVariables
**
**
*/
void CConfigParser::ReadVariables()
{
	DWORD size;
	TCHAR* buffer;
	TCHAR* variable;
	int bufferSize = 4096;
	bool loop;

	m_Variables.clear();
	do 
	{
		loop = false;
		buffer = new TCHAR[bufferSize];
		
		size = GetPrivateProfileString("Variables", NULL, "", buffer, bufferSize, m_Filename.c_str());

		if (size == bufferSize - 1)
		{
			// Buffer too small, increase it and retry
			delete [] buffer;
			bufferSize *= 2;
			loop = true;
		}

	} while(loop);

	if (size > 0)
	{
		variable = new TCHAR[bufferSize];

		// Read all variables
		char* pos = buffer;
		while(strlen(pos) > 0)
		{
			do 
			{
				loop = false;
				size = GetPrivateProfileString("Variables", pos, "", variable, bufferSize, m_Filename.c_str());

				if (size == bufferSize - 1)
				{
					// Buffer too small, increase it and retry
					delete [] variable;
					bufferSize *= 2;
					variable = new TCHAR[bufferSize];
					loop = true;
				}

			} while(loop);

			if (strlen(variable) > 0)
			{
				m_Variables[pos] = variable;
			}

			pos = pos + strlen(pos) + 1;
		}

		delete [] variable;
	}
	delete [] buffer;
}

/*
** ReadString
**
**
*/
const std::string& CConfigParser::ReadString(LPCTSTR section, LPCTSTR key, LPCTSTR defValue)
{
	static std::string result;
	DWORD size;
	TCHAR* buffer;
	int bufferSize = 4096;
	bool loop;

	do 
	{
		loop = false;
		buffer = new TCHAR[bufferSize];
		buffer[0] = 0;
		
		size = GetPrivateProfileString(section, key, defValue, buffer, bufferSize, m_Filename.c_str());

		if (size == bufferSize - 1)
		{
			// Buffer too small, increase it and retry
			delete [] buffer;
			bufferSize *= 2;
			loop = true;
		}

	} while(loop);

	result = buffer;

	delete [] buffer;

	// Check Litestep vars
	if (Rainmeter && !Rainmeter->GetDummyLitestep())
	{
		char buffer[4096];	// lets hope the buffer is large enough...

		if (result.size() < 4096)
		{
			VarExpansion(buffer, result.c_str());
			result = buffer;
		}
	}

	// Check for variables (#VAR#)
	int start = 0;
	int end = -1;
	int pos = -1;
	loop = true;

	do 
	{
		pos = result.find('#', start);
		if (pos != -1)
		{
			int end = result.find('#', pos + 1);
			if (end != -1)
			{
				std::string var(result.begin() + pos + 1, result.begin() + end);
				
				std::map<std::string, std::string>::iterator iter = m_Variables.find(var);
				if (iter != m_Variables.end())
				{
					// Variable found, replace it with the value
					result.replace(result.begin() + pos, result.begin() + end + 1, (*iter).second);
					start = pos + (*iter).second.length();
				}
				else
				{
					start = end;
				}
			}
			else
			{
				loop = false;
			}
		}
		else
		{
			loop = false;
		}
	} while(loop);

	return result;
}


double CConfigParser::ReadFloat(LPCTSTR section, LPCTSTR key, double defValue)
{
	TCHAR buffer[256];
	sprintf(buffer, "%f", defValue);

	const std::string& result = ReadString(section, key, buffer);

	return atof(result.c_str());
}

int CConfigParser::ReadInt(LPCTSTR section, LPCTSTR key, int defValue)
{
	TCHAR buffer[256];
	sprintf(buffer, "%i", defValue);

	const std::string& result = ReadString(section, key, buffer);

	return atoi(result.c_str());
}

Color CConfigParser::ReadColor(LPCTSTR section, LPCTSTR key, Color defValue)
{
	TCHAR buffer[256];
	sprintf(buffer, "%i, %i, %i, %i", defValue.GetR(), defValue.GetG(), defValue.GetB(), defValue.GetA());

	const std::string& result = ReadString(section, key, buffer);

	return ParseColor(result.c_str());
}

/*
** ParseColor
**
** This is a helper method that parses the color values from the given string.
** The color can be supplied as three/four comma separated values or as one 
** hex-value.
**
*/
Color CConfigParser::ParseColor(LPCTSTR string)
{
	int R, G, B, A;

	if(strchr(string, ',') != NULL)
	{
		char* parseSz = _strdup(string);
		char* token;

		token = strtok(parseSz, ",");
		if (token != NULL)
		{
			R = atoi(token);
		}
		else
		{
			R = 255;
		}
		token = strtok( NULL, ",");
		if (token != NULL)
		{
			G = atoi(token);
		}
		else
		{
			G = 255;
		}
		token = strtok( NULL, ",");
		if (token != NULL)
		{
			B = atoi(token);
		}
		else
		{
			B = 255;
		}
		token = strtok( NULL, ",");
		if (token != NULL)
		{
			A = atoi(token);
		}
		else
		{
			A = 255;
		}
		free(parseSz);
	} 
	else
	{
		const char* start = string;

		if(strncmp(string, "0x", 2) == 0)
		{
			start = string + 2;
		}

		if (strlen(string) > 6 && !isspace(string[6]))
		{
			sscanf(string, "%02x%02x%02x%02x", &R, &G, &B, &A);
		} 
		else 
		{
			sscanf(string, "%02x%02x%02x", &R, &G, &B);
			A = 255;	// Opaque
		}
	}

	return Color(A, R, G, B);
}
