/*
  Copyright (C) 2004 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/ConfigParser.h,v 1.1 2004/06/05 10:55:54 rainy Exp $

  $Log: ConfigParser.h,v $
  Revision 1.1  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

*/

#ifndef __CONFIGPARSER_H__
#define __CONFIGPARSER_H__

#include <windows.h>
#include <map>
#include <string>
#include <gdiplus.h>

class CConfigParser
{
public:
	CConfigParser();
	~CConfigParser();

	Initialize(LPCTSTR filename);

	const std::string& ReadString(LPCTSTR section, LPCTSTR key, LPCTSTR defValue);
	double ReadFloat(LPCTSTR section, LPCTSTR key, double defValue);
	int ReadInt(LPCTSTR section, LPCTSTR key, int defValue);
	Gdiplus::Color ReadColor(LPCTSTR section, LPCTSTR key, Gdiplus::Color defValue);

	std::string& GetFilename() { return m_Filename; }

private:
	void ReadVariables();
	Gdiplus::Color ParseColor(LPCTSTR string);

	std::map<std::string, std::string> m_Variables;
	std::string m_Filename;
};

#endif
