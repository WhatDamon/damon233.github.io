/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeasureTime.cpp,v 1.7 2004/07/11 17:15:36 rainy Exp $

  $Log: MeasureTime.cpp,v $
  Revision 1.7  2004/07/11 17:15:36  rainy
  Fixed localtime calculation.

  Revision 1.6  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.5  2004/03/13 16:17:42  rainy
  Added timezones

  Revision 1.4  2003/02/10 18:13:14  rainy
  Returns the time in secs as value.

  Revision 1.3  2002/04/26 18:24:15  rainy
  Modified the Update method to support disabled measures.

  Revision 1.2  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.1  2001/12/23 10:11:08  rainy
  Initial version.

*/

#include "MeasureTime.h"
#include "Rainmeter.h"
#include <time.h>

/*
** CMeasureTime
**
** The constructor
**
*/
CMeasureTime::CMeasureTime() : CMeasure()
{
	/* Set time zone from TZ environment variable. If TZ is not set,
     * the operating system is queried to obtain the default value 
     * for the variable. 
     */
    _tzset();

	m_DeltaTime = 0.0;
	m_Time = 0;
}

/*
** ~CMeasureTime
**
** The destructor
**
*/
CMeasureTime::~CMeasureTime()
{
}

/*
** Update
**
** Updates the current time
**
*/
bool CMeasureTime::Update(CMeterWindow* meterWindow)
{
	if (!CMeasure::PreUpdate(meterWindow)) return false;

	time(&m_Time);

	// Modify the ltime to match the current timezone
	// This way we can use the value also for the clock
	m_Time += m_DeltaTime;
	m_Value = m_Time;
	
	if (m_Format.size() != 0)
	{
		// If there is some date format, parse the value from it instead
		char tmpSz[MAX_LINE_LENGTH];
		struct tm* today;
		today = gmtime(&m_Time);
		strftime(tmpSz, MAX_LINE_LENGTH, m_Format.c_str(), today);

		m_Value = atof(tmpSz);
	}

	return PostUpdate(meterWindow);
}

/*
** GetStringValue
**
** Returns the time as string.
**
*/
const char* CMeasureTime::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char tmpSz[MAX_LINE_LENGTH];
	struct tm* today;

	today = gmtime(&m_Time);

	// Create the string
	if (m_Format.size() > 0)
	{
		strftime(tmpSz, MAX_LINE_LENGTH, m_Format.c_str(), today);
	}
	else
	{
		strftime(tmpSz, MAX_LINE_LENGTH, "%H:%M:%S", today);
	}

	return CheckSubstitute(tmpSz);
}

/*
** ReadConfig
**
** Reads the measure specific configs.
**
*/
void CMeasureTime::ReadConfig(CConfigParser& parser, const char* section)
{
	CMeasure::ReadConfig(parser, section);

	m_Format = parser.ReadString(section, "Format", "");

	std::string timezone;
	timezone = parser.ReadString(section, "TimeZone", "local");
	bool dst = 1 == parser.ReadInt(section, "DaylightSavingTime", 1);

	struct tm* today;
	time_t gtime;

	time(&gtime);
	today = localtime(&gtime);
	
	if (stricmp("local", timezone.c_str()) == 0)
	{
		today = gmtime(&gtime);

		time_t ltime = mktime(today);
		m_DeltaTime = gtime - ltime;
	}
	else
	{
		double zone = atof(timezone.c_str());

		if (dst && today->tm_isdst)
		{
			// Add DST
			TIME_ZONE_INFORMATION tzi;
			GetTimeZoneInformation(&tzi);

			m_DeltaTime = zone * 3600.0 - tzi.DaylightBias * 60;
		}
		else
		{
			m_DeltaTime = zone * 3600.0;
		}
	}
}
