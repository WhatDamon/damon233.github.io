/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: /home/cvsroot/Rainmeter/Plugin/MeterRotator.cpp,v 1.4 2004/08/13 15:46:43 rainy Exp $

  $Log: MeterRotator.cpp,v $
  Revision 1.4  2004/08/13 15:46:43  rainy
  Added LineStart.
  Reminder->Remainder.

  Revision 1.3  2004/07/11 17:18:07  rainy
  Relative coordinate support.

  Revision 1.2  2004/06/05 10:55:54  rainy
  Too much changes to be listed in here...

  Revision 1.1  2004/03/13 16:18:43  rainy
  Initial version

*/

#pragma warning(disable: 4786)

#include "MeterRotator.h"
#include "Measure.h"
#include "Error.h"
#include "Litestep.h"

using namespace Gdiplus;

/*
** CMeterRotator
**
** The constructor
**
*/
CMeterRotator::CMeterRotator() : CMeter()
{
	m_Bitmap = NULL;
	m_Value = 0.0;
}

/*
** ~CMeterRotator
**
** The destructor
**
*/
CMeterRotator::~CMeterRotator()
{
	if(m_Bitmap != NULL) delete m_Bitmap;
}

/*
** Initialize
**
** Load the image & configs.
**
*/
void CMeterRotator::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	// Load the bitmaps if defined
	if(!m_ImageName.empty())
	{
		WCHAR* wideSz = ConvertToWide(m_ImageName.c_str());
		m_Bitmap = new Bitmap(wideSz);
		delete [] wideSz;

		Status status = m_Bitmap->GetLastStatus();
		if(Ok != status)
		{
            throw CError(std::string("Bitmap image not found: ") + m_ImageName, __LINE__, __FILE__);
		}
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterRotator::ReadConfig(CMeterWindow& meterWindow, const char* section)
{
	// Read common configs
	CMeter::ReadConfig(meterWindow, section);

	CConfigParser& parser = meterWindow.GetParser();

	m_ImageName = parser.ReadString(section, "ImageName", "");

	m_OffsetX = parser.ReadFloat(section, "OffsetX", 0.0);
	m_OffsetY = parser.ReadFloat(section, "OffsetY", 0.0);
	m_StartAngle = parser.ReadFloat(section, "StartAngle", 0.0);
	m_RotationAngle = parser.ReadFloat(section, "RotationAngle", 6.2832);

	m_ValueRemainder = parser.ReadInt(section, "ValueReminder", 0);		// Typo
	m_ValueRemainder = parser.ReadInt(section, "ValueRemainder", m_ValueRemainder);
}

/*
** Update
**
** Updates the value(s) from the measures.
**
*/
bool CMeterRotator::Update(CMeterWindow& meterWindow)
{
	if (CMeter::Update(meterWindow) && m_Measure)
	{
		if (m_ValueRemainder > 0)
		{
			m_Value = (int)m_Measure->GetValue() % m_ValueRemainder;
			m_Value /= (double)m_ValueRemainder;
		}
		else
		{
			m_Value = m_Measure->GetRelativeValue();
		}
		return true;
	}
	return false;
}


/*
** Draw
**
** Draws the meter on the double buffer
**
*/
bool CMeterRotator::Draw(CMeterWindow& meterWindow)
{
	if(!CMeter::Draw(meterWindow)) return false;

	// Calculate the center for rotation
	int x = GetX();
	int y = GetY();

	double cx = x + m_W / 2.0;
	double cy = y + m_H / 2.0;

	// Calculate the rotation
	double angle = m_RotationAngle * m_Value + m_StartAngle;

	Graphics graphics(meterWindow.GetDoubleBuffer());

	angle = angle * 180.0 / 3.14159265;		// Convert to degrees

	graphics.TranslateTransform(cx, cy);
	graphics.RotateTransform(angle);
	graphics.TranslateTransform(-m_OffsetX, -m_OffsetY);

	if(m_Bitmap)
	{
		UINT width = m_Bitmap->GetWidth();
		UINT height = m_Bitmap->GetHeight();

		// Blit the image
		graphics.DrawImage(m_Bitmap, 0, 0, width, height);
	}

	return true;
}

