/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Error.cpp,v 1.1.1.1 2001/08/11 10:58:19 Rainy Exp $

  $Log: Error.cpp,v $
  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "Error.h"
#include <stdio.h>

std::string CError::c_String;
int CError::c_Line=0;
const char* CError::c_File=NULL;
CError::RAINERROR CError::c_Error=ERROR_USER;

const char* CError::c_ErrorStrings[] = 
{
	"User defined error",
	"Out of memory",
	"Null parameter",
	"Unable to register windowclass",
	"Unable to create window"
};

/* 
** GetString
**
** Returns the error string
**
*/
const std::string& CError::GetString()
{
	static char Buffer[16];

	if(c_Error!=ERROR_USER) 
	{
		c_String = c_ErrorStrings[c_Error];
		if(c_File) 
		{
			sprintf(Buffer, "%i", c_Line);

			c_String += "\n(";
			c_String += c_File;
			c_String += " : ";
			c_String += Buffer;
			c_String += ")";
		}
	}

	return c_String; 
}
