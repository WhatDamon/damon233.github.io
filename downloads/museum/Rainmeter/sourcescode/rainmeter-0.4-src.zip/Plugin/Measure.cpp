/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Measure.cpp,v 1.4 2001/09/01 13:00:41 rainy Exp $

  $Log: Measure.cpp,v $
  Revision 1.4  2001/09/01 13:00:41  rainy
  Slight changes in the interface. The value is now measured only once if possible.
  Added support for logging the max value.

  Revision 1.3  2001/08/19 09:15:41  rainy
  Invert was moved here from the meter.

  Revision 1.2  2001/08/12 15:47:00  Rainy
  Adjusted Update()'s interface.
  Added GetStringValue() method.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "Measure.h"
#include "Rainmeter.h"

CMeasure::CMeasure()
{
	m_Invert = false;
	m_LogMaxValue = false;
	m_MaxValue = 1;
}

CMeasure::~CMeasure()
{
}

void CMeasure::ReadConfig(const char* filename, const char* section)
{
	m_Invert = 0!=GetPrivateProfileInt(section, "InvertMeasure", 0, filename);
}

bool CMeasure::Update(CMeterWindow& meterWindow, int counter)
{
	if(m_LogMaxValue)
	{
		m_MaxValue = max(m_MaxValue, GetMeasuredValue());
	}

	if(counter == GetCounter())
	{
		return true;	// The Value is already valid, no need tuo update
	}

	return false;
}

UINT CMeasure::GetValue()
{
	// Invert if so requested
	if(m_Invert)
	{
		return m_MaxValue - GetMeasuredValue();
	}
	return GetMeasuredValue();
}

char* CMeasure::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char buffer[MAX_LINE_LENGTH];
	static char buffer2[MAX_LINE_LENGTH];
	char* format;
	double value;

	UINT theValue = GetValue();

	if(percentual)
	{
		sprintf(buffer, "%i", (UINT)(100.0 * (double)theValue / (double)GetDefaultMaxValue()));
	} 
	else if(autoScale)
	{
		if(theValue > 1000 * 1000 * 1000)
		{
			format = "%.1f G";
			value = (double)(theValue / (1024 * 1024)) / 1024.0;
		}
		else if(theValue > 1000 * 1000)
		{
			format = "%.1f M";
			value = (double)(theValue / 1024) / 1024.0;
		}
		else if(theValue > 1000)
		{
			format = "%.1f k";
			value = (double)(theValue) / 1024.0;
		}
		else
		{
			format = "%.0f ";
			value = (double)theValue;
		}
		sprintf(buffer, format, value);
	}
	else 
	{
		if(decimals == 0)
		{
			sprintf(buffer, "%i", (UINT)(theValue * (1.0 / scale) + 0.5));
		}
		else
		{
			sprintf(buffer2, "%%.%if", decimals);
			sprintf(buffer, buffer2, (double)(theValue * (1.0 / scale)));
		}
	}

	return buffer;
}
