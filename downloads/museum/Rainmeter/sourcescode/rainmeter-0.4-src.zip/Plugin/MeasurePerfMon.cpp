/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasurePerfMon.cpp,v 1.2 2001/09/01 13:00:09 rainy Exp $

  $Log: MeasurePerfMon.cpp,v $
  Revision 1.2  2001/09/01 13:00:09  rainy
  Slight changes in the interface. The value is now measured only once if possible.

  Revision 1.1  2001/08/19 09:09:37  rainy
  Initial version.

*/

#include "MeasurePerfMon.h"
#include "../PerfMon/PerfSnap.h"
#include "../PerfMon/PerfObj.h"
#include "../PerfMon/PerfCntr.h"
#include "../PerfMon/ObjList.h"
#include "../PerfMon/ObjInst.h"

CPerfTitleDatabase CMeasurePerfMon::g_CounterTitles( PERF_TITLE_COUNTER );
int CMeasurePerfMon::c_Counter = -1;

CMeasurePerfMon::CMeasurePerfMon() : CMeasure()
{
	m_Difference = false;
	m_FirstTime = true;
	m_OldValue = 0;
	m_Value = 0;
}

CMeasurePerfMon::~CMeasurePerfMon()
{
}

bool CMeasurePerfMon::Update(CMeterWindow& meterWindow, int counter)
{
	CMeasure::Update(meterWindow, counter);
	c_Counter = counter;

	// Need to update always

	if(meterWindow.IsNT())	// This only works in NT
	{
		CPerfObject* pPerfObj;
		CPerfObjectInstance* pObjInst;
		CPerfCounter* pPerfCntr;
		BYTE data[256];
		char name[256];
		ULONGLONG value;

		CPerfSnapshot snapshot( &g_CounterTitles );
		CPerfObjectList objList( &snapshot, &g_CounterTitles );

		if(snapshot.TakeSnapshot( m_ObjectName.c_str() ))
		{
			pPerfObj = objList.GetPerfObject(m_ObjectName.c_str());

			for(pObjInst = pPerfObj->GetFirstObjectInstance();
				pObjInst != NULL;
				pObjInst = pPerfObj->GetNextObjectInstance())
			{
				if(pObjInst->GetObjectInstanceName(name, 256) || m_InstanceName.empty())
				{
					if(m_InstanceName.empty() || _stricmp(m_InstanceName.c_str(), name) == 0)
					{
						pPerfCntr = pObjInst->GetCounterByName(m_CounterName.c_str());
						if(pPerfCntr != NULL)
						{
							pPerfCntr->GetData(data, 256, NULL);
							
							if(pPerfCntr->GetSize() == 1)
							{
								value = *(BYTE*)data;
							} 
							else if(pPerfCntr->GetSize() == 2)
							{
								value = *(WORD*)data;
							}
							else if(pPerfCntr->GetSize() == 4)
							{
								value = *(DWORD*)data;
							}
							else if(pPerfCntr->GetSize() == 8)
							{
								value = *(ULONGLONG*)data;
							}

							if(m_Difference)
							{
								// Compare with the old value
								if(!m_FirstTime) 
								{
									m_Value = value - m_OldValue;
								}
								m_OldValue = value;
								m_FirstTime = false;
							}
							else
							{
								m_Value = value;
							}


							delete pPerfCntr;
						}
						delete pObjInst;
						break;	// No need to continue
					}
				}
					
				delete pObjInst;
			}

			delete pPerfObj;
		}
	}

	return false;
}

void CMeasurePerfMon::ReadConfig(const char* filename, const char* section)
{
	CMeasure::ReadConfig(filename, section);

	char buffer[256];

	if(GetPrivateProfileString( section, "PerfMonObject", "", buffer, 255, filename) > 0) 
	{
 		m_ObjectName = buffer;
	}

	if(GetPrivateProfileString( section, "PerfMonCounter", "", buffer, 255, filename) > 0) 
	{
 		m_CounterName = buffer;
	}

	if(GetPrivateProfileString( section, "PerfMonInstance", "", buffer, 255, filename) > 0) 
	{
 		m_InstanceName = buffer;
	}

	m_Difference = 0!=GetPrivateProfileInt(section, "PerfMonDifference", 1, filename);

	int value = GetPrivateProfileInt(section, "PerfMonMaxValue", 0, filename);

	if(value == 0)
	{
		m_MaxValue = 1;
		m_LogMaxValue = true;
	}
	else
	{
		m_MaxValue = value;
	}
}


