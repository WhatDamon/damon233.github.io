/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasurePerfMon.h,v 1.2 2001/09/01 13:00:09 rainy Exp $

  $Log: MeasurePerfMon.h,v $
  Revision 1.2  2001/09/01 13:00:09  rainy
  Slight changes in the interface. The value is now measured only once if possible.

  Revision 1.1  2001/08/19 09:09:37  rainy
  Initial version.

*/

#ifndef __MEASUREPERFMON_H__
#define __MEASUREPERFMON_H__

#include "Measure.h"
#include "../PerfMon/Titledb.h"

class CMeasurePerfMon : public CMeasure
{
public:
	CMeasurePerfMon();
	virtual ~CMeasurePerfMon();

	virtual bool Update(CMeterWindow& meterWindow, int counter);
	virtual void ReadConfig(const char* filename, const char* section);
	virtual UINT GetMeasuredValue() { return m_Value; };
	virtual int GetCounter() { return c_Counter; };

private:
	std::string m_ObjectName;
	std::string m_CounterName;
	std::string m_InstanceName;
	bool m_Difference;
	ULONGLONG m_OldValue;
	bool m_FirstTime;
	UINT m_Value;

	static int c_Counter;
	static CPerfTitleDatabase g_CounterTitles;
};

#endif
