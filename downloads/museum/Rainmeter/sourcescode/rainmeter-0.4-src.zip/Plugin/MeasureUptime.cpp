/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureUptime.cpp,v 1.1 2001/09/01 12:56:25 rainy Exp $

  $Log: MeasureUptime.cpp,v $
  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.

*/

#include "MeasureUptime.h"
#include "Rainmeter.h"

UINT CMeasureUptime::c_Value = 0;
UINT CMeasureUptime::c_OldTicks = 0;
int CMeasureUptime::c_Counter = -1;

CMeasureUptime::CMeasureUptime() : CMeasure()
{
}

CMeasureUptime::~CMeasureUptime()
{
}

bool CMeasureUptime::Update(CMeterWindow& meterWindow, int counter)
{
	if(CMeasure::Update(meterWindow, counter)) return true;
	c_Counter = counter;

	DWORD ticks = GetTickCount();

	// Dunno if this works, but if it does, the uptime should work bit longer than those 49,7 days
	if(ticks < c_OldTicks)
	{
		// The uptime wrapped!
		c_OldTicks = 0;		// Slight inaccuracy here
	}
	c_Value = c_Value + (ticks - c_OldTicks) / 1000;
	c_OldTicks = ticks;

	return false;
}

char* CMeasureUptime::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char buffer[MAX_LINE_LENGTH];
	
	int value = GetValue();
	int secs = value % 60;
	int mins = (value / 60) % 60;
	int hours = (value / (60 * 60)) % 24;
	int days =  (value / (60 * 60 * 24));

	sprintf(buffer, "%id %i:%02i", days, hours, mins);

	return buffer;
}
