/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterBitmap.cpp,v 1.1 2001/09/01 12:56:25 rainy Exp $

  $Log: MeterBitmap.cpp,v $
  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.


*/

#include "MeterBitmap.h"
#include "Measure.h"
#include "Error.h"
#include <lsapi\lsapi.h>

CMeterBitmap::CMeterBitmap() : CMeter()
{
	m_Bitmap = NULL;
	m_FrameCount = 0;
}

CMeterBitmap::~CMeterBitmap()
{
	if(m_Bitmap != NULL) DeleteObject(m_Bitmap);
}

void CMeterBitmap::Initialize(CMeterWindow& meterWindow)
{
	// Load the bitmaps if defined
	if(!m_ImageName.empty())
	{
		m_Bitmap = LoadLSImage(m_ImageName.c_str(), NULL);

		if(m_Bitmap == NULL)
		{
			std::string errorSz("Bitmap image not found: ");
			errorSz += m_ImageName;
			CError::SetError(errorSz, __LINE__, __FILE__);
			throw true;
		}
		else
		{
			// Get the size form the bitmap
			BITMAP bm;
			GetObject(m_Bitmap, sizeof(BITMAP), &bm);
			m_W = bm.bmWidth;
			m_H = bm.bmHeight;
		}
	}
}

void CMeterBitmap::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "BitmapImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_ImageName = tmpSz;
	}

	m_FrameCount = GetPrivateProfileInt( section, "BitmapFrames", 0, filename);
}

void CMeterBitmap::Update(CMeterWindow& meterWindow, int counter)
{
	int newH, newW, newY, newX;

	if(m_FrameCount == 0 || m_Bitmap == NULL) return;	// Unable to continue

	CMeter::Update(meterWindow, counter);

	double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetDefaultMaxValue());
	int frame = value * m_FrameCount;
	frame = min(frame, (m_FrameCount - 1));

	if(m_H > m_W)
	{
		newH = m_H / m_FrameCount;
		newW = m_W;
		newX = 0;
		newY = frame * newH;
	}
	else
	{
		newW = m_W / m_FrameCount;
		newH = m_H;
		newX = frame * newW;
		newY = 0;
	}


	// Blit the image
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC dc = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_Bitmap);

	TransparentBltLS(bufferDC,
					 m_X,
					 m_Y,
					 newW,
					 newH,
					 dc,
					 newX,
					 newY,
					 RGB(255,0,255));

	SelectObject(dc, oldBM);
	DeleteDC(dc);
}

