/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterHistogram.cpp,v 1.5 2001/09/01 12:58:48 rainy Exp $

  $Log: MeterHistogram.cpp,v $
  Revision 1.5  2001/09/01 12:58:48  rainy
  Removed MaxValues (i.e. they aren't stored anymore).
  Fixed a bug in bitmap histogram placement.

  Revision 1.4  2001/08/25 17:07:28  rainy
  Added support for background images behind the curves.

  Revision 1.3  2001/08/19 09:13:13  rainy
  Invert moved to the measures.

  Revision 1.2  2001/08/12 15:38:54  Rainy
  Adjusted Update()'s interface.
  Added invert for the secondary measure.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "MeterHistogram.h"
#include "Measure.h"
#include "Error.h"
#include <lsapi\lsapi.h>

CMeterHistogram::CMeterHistogram() : CMeter()
{
	m_SecondaryMeasure = NULL;
	m_PrimaryColor = 0;
	m_SecondaryColor = 0;
	m_BothColor = 0;
	m_HistogramBitmap = NULL;
	m_MeterPos = 0;
	m_PrimaryPen = NULL;
	m_SecondaryPen = NULL;
	m_BothPen = NULL;
	m_TransparentPen = NULL;
	m_PrimaryBitmap = NULL;
	m_SecondaryBitmap = NULL;
	m_BothBitmap = NULL;
	m_MaskBitmap = NULL;
}

CMeterHistogram::~CMeterHistogram()
{
	delete m_SecondaryMeasure;

	DeleteObject(m_HistogramBitmap);
	DeleteObject(m_PrimaryPen);
	DeleteObject(m_SecondaryPen);
	DeleteObject(m_BothPen);
	DeleteObject(m_TransparentPen);

	if(m_PrimaryBitmap != NULL) DeleteObject(m_PrimaryBitmap);
	if(m_SecondaryBitmap != NULL) DeleteObject(m_SecondaryBitmap);
	if(m_BothBitmap != NULL) DeleteObject(m_BothBitmap);
	if(m_MaskBitmap != NULL) DeleteObject(m_MaskBitmap);
}

void CMeterHistogram::Initialize(CMeterWindow& meterWindow)
{
	HBITMAP oldBM = NULL;
	RECT rect;
	rect.left = 0;
	rect.right = m_W;
	rect.top = 0;
	rect.bottom = m_H;

	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);

	// Load the bitmaps if defined
	if(!m_PrimaryImageName.empty())
	{
		m_PrimaryBitmap = LoadLSImage(m_PrimaryImageName.c_str(), NULL);

		if(m_PrimaryBitmap == NULL)
		{
			std::string errorSz("PrimaryImage not found: ");
			errorSz += m_PrimaryImageName;
			CError::SetError(errorSz, __LINE__, __FILE__);
			throw true;
		}
	}

	if(!m_SecondaryImageName.empty())
	{
		m_SecondaryBitmap = LoadLSImage(m_SecondaryImageName.c_str(), NULL);

		if(m_SecondaryBitmap == NULL)
		{
			std::string errorSz("SecondaryImage not found: ");
			errorSz += m_SecondaryImageName;
			CError::SetError(errorSz, __LINE__, __FILE__);
			throw true;
		}
	}

	if(!m_BothImageName.empty())
	{
		m_BothBitmap = LoadLSImage(m_BothImageName.c_str(), NULL);

		if(m_BothBitmap == NULL)
		{
			std::string errorSz("BothImage not found: ");
			errorSz += m_BothImageName;
			CError::SetError(errorSz, __LINE__, __FILE__);
			throw true;
		}
	}

	// A sanity check
	if(m_SecondaryMeasure && !m_PrimaryImageName.empty() && (m_BothImageName.empty() || m_SecondaryImageName.empty()))
	{
		CError::SetError("You need to define SecondaryImage and BothImage also!", __LINE__, __FILE__);
		throw true;
	}

	// Calculate the meter dimensions 
	if(m_PrimaryBitmap)
	{
		// Get the size form the bitmap
		BITMAP bm;
		GetObject(m_PrimaryBitmap, sizeof(BITMAP), &bm);
		m_W = bm.bmWidth;
		m_H = bm.bmHeight;
		rect.right = bm.bmWidth;
		rect.bottom = bm.bmHeight * 3;		// We'll use 3 times as large bitmap for masking primary, secondary and both bitmaps

		// Create the bitmap for the Histogram graph (we'll use this as temp bitmap for mask-blitting)
		m_HistogramBitmap = CreateCompatibleBitmap(bufferDC, m_W, m_H);

		// Create the monocrome bitmap for the mask
		m_MaskBitmap = CreateBitmap(rect.right, rect.bottom, 1, 1, NULL);

		// Fill it with black so it'll be transparent in the mask
		HBRUSH brush = CreateSolidBrush( RGB(0, 0, 0) );
		oldBM = (HBITMAP)SelectObject(tmpDC, m_MaskBitmap);
		FillRect(tmpDC, &rect, brush);
		DeleteObject(brush);

		// The pens are white and black
		m_PrimaryPen = CreatePen(PS_SOLID, 0, RGB(255, 255, 255));
		m_SecondaryPen = CreatePen(PS_SOLID, 0, RGB(255, 255, 255));
		m_BothPen = CreatePen(PS_SOLID, 0, RGB(255, 255, 255));
		m_TransparentPen = CreatePen(PS_SOLID, 0, RGB(0, 0, 0));
	} 
	else
	{
		// Create the bitmap for the Histogram graph
		m_HistogramBitmap = CreateCompatibleBitmap(bufferDC, m_W, m_H);

		// Fill it with pink so it'll be transparent
		HBRUSH brush = CreateSolidBrush( RGB(255, 0, 255) );
		oldBM = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);
		FillRect(tmpDC, &rect, brush);
		DeleteObject(brush);

		m_PrimaryPen = CreatePen(PS_SOLID, 0, m_PrimaryColor);
		m_SecondaryPen = CreatePen(PS_SOLID, 0, m_SecondaryColor);
		m_BothPen = CreatePen(PS_SOLID, 0, m_BothColor);
		m_TransparentPen = CreatePen(PS_SOLID, 0, RGB(255, 0, 255));
	}

	SelectObject(tmpDC, oldBM);
	DeleteObject(tmpDC);
}

void CMeterHistogram::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	// Read configs for Histogram meter
	if(GetPrivateProfileString(section, "PrimaryColor", "0, 255, 0", tmpSz, 255, filename) > 0) 
	{
		int R, G, B;
		sscanf(tmpSz, "%i, %i, %i", &R, &G, &B);
		m_PrimaryColor = RGB(R, G, B);
	}

	if(GetPrivateProfileString(section, "SecondaryColor", "255, 0, 0", tmpSz, 255, filename) > 0) 
	{
		int R, G, B;
		sscanf(tmpSz, "%i, %i, %i", &R, &G, &B);
		m_SecondaryColor = RGB(R, G, B);
	}

	if(GetPrivateProfileString(section, "BothColor", "255, 255, 0", tmpSz, 255, filename) > 0) 
	{
		int R, G, B;
		sscanf(tmpSz, "%i, %i, %i", &R, &G, &B);
		m_BothColor = RGB(R, G, B);
	}

	if(GetPrivateProfileString(section, "SecondaryMeasure", "", tmpSz, 255, filename) > 0) 
	{
		m_SecondaryMeasure = CreateMeasure(tmpSz);
		if(m_SecondaryMeasure) m_SecondaryMeasure->ReadConfig(filename, section);
	}

	if(GetPrivateProfileString(section, "PrimaryImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_PrimaryImageName = tmpSz;
	}

	if(GetPrivateProfileString(section, "SecondaryImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_SecondaryImageName = tmpSz;
	}

	if(GetPrivateProfileString(section, "BothImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_BothImageName = tmpSz;
	}
}

void CMeterHistogram::Update(CMeterWindow& meterWindow, int counter)
{
	CMeter::Update(meterWindow, counter);

	if(m_SecondaryMeasure)
	{
		m_SecondaryMeasure->Update(meterWindow, counter);
	}

	if(m_PrimaryBitmap == NULL)
	{
		UpdateColors(meterWindow);
	}
	else
	{
		UpdateImages(meterWindow);
	}
}

void CMeterHistogram::UpdateColors(CMeterWindow& meterWindow)
{
	int primaryValue = 0;
	int secondaryValue = 0;

	// Update the graph
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);
	HPEN oldPen = (HPEN)SelectObject(tmpDC, m_BothPen);

	// Draw a line
	int X = m_MeterPos;
	int Y = m_H;
	MoveToEx(tmpDC, X, Y, NULL);

	double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetDefaultMaxValue());
	primaryValue = m_H * value;
	primaryValue = min(m_H, primaryValue);

	if(m_SecondaryMeasure)
	{
		value = ((double)m_SecondaryMeasure->GetValue() / (double)m_SecondaryMeasure->GetDefaultMaxValue());
		secondaryValue = m_H * value;
		secondaryValue = min(m_H, secondaryValue);

		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, Y);

		if(primaryValue < secondaryValue) 
		{
			SelectObject(tmpDC, m_SecondaryPen);
			Y = m_H - secondaryValue;
		} 
		else 
		{
			SelectObject(tmpDC, m_PrimaryPen);
			Y = m_H - primaryValue;
		}
	}
	else
	{
		SelectObject(tmpDC, m_PrimaryPen);
		Y = m_H - primaryValue;
	}
	LineTo(tmpDC, X, Y);

	SelectObject(tmpDC, m_TransparentPen);
	Y = 0;
	LineTo(tmpDC, X, Y);

	m_MeterPos++;
	m_MeterPos %= m_W;

	PaintColors(meterWindow, tmpDC);

	SelectObject(tmpDC, oldBM);
	SelectObject(tmpDC, oldPen);
	DeleteObject(tmpDC);
}

void CMeterHistogram::PaintColors(CMeterWindow& meterWindow, HDC dc)
{
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_HistogramBitmap);

	// Blit the graph in two phases so that we'll get scrolling
	if(m_MeterPos > 0) 
	{
		TransparentBltLS(bufferDC,
						 m_X + m_W - m_MeterPos,
						 m_Y,
						 m_MeterPos,
						 m_H,
						 dc,
						 0,
						 0,
						 RGB(255,0,255));
	}

	if(m_MeterPos < m_W) 
	{
		TransparentBltLS(bufferDC,
						 m_X,
						 m_Y,
						 m_W - m_MeterPos,
						 m_H,
						 dc,
						 m_MeterPos,
						 0,
						 RGB(255,0,255));
	}

	SelectObject(dc, oldBM);
}

void CMeterHistogram::UpdateImages(CMeterWindow& meterWindow)
{
	int primaryValue = 0;
	int secondaryValue = 0;

	// Update the masks
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_MaskBitmap);
	HPEN oldPen = (HPEN)SelectObject(tmpDC, m_TransparentPen);

	double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetDefaultMaxValue());
	primaryValue = m_H * value;
	primaryValue = min(m_H, primaryValue);

	if(m_SecondaryMeasure)
	{
		value = ((double)m_SecondaryMeasure->GetValue() / (double)m_SecondaryMeasure->GetDefaultMaxValue());
		secondaryValue = m_H * value;
		secondaryValue = min(m_H, secondaryValue);
	}

	// Draw a primary line
	int X = m_MeterPos;
	int Y = m_H;
	MoveToEx(tmpDC, X, Y, NULL);

	if(m_SecondaryMeasure)
	{
		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, Y);

		if(primaryValue > secondaryValue) 
		{
			SelectObject(tmpDC, m_PrimaryPen);
			Y = m_H - primaryValue;
			LineTo(tmpDC, X, Y);
		}
	}
	else
	{
		SelectObject(tmpDC, m_PrimaryPen);
		Y = m_H - primaryValue;
		LineTo(tmpDC, X, Y);
	}
	SelectObject(tmpDC, m_TransparentPen);
	LineTo(tmpDC, X, 0);

	// Draw Secondary and Both lines
	if(m_SecondaryMeasure)
	{
		// Secondary
		MoveToEx(tmpDC, X, m_H * 2, NULL);
		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, m_H + Y);

		if(secondaryValue > primaryValue) 
		{
			SelectObject(tmpDC, m_SecondaryPen);
			Y = m_H - secondaryValue;
			LineTo(tmpDC, X, m_H + Y);
		}
		SelectObject(tmpDC, m_TransparentPen);
		LineTo(tmpDC, X, m_H);

		// Both
		MoveToEx(tmpDC, X, m_H * 3, NULL);
		Y = max( m_H - primaryValue, m_H - secondaryValue);
		SelectObject(tmpDC, m_BothPen);
		LineTo(tmpDC, X, m_H * 2 + Y);
		SelectObject(tmpDC, m_TransparentPen);
		LineTo(tmpDC, X, m_H * 2);
	}

	m_MeterPos++;
	m_MeterPos %= m_W;

	PaintImages(meterWindow, tmpDC);

	SelectObject(tmpDC, oldBM);
	SelectObject(tmpDC, oldPen);
	DeleteObject(tmpDC);
}

void CMeterHistogram::PaintImages(CMeterWindow& meterWindow, HDC dc)
{
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_PrimaryBitmap);

	HDC tmpDC = CreateCompatibleDC(dc);
	HBITMAP oldBM2 = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);

	MaskBlit(bufferDC, dc, tmpDC, m_MaskBitmap, 0);

	if(m_SecondaryBitmap)
	{
		SelectObject(dc, m_SecondaryBitmap);
		MaskBlit(bufferDC, dc, tmpDC, m_MaskBitmap, m_H);

		SelectObject(dc, m_BothBitmap);
		MaskBlit(bufferDC, dc, tmpDC, m_MaskBitmap, m_H * 2);
	}

	SelectObject(dc, oldBM);
	SelectObject(tmpDC, oldBM2);
	DeleteObject(tmpDC);
}

void CMeterHistogram::MaskBlit(HDC destDC, HDC scrDC, HDC tmpDC, HBITMAP maskBitmap, int yOffset)
{
	// Take a copy of the source image
	BitBlt(tmpDC, 0, 0, m_W, m_H, scrDC, 0, 0, SRCCOPY);

	// Blit the graph in two phases so that we'll get scrolling

	SelectObject(scrDC, m_MaskBitmap);
	BitBlt(scrDC, 0, yOffset, m_W, m_H, scrDC, 0, 0, DSTINVERT);	// Invert the mask

	// Mask the destination
	if(m_MeterPos > 0) 
	{
		BitBlt(destDC,
				m_X + m_W - m_MeterPos,
				m_Y,
				m_MeterPos,
				m_H,
				scrDC,
				0,
				yOffset,
				SRCAND);
	}

	if(m_MeterPos < m_W) 
	{
		BitBlt(destDC,
				m_X,
				m_Y,
				m_W - m_MeterPos,
				m_H,
				scrDC,
				m_MeterPos,
				yOffset,
				SRCAND);
	}

	BitBlt(scrDC, 0, yOffset, m_W, m_H, scrDC, 0, 0, DSTINVERT);	// Invert the mask
	
	// Mask the source
	if(m_MeterPos > 0) 
	{
		BitBlt(tmpDC,
				0 + m_W - m_MeterPos,
				0,
				m_MeterPos,
				m_H,
				scrDC,
				0,
				yOffset,
				SRCAND);
	}

	if(m_MeterPos < m_W) 
	{
		BitBlt(tmpDC,
				0,
				0,
				m_W - m_MeterPos,
				m_H,
				scrDC,
				m_MeterPos,
				yOffset,
				SRCAND);
	}

	// XOR the masked source bitmap over the masked destination
	BitBlt(destDC,
			m_X,
			m_Y,
			m_W,
			m_H,
			tmpDC,
			0,
			0,
			SRCINVERT);
}
