/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterString.h,v 1.3 2001/09/01 12:57:33 rainy Exp $

  $Log: MeterString.h,v $
  Revision 1.3  2001/09/01 12:57:33  rainy
  Added support for percentual measuring.

  Revision 1.2  2001/08/19 09:12:44  rainy
  no message

  Revision 1.1  2001/08/12 15:35:07  Rainy
  Inital Version


*/

#ifndef __METERSTRING_H__
#define __METERSTRING_H__

#include "Meter.h"
#include "MeterWindow.h"

class CMeterString : public CMeter
{
public:
	CMeterString();
	virtual ~CMeterString();

	virtual void ReadConfig(const char* filename, const char* section);
	virtual void Initialize(CMeterWindow& meterWindow);
	virtual void Update(CMeterWindow& meterWindow, int counter);

	enum TEXTALIGN
	{
		LEFT,
		RIGHT,
		CENTER
	};

	enum TEXTSTYLE
	{
		NORMAL,
		BOLD,
		ITALIC,
		BOLDITALIC
	};

private:
	void Paint(CMeterWindow& meterWindow, HDC dc);

	COLORREF m_Color;
	std::string m_Postfix;
	std::string m_Prefix;
	std::string m_FontFace;
	bool m_AutoScale;
	TEXTALIGN m_Align;
	TEXTSTYLE m_Style;
	int m_FontSize;
	double m_Scale;
	bool m_NoDecimals;
	bool m_Percentual;

	HFONT m_Font;
};

#endif

/*
E	eksa	10^18
P	peta	10^15
T	tera	10^12
G	giga	10^9
M	mega	10^6
k	kilo	10^3
*/	
