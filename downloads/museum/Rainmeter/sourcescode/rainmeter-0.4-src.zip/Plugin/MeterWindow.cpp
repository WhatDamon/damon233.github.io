/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterWindow.cpp,v 1.7 2001/09/01 12:57:13 rainy Exp $

  $Log: MeterWindow.cpp,v $
  Revision 1.7  2001/09/01 12:57:13  rainy
  Added support for Bar and Bitmap meters.

  Revision 1.6  2001/08/25 18:08:34  rainy
  Added mousebutton actions.
  The About dialog has now the build date.

  Revision 1.5  2001/08/25 17:15:52  rainy
  Added context menu, which can show the about dialog, refresh the configuration or quit the program.
  The ini-file can be defined in the step.rc also.

  Revision 1.4  2001/08/19 09:43:29  rainy
  Mouse over hid the window even if it was not wanted.

  Revision 1.3  2001/08/19 09:12:12  rainy
  Added support for GetRevID.
  Added StartHidden.

  Revision 1.2  2001/08/12 15:36:55  Rainy
  The ini-file's exsistance is checked.
  Added String meter.
  Improved mouse over hiding.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "MeterWindow.h"
#include "Rainmeter.h"
#include "Error.h"
#include <math.h>
#include <time.h>
#include "MeterHistogram.h"
#include "MeterString.h"
#include "MeterBar.h"
#include "MeterBitmap.h"
#include "resource.h"
#include <assert.h>

#define METERTIMER 1

/* 
** CMeterWindow
**
** Constructor
**
*/
CMeterWindow::CMeterWindow()
{
	m_DC = NULL;
	m_Background = NULL;
	m_DoubleBuffer = NULL;
	m_Window = NULL;
	m_Instance = NULL;

	m_WindowX = 0;
	m_WindowY = 0;
	m_WindowW = 0;
	m_WindowH = 0;
	m_WindowAlwaysOnTop = false;
	m_WindowDraggable = false;
	m_WindowUpdate = 1000;
	m_WindowHide = false;
	m_Hidden = false;
	m_WindowStartHidden = false;
	m_Rainmeter = NULL;
}

/* 
** ~CMeterWindow
**
** Destructor
**
*/
CMeterWindow::~CMeterWindow()
{
	// Destroy the meters
	std::list<CMeter*>::iterator i = m_Meters.begin();
	for( ; i != m_Meters.end(); i++)
	{
		delete (*i);
	}

	if(m_DC) DeleteObject(m_DC);
	if(m_Background) DeleteObject(m_Background);
	if(m_DoubleBuffer) DeleteObject(m_DoubleBuffer);

	if(m_Window) DestroyWindow(m_Window);

	BOOL Result;
	int counter = 0;
	do {
		// Wait for the window to die
		Result = UnregisterClass("RainmeterMeterWindow", m_Instance);
		Sleep(100);
		counter += 1;
	} while(!Result && counter < 10);
}

/* 
** Initialize
**
** Initializes the window, creates the class and the window.
**
*/
int CMeterWindow::Initialize(CRainmeter& Rainmeter, HWND Parent, HINSTANCE Instance)
{
	int flags;
	WNDCLASSEX wc;

	if(Parent==NULL || Instance==NULL) 
	{
		CError::SetError(CError::ERROR_NULL_PARAMETER, __LINE__, __FILE__);
		throw true;
	}

	m_Instance = Instance;
	m_Rainmeter = &Rainmeter;

	// Register the windowclass
	memset(&wc, 0, sizeof(WNDCLASSEX));
	wc.style = CS_NOCLOSE;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.lpfnWndProc = WndProc;
	wc.hInstance = Instance;
	wc.lpszClassName = "RainmeterMeterWindow";
	
	if(!RegisterClassEx(&wc))
	{
		CError::SetError(CError::ERROR_REGISTER_WINDOWCLASS, __LINE__, __FILE__);
		throw true;
	}

	if(Rainmeter.GetWharfData() != NULL)
	{
		flags = WS_CHILD;
	}
	else
	{
		flags = WS_POPUP;
	}

	m_Window = CreateWindowEx(WS_EX_TOOLWINDOW, 
							"RainmeterMeterWindow", 
							NULL, 
							flags,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							Parent,
							NULL,
							Instance,
							this);

	if(m_Window == NULL) 
	{ 
		CError::SetError(CError::ERROR_CREATE_WINDOW, __LINE__, __FILE__);
		throw true;
	}

	SetWindowLong(m_Window, GWL_USERDATA, magicDWord);

	Refresh(true);

	return 0;
}

void CMeterWindow::Refresh(bool init)
{
	assert(m_Rainmeter != NULL);

	if(!init)
	{
		// First destroy everything

		ShowWindow(m_Window, SW_HIDE);
		
		KillTimer(m_Window, METERTIMER);	// Kill the timer

		std::list<CMeter*>::iterator i = m_Meters.begin();
		for( ; i != m_Meters.end(); i++)
		{
			delete (*i);
		}
		m_Meters.clear();

		if(m_DC) DeleteObject(m_DC);
		m_DC = NULL;
		if(m_Background) DeleteObject(m_Background);
		m_Background = NULL;
		if(m_DoubleBuffer) DeleteObject(m_DoubleBuffer);
		m_DoubleBuffer = NULL;

		m_BackgroundName.erase();
		SetWindowRgn(m_Window, NULL, FALSE);
	}

	// Load the config and recreate everything
	ReadConfig(m_Rainmeter->GetCommandLine());
	InitializeMeters();

	if(m_Rainmeter->GetWharfData() != NULL)
	{
		// Running in a wharf. Let's add the border.
		m_WindowX += m_Rainmeter->GetWharfData()->borderSize;
		m_WindowY += m_Rainmeter->GetWharfData()->borderSize;
	}

	if(m_WindowStartHidden && init)
	{
		SetWindowPos(m_Window, HWND_TOPMOST, m_WindowX, m_WindowY, m_WindowW, m_WindowH, 0);
	}
	else
	{
		if(m_WindowAlwaysOnTop && m_Rainmeter->GetWharfData() == NULL) 
		{
			SetWindowPos(m_Window, HWND_TOPMOST, m_WindowX, m_WindowY, m_WindowW, m_WindowH, SWP_NOACTIVATE | SWP_SHOWWINDOW);
		} 
		else
		{
			SetWindowPos(m_Window, NULL, m_WindowX, m_WindowY, m_WindowW, m_WindowH, SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
		}
	}

	Update();

	// Start the timer
	if(0 == SetTimer(m_Window, METERTIMER, m_WindowUpdate, NULL)) 
	{
		CError::SetError("Unable to create a timer!", __LINE__, __FILE__);
		throw true;
	}
}

void CMeterWindow::Hide()
{
	if(m_Window) ShowWindow(m_Window, SW_HIDE);
}

void CMeterWindow::Show()
{
	if(m_Window) ShowWindow(m_Window, SW_SHOWNOACTIVATE);
}

void CMeterWindow::ReadConfig(LPCSTR cmdLine)
{
	char tmpSz[MAX_LINE_LENGTH];
	char iniFile[MAX_LINE_LENGTH];

	if(cmdLine == NULL || cmdLine[0]=='\0') 
	{
		iniFile[0] = 0;

		if(!m_Rainmeter->GetDummyLitestep()) 
		{
			GetRCString("RainmeterIniFile", iniFile, "", MAX_LINE_LENGTH - 1);
		}

		if(strlen(iniFile) == 0)
		{
			// No arguments, so we'll try to use the DLL's directory
			GetModuleFileName(GetModuleHandle("Rainmeter.dll"), iniFile, MAX_LINE_LENGTH);

			// Remove the module's name from the path
			char* pos = strrchr(iniFile, '\\');
			if(pos) 
			{
				*(pos + 1)='\0';
			} 
			else 
			{
				iniFile[0]='\0';
			}

			// Add the filename
			if(strlen(iniFile) < MAX_LINE_LENGTH - 15) 
			{ 
				strcat(iniFile, "Rainmeter.ini");
			}
		}
	} 
	else 
	{
		strncpy(iniFile, cmdLine, MAX_LINE_LENGTH);
		iniFile[MAX_LINE_LENGTH - 1] = '\0';
	}

	// Check that the file exists
	FILE* file = fopen(iniFile, "r");
	if(file == NULL)
	{
		std::string errorSz("No such ini-file: ");
		errorSz += iniFile;
		CError::SetError(errorSz, __LINE__, __FILE__);
		throw true;
	}
	else
	{
		fclose(file);
	}

	// Global settings
	if(GetPrivateProfileString( "Rainmeter", "Background", "", tmpSz, 255, iniFile) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_BackgroundName = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "RightMouseAction", "", tmpSz, 255, iniFile) > 0) 
	{
 		m_RightMouseAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "LeftMouseAction", "", tmpSz, 255, iniFile) > 0) 
	{
 		m_LeftMouseAction = tmpSz;
	}

	m_WindowX = GetPrivateProfileInt( "Rainmeter", "WindowX", 0, iniFile);
	m_WindowY = GetPrivateProfileInt( "Rainmeter", "WindowY", 0, iniFile);

	m_WindowAlwaysOnTop = 0!=GetPrivateProfileInt( "Rainmeter", "AlwaysOnTop", 0, iniFile);
	m_WindowDraggable = 0!=GetPrivateProfileInt( "Rainmeter", "Draggable", 0, iniFile);
	m_WindowUpdate = GetPrivateProfileInt( "Rainmeter", "Update", 1000, iniFile);
	m_WindowHide = 0!=GetPrivateProfileInt( "Rainmeter", "HideOnMouseOver", 0, iniFile);
	m_WindowStartHidden = 0!=GetPrivateProfileInt( "Rainmeter", "StartHidden", 0, iniFile);

	// Create the meters

	// Get all the sections (i.e. different meters)
	GetPrivateProfileString( NULL, NULL, NULL, tmpSz, MAX_LINE_LENGTH, iniFile);
	char* pos = tmpSz;
	while(strlen(pos) > 0)
	{
		if(strcmp("Rainmeter", pos) != 0)
		{
			CMeter* meter = CreateMeter(iniFile, pos);
			meter->ReadConfig(iniFile, pos);
			m_Meters.push_back(meter);
		}
		pos = pos + strlen(pos) + 1;
	}
}

CMeter* CMeterWindow::CreateMeter(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read the type of the meter and create such
	if(GetPrivateProfileString( section, "Type", "HISTOGRAM", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp("HISTOGRAM", tmpSz) == 0)
		{
			return new CMeterHistogram;
		} 
		else if(_stricmp("STRING", tmpSz) == 0)
		{
			return new CMeterString;
		} 
		else if(_stricmp("BAR", tmpSz) == 0)
		{
			return new CMeterBar;
		} 
		else if(_stricmp("BITMAP", tmpSz) == 0)
		{
			return new CMeterBitmap;
		} 
	}

	std::string errorSz("No such meter: ");
	errorSz += tmpSz;
	CError::SetError(errorSz, __LINE__, __FILE__);
	throw true;

	return NULL;
}

void CMeterWindow::InitializeMeters()
{
	// Handle negative coordinates
	RECT r;
	GetClientRect(GetDesktopWindow(), &r); 
	if(m_WindowX < 0) m_WindowX += r.right;
	if(m_WindowY < 0) m_WindowY += r.bottom;

	// Load the bitmaps
	if(!m_BackgroundName.empty())
	{
		char tmpSz[256];
		strcpy(tmpSz, m_BackgroundName.c_str());
		m_Background = LoadLSImage(tmpSz, NULL);

		if(m_Background == NULL)
		{
			std::string errorSz("Background not found: ");
			errorSz += m_BackgroundName;
			CError::SetError(errorSz, __LINE__, __FILE__);
			throw true;
		}
	}

	// Calculate the window dimensions
	if(m_Background)
	{
		// Get the size form the background bitmap
		BITMAP bm;
		GetObject(m_Background, sizeof(BITMAP), &bm);

		m_WindowW = bm.bmWidth;
		m_WindowH = bm.bmHeight;
	} 
	else
	{
		// No background -> Get the largest meter point
		std::list<CMeter*>::iterator i = m_Meters.begin();
		for( ; i != m_Meters.end(); i++)
		{
			m_WindowW = max(m_WindowW , (*i)->GetX() + (*i)->GetW());
			m_WindowH = max(m_WindowH , (*i)->GetY() + (*i)->GetH());
		}
	}

	if(m_WindowW == 0 || m_WindowH == 0)
	{
		CError::SetError("The window's dimensions are zero.", __LINE__, __FILE__);
		throw true;
	}

	// Create DC and doublebuffer
	HWND desktop = GetDesktopWindow();
	HDC DDC = GetDC(desktop);
	m_DC = CreateCompatibleDC(DDC);
	m_DoubleBuffer = CreateCompatibleBitmap(DDC, m_WindowW, m_WindowH);
	
	// If Background is not set, take a copy from the desktop
	if(m_Background == NULL) 
	{
		m_Background = CreateCompatibleBitmap(DDC, m_WindowW, m_WindowH);
		HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_Background);
		BitBlt(m_DC, 0, 0, m_WindowW, m_WindowH, DDC, m_WindowX, m_WindowY, SRCCOPY);
		SelectObject(m_DC, oldBM);
	}

	ReleaseDC(desktop, DDC);

	HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_Background);
	// Initalize all meters
	std::list<CMeter*>::iterator i = m_Meters.begin();
	for( ; i != m_Meters.end(); i++)
	{
		(*i)->Initialize(*this);
	}
	SelectObject(m_DC, oldBM);

	// Set window region if needed
	if(!m_BackgroundName.empty()) 
	{
		// m_Background must not be in any DC when calling BitmapToRegion
		HRGN region = BitmapToRegion(m_Background, RGB(255,0,255), 0x101010, 0, 0);
		SetWindowRgn(m_Window, region, FALSE);
	}
}

void CMeterWindow::Update()
{
	static int counter = 0;
	// Copy the background over the doublebuffer
	HDC tmpDC = CreateCompatibleDC(m_DC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_Background);
	HBITMAP oldBM2 = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);
	BitBlt(m_DC, 0, 0, m_WindowW, m_WindowH, tmpDC, 0, 0, SRCCOPY);
	SelectObject(tmpDC, oldBM);
	DeleteDC(tmpDC);

	// Update all meters (m_DC must hold the Doublebuffer)
	std::list<CMeter*>::iterator i = m_Meters.begin();
	for( ; i != m_Meters.end(); i++)
	{
		(*i)->Update(*this, counter);
	}
	counter++;

	SelectObject(m_DC, oldBM2);
}

LRESULT CMeterWindow::OnPaint(WPARAM wParam, LPARAM lParam) 
{
	PAINTSTRUCT ps;
	RECT rect;
	HDC winDC = BeginPaint(m_Window, &ps);

	GetClientRect(m_Window, &rect);

	// Just blit the doublebuffer to the window
	HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);
	BitBlt(winDC, 0, 0, rect.right, rect.bottom, m_DC, 0, 0, SRCCOPY);
	SelectObject(m_DC, oldBM);

	EndPaint(m_Window, &ps);
	return 0;
}

LRESULT CMeterWindow::OnTimer(WPARAM wParam, LPARAM lParam) 
{
	static int Count=1;

	if(wParam == METERTIMER) 
	{
		ShowWindowIfAppropriate();
		
		Update();

		// Just blit the doublebuffer to the window
		RECT rect;
		GetClientRect(m_Window, &rect);
		HDC winDC = GetWindowDC(m_Window);
		SelectObject(m_DC, m_DoubleBuffer);
		BitBlt(winDC, 0, 0, rect.right, rect.bottom, m_DC, 0, 0, SRCCOPY);
		ReleaseDC(m_Window, winDC);
	}

	return 0;
}

void CMeterWindow::ShowWindowIfAppropriate()
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not show the window
			return;
		}

		bool inside = false;
		POINT pos;
		RECT rect;

		GetCursorPos(&pos);
		GetWindowRect(m_Window, &rect);

		if(rect.left <= pos.x && rect.right >= pos.x &&
		   rect.top <= pos.y && rect.bottom >= pos.y) inside = true;

		if(m_Hidden && !inside)
		{
			// Show window
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
			m_Hidden = false;
		}
	}
}

LRESULT CMeterWindow::OnMouseMove(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not hide the window
			return 0;
		}

		// Hide window if it is visible
		if(IsWindowVisible(m_Window))
		{
			ShowWindow(m_Window, SW_HIDE);
			m_Hidden = true;
		}
	}

	return 0;
}

LRESULT CMeterWindow::OnCreate(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

LRESULT CMeterWindow::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	if(wParam == ID_CONTEXT_ABOUT)
	{
		ShowAboutBox();
	} 
	else if(wParam == ID_CONTEXT_REFRESH)
	{
		Refresh(false);
	} 
	else if(wParam == ID_CONTEXT_QUIT)
	{
		QuitRainmeter();
	} 

	return 0;
}

void CMeterWindow::QuitRainmeter()
{
	// This doesn't free all allocated memory, but we are quitting anyway so it doesn't matter.

	PostQuitMessage(0);
	quitModule(m_Instance);
}

void CMeterWindow::ShowAboutBox()
{
	std::string sz;
	sz = "Rainmeter version ";
	sz += VERSION;
	sz += "\n(Build on ";
	sz += __DATE__;
	sz += ")\n\nGet the latest version from:\nwww.iki.fi/rainy";
						
	MessageBox(m_Window, sz.c_str(), "Rainmeter", MB_OK);
}

LRESULT CMeterWindow::OnNcHitTest(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowDraggable)
	{
		return HTCAPTION;
	}
	return HTCLIENT;
}

LRESULT CMeterWindow::OnWindowPosChanging(WPARAM wParam, LPARAM lParam) 
{
	if(!m_WindowAlwaysOnTop)
	{
		LPWINDOWPOS wp=(LPWINDOWPOS)lParam;
		wp->flags|=SWP_NOZORDER;
	}

	return 0;
}

LRESULT CMeterWindow::OnDestroy(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

// Litestep revision control
// Not rcs-style but who cares
LRESULT CMeterWindow::OnGetRevID(WPARAM wParam, LPARAM lParam) 
{
	char* Buffer=(char*)lParam;

	if(Buffer != NULL)
	{
		if(wParam==0) 
		{
			sprintf(Buffer, "Rainmeter.dll: %s", VERSION);
		} 
		else if(wParam==1) 
		{
			sprintf(Buffer, "Rainmeter.dll: %s %s, Rainy", VERSION, __DATE__);
		} 
		else
		{
			Buffer[0] = 0;
		}

		return strlen(Buffer);
	}

	return 0;
}

LRESULT CMeterWindow::OnLeftButton(WPARAM wParam, LPARAM lParam) 
{
	if(!m_LeftMouseAction.empty())
	{
		// Run the command
		if(!m_Rainmeter->GetDummyLitestep())
		{
			// This can run bangs also
			LSExecute(NULL, m_LeftMouseAction.c_str(), SW_SHOWNORMAL);
		}
		else
		{
			// The normal way
			if(m_LeftMouseAction[0] != '!')	// Bangs not allowed
			{
				ShellExecute(NULL, "open", m_LeftMouseAction.c_str(), NULL, NULL, SW_SHOWNORMAL);
			}
		}
	}
	else
	{
		// Run the DefWindowProc so the dragging works
		if(m_WindowDraggable)
		{
			return DefWindowProc(m_Window, WM_NCLBUTTONDOWN, wParam, lParam);
		}
		else
		{
			return DefWindowProc(m_Window, WM_LBUTTONDOWN, wParam, lParam);
		}
	}

	return 0;
}

LRESULT CMeterWindow::OnRightButton(WPARAM wParam, LPARAM lParam) 
{
	if(!m_RightMouseAction.empty())
	{
		// Run the command
		if(!m_Rainmeter->GetDummyLitestep())
		{
			// This can run bangs also
			LSExecute(NULL, m_RightMouseAction.c_str(), SW_SHOWNORMAL);
		}
		else
		{
			// The normal way
			if(m_LeftMouseAction[0] != '!')	// Bangs not allowed
			{
				ShellExecute(NULL, "open", m_RightMouseAction.c_str(), NULL, NULL, SW_SHOWNORMAL);
			}
		}
	}

	return 0;
}

LRESULT CMeterWindow::OnContextMenu(WPARAM wParam, LPARAM lParam) 
{
	if(m_RightMouseAction.empty())
	{
		// Show context menu

		int xPos = LOWORD(lParam); 
		int yPos = HIWORD(lParam); 

		HMENU menu = LoadMenu(m_Instance, MAKEINTRESOURCE(IDR_CONTEXT_MENU));

		if(menu)
		{
			HMENU subMenu = GetSubMenu(menu, 0);
			if(subMenu)
			{
				if(!m_Rainmeter->GetDummyLitestep())
				{
					// Disable Quit if ran as a Litestep plugin
					EnableMenuItem(subMenu, ID_CONTEXT_QUIT, MF_BYCOMMAND | MF_GRAYED);
				}

				TrackPopupMenu(
				  subMenu,
				  TPM_RIGHTBUTTON | TPM_LEFTALIGN, 
				  xPos,
				  yPos,
				  0,
				  m_Window,
				  NULL
				);		
			}

			DestroyMenu(menu);
		}
	}

	return 0;
}

/* 
** WndProc
**
** The window procedure for the Meter
**
*/
LRESULT CALLBACK CMeterWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static CMeterWindow* Window=NULL;

	if(uMsg==WM_CREATE) {
		// Fetch this window-object from the CreateStruct
		Window=(CMeterWindow*)((LPCREATESTRUCT)lParam)->lpCreateParams;
	}

	BEGIN_MESSAGEPROC
	MESSAGE(OnPaint, WM_PAINT)
	MESSAGE(OnCreate, WM_CREATE)
	MESSAGE(OnDestroy, WM_DESTROY)
	MESSAGE(OnTimer, WM_TIMER)
	MESSAGE(OnCommand, WM_COMMAND)
	MESSAGE(OnNcHitTest, WM_NCHITTEST)
	MESSAGE(OnMouseMove, WM_MOUSEMOVE)
	MESSAGE(OnMouseMove, WM_NCMOUSEMOVE)
	MESSAGE(OnContextMenu, WM_CONTEXTMENU)
	MESSAGE(OnContextMenu, WM_NCRBUTTONUP)
	MESSAGE(OnRightButton, WM_NCRBUTTONDOWN)
	MESSAGE(OnRightButton, WM_RBUTTONDOWN)
	MESSAGE(OnLeftButton, WM_NCLBUTTONDOWN)
	MESSAGE(OnLeftButton, WM_LBUTTONDOWN)
	MESSAGE(OnWindowPosChanging, WM_WINDOWPOSCHANGING)
	MESSAGE(OnGetRevID, LM_GETREVID)
	END_MESSAGEPROC
}

/*
** IsNT
**
** returns true, if the user is running NT.
**
*/
bool CMeterWindow::IsNT()
{
	// Check if you are running a real OS

	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if(!GetVersionEx((OSVERSIONINFO*)&osvi))
	{
		// Something's wrong, lets assime Win9x
		return false;
	}

	if(osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		return true;	// You got NT
	}
	
	return false;	// Wintendo alert!
}

