/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterWindow.h,v 1.6 2001/09/01 12:57:13 rainy Exp $

  $Log: MeterWindow.h,v $
  Revision 1.6  2001/09/01 12:57:13  rainy
  Added support for Bar and Bitmap meters.

  Revision 1.5  2001/08/25 18:08:34  rainy
  Added mousebutton actions.
  The About dialog has now the build date.

  Revision 1.4  2001/08/25 17:14:00  rainy
  Pointer to CRainmeter is now stored in a member variable.
  Added few more methods.

  Revision 1.3  2001/08/19 09:10:18  rainy
  Added GetWindow() and OnGetRevID().

  Revision 1.2  2001/08/12 15:37:39  Rainy
  ToggleWindowIfNecessary is now ShowWindowIfAppropriate.
  Added method for mouseover messages.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#ifndef __METERWINDOW_H__
#define __METERWINDOW_H__

#include <windows.h>
#include <string>
#include <list>
#include "Meter.h"

class CRainmeter;

class CMeterWindow
{
public:
	CMeterWindow();
	~CMeterWindow();

	int Initialize(CRainmeter& Rainmeter, HWND Parent, HINSTANCE Instance);

	void Hide();
	void Show();
	void Refresh(bool init);
	
	HDC GetDoubleBuffer() { return m_DC; };
	HWND GetWindow() { return m_Window; };

	bool IsNT();

protected:
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	LRESULT OnPaint(WPARAM wParam, LPARAM lParam);
	LRESULT OnCreate(WPARAM wParam, LPARAM lParam);
	LRESULT OnDestroy(WPARAM wParam, LPARAM lParam);
	LRESULT OnTimer(WPARAM wParam, LPARAM lParam);
	LRESULT OnCommand(WPARAM wParam, LPARAM lParam);
	LRESULT OnNcHitTest(WPARAM wParam, LPARAM lParam);
	LRESULT OnWindowPosChanging(WPARAM wParam, LPARAM lParam);
	LRESULT OnMouseMove(WPARAM wParam, LPARAM lParam);
	LRESULT OnContextMenu(WPARAM wParam, LPARAM lParam);
	LRESULT OnGetRevID(WPARAM wParam, LPARAM lParam);
	LRESULT OnLeftButton(WPARAM wParam, LPARAM lParam);
	LRESULT OnRightButton(WPARAM wParam, LPARAM lParam);

private:
	void QuitRainmeter();
	void ShowAboutBox();

	void Update();
	void ReadConfig(LPCSTR cmdLine);
	void InitializeMeters();
	CMeter* CreateMeter(const char* filename, const char* section);
	void ShowWindowIfAppropriate();

	HDC m_DC;
	HBITMAP m_Background;
	HBITMAP m_DoubleBuffer;
	HWND m_Window;
	HINSTANCE m_Instance;

	std::string m_RightMouseAction;
	std::string m_LeftMouseAction;

	std::string m_BackgroundName;
	int m_WindowX;
	int m_WindowY;
	int m_WindowW;
	int m_WindowH;
	bool m_WindowAlwaysOnTop;
	bool m_WindowDraggable;
	int m_WindowUpdate;
	bool m_WindowHide;
	bool m_WindowStartHidden;

	bool m_Hidden;

	std::list<CMeter*> m_Meters;

	CRainmeter* m_Rainmeter;
};

#endif
