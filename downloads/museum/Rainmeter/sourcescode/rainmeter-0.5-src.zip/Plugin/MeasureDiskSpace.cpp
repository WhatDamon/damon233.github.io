/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureDiskSpace.cpp,v 1.6 2001/10/28 10:22:20 rainy Exp $

  $Log: MeasureDiskSpace.cpp,v $
  Revision 1.6  2001/10/28 10:22:20  rainy
  GetStringValue uses consts.

  Revision 1.5  2001/10/14 07:31:03  rainy
  Minor monifications to remove few warnings with VC.NET

  Revision 1.4  2001/09/26 16:27:15  rainy
  Changed the interfaces a bit.

  Revision 1.3  2001/09/01 13:00:10  rainy
  Slight changes in the interface. The value is now measured only once if possible.

  Revision 1.2  2001/08/19 09:15:08  rainy
  Added support for value invert.
  Also the CMeasure's ReadConfig is executed.

  Revision 1.1  2001/08/12 15:35:08  Rainy
  Inital Version


*/

#include "MeasureDiskSpace.h"
#include "Rainmeter.h"

CMeasureDiskSpace::CMeasureDiskSpace() : CMeasure()
{
}

CMeasureDiskSpace::~CMeasureDiskSpace()
{
}

void CMeasureDiskSpace::Update(CMeterWindow& meterWindow)
{
	ULARGE_INTEGER i64FreeBytesToCaller, i64TotalBytes, i64FreeBytes;

	CMeasure::Update(meterWindow);

	if(GetDiskFreeSpaceEx(m_Drive.c_str(), &i64FreeBytesToCaller, &i64TotalBytes, &i64FreeBytes))
	{
		// Gotta scale the value down cooz we are using 32 bit numbers.
		// Note that this doesn't work if the drive is over 2 terabytes in size.
		m_Value = (UINT)(i64FreeBytesToCaller.QuadPart / 1024);
	}
}

void CMeasureDiskSpace::ReadConfig(const char* filename, const char* section)
{
	CMeasure::ReadConfig(filename, section);

	char tmpSz[MAX_LINE_LENGTH];

	if(GetPrivateProfileString(section, "Drive", "C:\\", tmpSz, 255, filename) > 0) 
	{
 		m_Drive = tmpSz;
	}

	// Set the m_MaxValue
	ULARGE_INTEGER i64FreeBytesToCaller, i64TotalBytes, i64FreeBytes;

	if(GetDiskFreeSpaceEx(m_Drive.c_str(), &i64FreeBytesToCaller, &i64TotalBytes, &i64FreeBytes))
	{
		m_MaxValue = (UINT)(i64TotalBytes.QuadPart / 1024);
	}
}

const char* CMeasureDiskSpace::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static std::string newStr;

	const char* buffer = CMeasure::GetStringValue(autoScale, scale, decimals, percentual);
	newStr = buffer;
	int len = newStr.length();

	if(autoScale)
	{
		// The values are given as kilos so we need to change the postfix
		if(newStr[len-1] == 'G')
		{
			newStr[len-1] = 'T';
		}
		else if(newStr[len-1] == 'M')
		{
			newStr[len-1] = 'G';
		}
		else if(newStr[len-1] == 'k')
		{
			newStr[len-1] = 'M';
		}
		else
		{
			newStr += "k";
		}
	}

	return newStr.c_str();
}
