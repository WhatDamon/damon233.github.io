/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasurePerfMon.cpp,v 1.5 2001/10/28 10:21:11 rainy Exp $

  $Log: MeasurePerfMon.cpp,v $
  Revision 1.5  2001/10/28 10:21:11  rainy
  Most of the code moved to external DLL

  Revision 1.4  2001/10/14 07:31:15  rainy
  Minor monifications to remove few warnings with VC.NET

  Revision 1.3  2001/09/26 16:27:14  rainy
  Changed the interfaces a bit.

  Revision 1.2  2001/09/01 13:00:09  rainy
  Slight changes in the interface. The value is now measured only once if possible.

  Revision 1.1  2001/08/19 09:09:37  rainy
  Initial version.

*/

#include "MeasurePerfMon.h"
#include "Error.h"

CMeasurePerfMon::CMeasurePerfMon() : CMeasure()
{
	m_Difference = false;
	m_FirstTime = true;
	m_OldValue = 0;
	m_PerfMon = NULL;
	GetPerfDataFunc = NULL;
}

CMeasurePerfMon::~CMeasurePerfMon()
{
	if(m_PerfMon)
	{
		FreeLibrary(m_PerfMon);
	}
}

void CMeasurePerfMon::Update(CMeterWindow& meterWindow)
{
	CMeasure::Update(meterWindow);

	PLATFORM os = meterWindow.IsNT();

	if(GetPerfDataFunc && os != PLATFORM_9X && os != PLATFORM_NT4)		// This only works in 2K and XP
	{
		ULONGLONG value = 0;
		value = GetPerfDataFunc(m_ObjectName.c_str(), m_InstanceName.c_str(), m_CounterName.c_str());

		if(m_Difference)
		{
			// Compare with the old value
			if(!m_FirstTime) 
			{
				m_Value = (UINT)(value - m_OldValue);
			}
			m_OldValue = value;
			m_FirstTime = false;
		}
		else
		{
			m_Value = (UINT)value;
		}
	}
}

void CMeasurePerfMon::ReadConfig(const char* filename, const char* section)
{
	CMeasure::ReadConfig(filename, section);

	char buffer[256];

	if(GetPrivateProfileString( section, "PerfMonObject", "", buffer, 255, filename) > 0) 
	{
 		m_ObjectName = buffer;
	}

	if(GetPrivateProfileString( section, "PerfMonCounter", "", buffer, 255, filename) > 0) 
	{
 		m_CounterName = buffer;
	}

	if(GetPrivateProfileString( section, "PerfMonInstance", "", buffer, 255, filename) > 0) 
	{
 		m_InstanceName = buffer;
	}

	m_Difference = 0!=GetPrivateProfileInt(section, "PerfMonDifference", 1, filename);

	int value = GetPrivateProfileInt(section, "PerfMonMaxValue", 0, filename);

	if(value == 0)
	{
		m_MaxValue = 1;
		m_LogMaxValue = true;
	}
	else
	{
		m_MaxValue = value;
	}

	// Try to load the library
	m_PerfMon = LoadLibrary("PerfMon.dll");
	if(m_PerfMon == NULL)
	{
		throw CError("Unable to load PerfMon.dll", __LINE__, __FILE__);
	}

	GetPerfDataFunc = (GETPERFDATA)GetProcAddress(m_PerfMon, "GetPerfData");

	if(GetPerfDataFunc == NULL)
	{
		throw CError("PerfMon.dll doesn't export GetPerfData-function", __LINE__, __FILE__);
	}
}


