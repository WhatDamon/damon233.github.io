/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureRegistry.cpp,v 1.1 2001/10/28 09:07:18 rainy Exp $

  $Log: MeasureRegistry.cpp,v $
  Revision 1.1  2001/10/28 09:07:18  rainy
  Inital version

*/

#include "MeasureRegistry.h"
#include "Rainmeter.h"

CMeasureRegistry::CMeasureRegistry() : CMeasure()
{
	m_RegKey = NULL;
}

CMeasureRegistry::~CMeasureRegistry()
{
	if(m_RegKey) RegCloseKey(m_RegKey);
}

void CMeasureRegistry::Update(CMeterWindow& meterWindow)
{
	CMeasure::Update(meterWindow);

	if(m_RegKey != NULL)
	{
		// Get the date for stistics
		DWORD size = 4096;
		char data[4096];
		DWORD type = 0;

		if(RegQueryValueEx(m_RegKey,
						m_RegValueName.c_str(),
						NULL,
						(LPDWORD)&type,
						(LPBYTE)&data,
						(LPDWORD)&size) == ERROR_SUCCESS)
		{
			switch(type)
			{
			case REG_DWORD:
				m_Value = *((LPDWORD)&data);
				m_StringValue.erase();
				break;

			case REG_SZ:
				m_Value = 0;
				m_StringValue = data;
				break;

			default:	// Other types are not supported
				m_Value = 0;
				m_StringValue.erase();
			}
		}
	}
}

void CMeasureRegistry::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[MAX_LINE_LENGTH];

	CMeasure::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "RegKey", "", tmpSz, 255, filename) > 0) 
	{
 		m_RegKeyName = tmpSz;
	}

	if(GetPrivateProfileString(section, "RegValue", "", tmpSz, 255, filename) > 0) 
	{
 		m_RegValueName = tmpSz;
	}

	m_MaxValue = GetPrivateProfileInt(section, "MaxRegValue", 0, filename);

	if(m_MaxValue == 0)
	{
		m_MaxValue = 1;
		m_LogMaxValue = true;
	}

	// Try to open the key
    RegOpenKeyEx(HKEY_CURRENT_USER, m_RegKeyName.c_str(), 0, KEY_READ, &m_RegKey); 
}

const char* CMeasureRegistry::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
    if (m_StringValue.empty())
	{
		return CMeasure::GetStringValue(autoScale, scale, decimals, percentual);
	}

	return m_StringValue.c_str();
}

