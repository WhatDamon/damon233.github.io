/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureUptime.cpp,v 1.4 2001/12/23 10:16:10 rainy Exp $

  $Log: MeasureUptime.cpp,v $
  Revision 1.4  2001/12/23 10:16:10  rainy
  The static variable is set to zero in destructor.

  Revision 1.3  2001/10/28 10:20:49  rainy
  GetStringValue uses consts

  Revision 1.2  2001/09/26 16:27:14  rainy
  Changed the interfaces a bit.

  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.

*/

#include "MeasureUptime.h"
#include "Rainmeter.h"

UINT CMeasureUptime::c_OldTicks = 0;

CMeasureUptime::CMeasureUptime() : CMeasure()
{
}

CMeasureUptime::~CMeasureUptime()
{
	c_OldTicks = 0;
}

void CMeasureUptime::Update(CMeterWindow& meterWindow)
{
	CMeasure::Update(meterWindow);

	DWORD ticks = GetTickCount();

	// Dunno if this works, but if it does, the uptime should work bit longer than those 49,7 days
	if(ticks < c_OldTicks)
	{
		// The uptime wrapped!
		c_OldTicks = 0;		// Slight inaccuracy here
	}
	m_Value = m_Value + (ticks - c_OldTicks) / 1000;
	c_OldTicks = ticks;
}

const char* CMeasureUptime::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char buffer[MAX_LINE_LENGTH];
	
	int secs = m_Value % 60;
	int mins = (m_Value / 60) % 60;
	int hours = (m_Value / (60 * 60)) % 24;
	int days =  (m_Value / (60 * 60 * 24));

	sprintf(buffer, "%id %i:%02i", days, hours, mins);

	return buffer;
}
