/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Measure.h,v 1.6 2001/10/28 10:24:06 rainy Exp $

  $Log: Measure.h,v $
  Revision 1.6  2001/10/28 10:24:06  rainy
  GetStringValue uses consts.
  Added IfAbove/Below actions.
  Added Plugin and Registry Measures.

  Revision 1.5  2001/09/26 16:27:15  rainy
  Changed the interfaces a bit.

  Revision 1.4  2001/09/01 13:00:41  rainy
  Slight changes in the interface. The value is now measured only once if possible.
  Added support for logging the max value.

  Revision 1.3  2001/08/19 09:15:41  rainy
  Invert was moved here from the meter.

  Revision 1.2  2001/08/12 15:47:00  Rainy
  Adjusted Update()'s interface.
  Added GetStringValue() method.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#ifndef __MEASURE_H__
#define __MEASURE_H__

#include "MeterWindow.h"

class CMeter;

class CMeasure
{
public:
	CMeasure();
	virtual ~CMeasure();
	
	virtual void ReadConfig(const char* filename, const char* section);
	virtual void Update(CMeterWindow& meterWindow);

	virtual void ReadStats(HKEY hKey);
	virtual void WriteStats(HKEY hKey);
	virtual const char* GetStats();

	void SetName(const char* name) { m_Name = name; };
	const char* GetName() { return m_Name.c_str(); };

	virtual UINT GetValue();
	virtual UINT GetMaxValue() { return m_MaxValue; };
	virtual const char* GetStringValue(bool autoScale, double scale, int decimals, bool percentual);

	static CMeasure* Create(const char* measure);

protected:
	bool m_Invert;
	bool m_LogMaxValue;
	UINT m_MaxValue;
	UINT m_Value;
	std::string m_Name;

	UINT m_IfAboveValue;
	UINT m_IfBelowValue;
	std::string m_IfAboveAction;
	std::string m_IfBelowAction;
	bool m_IfAboveCommited;
	bool m_IfBelowCommited;
};

#endif
