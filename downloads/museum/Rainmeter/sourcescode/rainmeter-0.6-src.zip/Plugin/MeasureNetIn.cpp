/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureNetIn.cpp,v 1.8 2001/12/23 10:17:56 rainy Exp $

  $Log: MeasureNetIn.cpp,v $
  Revision 1.8  2001/12/23 10:17:56  rainy
  The firstTime is now a member variable.

  Revision 1.7  2001/10/28 10:21:58  rainy
  Changes in the GetStat()

  Revision 1.6  2001/10/14 07:29:39  rainy
  Minor monifications to remove few warnings with VC.NET

  Revision 1.5  2001/09/26 16:27:15  rainy
  Changed the interfaces a bit.

  Revision 1.4  2001/09/01 13:00:10  rainy
  Slight changes in the interface. The value is now measured only once if possible.

  Revision 1.3  2001/08/19 09:14:55  rainy
  Added support for value invert.
  Also the CMeasure's ReadConfig is executed.

  Revision 1.2  2001/08/12 15:44:49  Rainy
  Adjusted Update()'s interface.
  Net throughput is now measured in bytes per second and not bits.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "MeasureNetIn.h"

CMeasureNetIn::CMeasureNetIn() : CMeasureNet()
{
	m_Counter = 0;
	m_TotalIn.QuadPart = 0;
	m_FirstTime = true;
}

CMeasureNetIn::~CMeasureNetIn()
{
}

void CMeasureNetIn::Update(CMeterWindow& meterWindow)
{
	static UINT inOctets;
	int i;

	CMeasure::Update(meterWindow);

	UpdateTable(m_Counter++);

	if(c_Table == NULL) return;

	if(!m_FirstTime) 
	{
		m_Value = 0;
		for(i = 0; i < c_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)c_Table->table[i].bDescr, "MS TCP Loopback interface") != 0)
			{
				m_Value += c_Table->table[i].dwInOctets;
			}
		}
		UINT tmpValue = m_Value;
		m_Value -= inOctets;
		inOctets = tmpValue;
	}
	else
	{
		inOctets = 0;
		for(i = 0; i < c_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)c_Table->table[i].bDescr, "MS TCP Loopback interface") != 0)
			{
				inOctets += c_Table->table[i].dwInOctets;
			}
		}

		m_FirstTime = false;
	}

	m_TotalIn.QuadPart += m_Value;
}

void CMeasureNetIn::ReadConfig(const char* filename, const char* section)
{
	CMeasure::ReadConfig(filename, section);

	int value = GetPrivateProfileInt(section, "NetInSpeed", 0, filename);

	if(value == 0)
	{
		m_MaxValue = 1;
		m_LogMaxValue = true;
	}
	else
	{
		m_MaxValue = value / 8;
	}
}

void CMeasureNetIn::ReadStats(HKEY hKey)
{
	DWORD size = sizeof(ULARGE_INTEGER);

	RegQueryValueEx(hKey,
					"TotalNetIn",
                    NULL,
                    NULL,
                    (LPBYTE)&m_TotalIn,
                    (LPDWORD)&size);
}

void CMeasureNetIn::WriteStats(HKEY hKey)
{
	RegSetValueEx(hKey,
				  "TotalNetIn",
				  NULL,
				  REG_QWORD,
                  (LPBYTE)&m_TotalIn,
                  sizeof(ULARGE_INTEGER));
}

const char* CMeasureNetIn::GetStats()
{
	static std::string str;
	static std::string newStr;

	// Swap the value so that GetStringValue returns what we want
	UINT value = m_Value;
	m_Value = (UINT)(m_TotalIn.QuadPart / 1000);	// Only count kilobytes

	const char* buffer = GetStringValue(true, 1, 2, false);
	newStr = buffer;
	int len = newStr.length();

	// The values are given as kilos so we need to change the postfix
	if(newStr[len-1] == 'G')
	{
		newStr[len-1] = 'T';
	}
	else if(newStr[len-1] == 'M')
	{
		newStr[len-1] = 'G';
	}
	else if(newStr[len-1] == 'k')
	{
		newStr[len-1] = 'M';
	}
	else
	{
		newStr += "k";
	}

	str = "Total Net In:\t\t";
	str += newStr;
	str += "b\n";

	m_Value = value;

	return str.c_str();
}
