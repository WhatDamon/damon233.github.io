/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureRegistry.h,v 1.1 2001/10/28 09:07:18 rainy Exp $

  $Log: MeasureRegistry.h,v $
  Revision 1.1  2001/10/28 09:07:18  rainy
  Inital version

*/

#ifndef __MEASUREREGISTRY_H__
#define __MEASUREREGISTRY_H__

#include "Measure.h"

class CMeasureRegistry : public CMeasure
{
public:
	CMeasureRegistry();
	virtual ~CMeasureRegistry();

	virtual void Update(CMeterWindow& meterWindow);
	virtual void ReadConfig(const char* filename, const char* section);
	virtual const char* GetStringValue(bool autoScale, double scale, int decimals, bool percentual);

private:
	std::string m_RegKeyName;
	std::string m_RegValueName;
	std::string m_StringValue;
    HKEY m_RegKey;

};

#endif
