/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Meter.cpp,v 1.7 2001/12/23 10:15:25 rainy Exp $

  $Log: Meter.cpp,v $
  Revision 1.7  2001/12/23 10:15:25  rainy
  Added ParseColor().

  Revision 1.6  2001/10/14 07:32:15  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.5  2001/09/26 16:26:53  rainy
  Changed the interfaces a bit.

  Revision 1.4  2001/09/01 12:59:16  rainy
  Added support for Uptime measure.
  W and H default to 1.

  Revision 1.3  2001/08/19 09:13:38  rainy
  Invert moved to the measures.
  Added PerfMon measure.

  Revision 1.2  2001/08/12 15:41:41  Rainy
  Adjusted Update()'s interface.
  Added invert measure.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "Error.h"
#include "Meter.h"
#include "MeterBitmap.h"
#include "MeterBar.h"
#include "MeterHistogram.h"
#include "MeterString.h"
#include "Measure.h"

CMeter::CMeter()
{
	m_Measure = NULL;
	m_X = 0;
	m_Y = 0;
	m_W = 0;
	m_H = 0;
}

CMeter::~CMeter()
{
}

void CMeter::Initialize(CMeterWindow& meterWindow)
{
	// Do nuthing
}

void CMeter::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// This one reads the common configs for all meters

	m_X = GetPrivateProfileInt(section, "X", 0, filename);
	m_Y = GetPrivateProfileInt(section, "Y", 0, filename);
	m_W = GetPrivateProfileInt(section, "W", 1, filename);
	m_H = GetPrivateProfileInt(section, "H", 1, filename);

	if(GetPrivateProfileString(section, "MeasureName", "", tmpSz, 255, filename) > 0) 
	{
		m_MeasureName = tmpSz;
	}

	if(m_W == 0 || m_H == 0)
	{
        throw CError(std::string("The meter ") + section + " has zero dimensions.", __LINE__, __FILE__);
	}
}

void CMeter::BindMeasure(std::list<CMeasure*>& measures)
{
	// Go through the list and check it there is a measure for us
	std::list<CMeasure*>::iterator i = measures.begin();
	for( ; i != measures.end(); i++)
	{
		if(_stricmp((*i)->GetName(), m_MeasureName.c_str()) == 0)
		{
			m_Measure = (*i);
			return;
		}
	}

    // Error 
    throw CError(std::string("The meter [") + m_Name + "] cannot be bound with [" + m_MeasureName + "]!", __LINE__, __FILE__);
}

CMeter* CMeter::Create(const char* meter)
{
	if(_stricmp("HISTOGRAM", meter) == 0)
	{
		return new CMeterHistogram;
	} 
	else if(_stricmp("STRING", meter) == 0)
	{
		return new CMeterString;
	} 
	else if(_stricmp("BAR", meter) == 0)
	{
		return new CMeterBar;
	} 
	else if(_stricmp("BITMAP", meter) == 0)
	{
		return new CMeterBitmap;
	} 

    // Error
    throw CError(std::string("No such meter: ") + meter, __LINE__, __FILE__);

	return NULL;
}

COLORREF CMeter::ParseColor(const char* string)
{
	int R, G, B;

	if(strchr(string, ',') != NULL)
	{
		sscanf(string, "%i, %i, %i", &R, &G, &B);
	} 
	else
	{
		sscanf(string, "%02x%02x%02x", &R, &G, &B);
	}

	return RGB(R, G, B);
}
