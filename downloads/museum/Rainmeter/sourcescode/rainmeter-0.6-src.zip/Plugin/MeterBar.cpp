/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterBar.cpp,v 1.4 2001/12/23 10:14:51 rainy Exp $

  $Log: MeterBar.cpp,v $
  Revision 1.4  2001/12/23 10:14:51  rainy
  Hex color values are now also supported.

  Revision 1.3  2001/10/14 07:32:33  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.2  2001/09/26 16:26:24  rainy
  Small adjustement to the interfaces.

  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.


*/

#include "MeterBar.h"
#include "Measure.h"
#include "Error.h"
#include <lsapi\lsapi.h>

CMeterBar::CMeterBar() : CMeter()
{
	m_Color = 0;
	m_BarBitmap = NULL;
	m_Brush = NULL;
}

CMeterBar::~CMeterBar()
{
	if(m_Brush != NULL) DeleteObject(m_Brush);
	if(m_BarBitmap != NULL) DeleteObject(m_BarBitmap);
}

void CMeterBar::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	// Load the bitmaps if defined
	if(!m_ImageName.empty())
	{
		m_BarBitmap = LoadLSImage(m_ImageName.c_str(), NULL);

		if(m_BarBitmap == NULL)
		{
            throw CError(std::string("Bar image not found: ") + m_ImageName, __LINE__, __FILE__);
		}
	}

	if(m_BarBitmap)
	{
		// Get the size form the bitmap
		BITMAP bm;
		GetObject(m_BarBitmap, sizeof(BITMAP), &bm);
		m_W = bm.bmWidth;
		m_H = bm.bmHeight;
	} 
	else
	{
		m_Brush = CreateSolidBrush(m_Color);
	}
}

void CMeterBar::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	// Read configs for Bar meter
	if(GetPrivateProfileString(section, "BarColor", "0, 255, 0", tmpSz, 255, filename) > 0) 
	{
		m_Color = ParseColor(tmpSz);
	}

	if(GetPrivateProfileString(section, "BarImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_ImageName = tmpSz;
	}

	if(GetPrivateProfileString( section, "BarOrientation", "VERTICAL", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp("VERTICAL", tmpSz) == 0)
		{
			m_Orientation = VERTICAL;
		} 
		else if(_stricmp("HORIZONTAL", tmpSz) == 0)
		{
			m_Orientation = HORIZONTAL;
		}
		else
		{
            throw CError(std::string("No such BarOrientation: ") + tmpSz, __LINE__, __FILE__);
		}
	}
}

void CMeterBar::Draw(CMeterWindow& meterWindow)
{
	if(m_Measure == NULL) return;

	int newH, newW, newY, newX;

	double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetMaxValue());
	if(m_Orientation == VERTICAL)
	{
		newH = min(m_H, (int)(m_H * value));
		newW = m_W;
		newX = m_X;
		newY = m_Y + m_H - newH;
	}
	else
	{
		newW = min(m_W, (int)(m_W * value));
		newH = m_H;
		newX = m_X;
		newY = m_Y;
	}

	HDC bufferDC = meterWindow.GetDoubleBuffer();

	if(m_BarBitmap)
	{
		// Blit the image
		HDC dc = CreateCompatibleDC(bufferDC);
		HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_BarBitmap);

		TransparentBltLS(bufferDC,
						 newX,
						 newY,
						 newW,
						 newH,
						 dc,
						 0,
						 0,
						 RGB(255,0,255));

		SelectObject(dc, oldBM);
		DeleteDC(dc);
	}
	else
	{
		// Fill a solid bar
		RECT rect;
		rect.top = newY;
		rect.bottom = newY + newH;
		rect.left = newX;
		rect.right = newX + newW;
		FillRect(bufferDC, &rect, m_Brush);
	}
}

