/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterBitmap.h,v 1.2 2001/09/26 16:26:23 rainy Exp $

  $Log: MeterBitmap.h,v $
  Revision 1.2  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.


*/

#ifndef __METERBITMAP_H__
#define __METERBITMAP_H__

#include "Meter.h"
#include "MeterWindow.h"

class CMeterBitmap : public CMeter
{
public:
	CMeterBitmap();
	virtual ~CMeterBitmap();

	virtual void ReadConfig(const char* filename, const char* section);
	virtual void Initialize(CMeterWindow& meterWindow);
	virtual void Draw(CMeterWindow& meterWindow);

private:
	int m_FrameCount;
	HBITMAP m_Bitmap;
	std::string m_ImageName;
};

#endif
