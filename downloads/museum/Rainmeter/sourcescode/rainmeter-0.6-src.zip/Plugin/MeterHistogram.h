/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterHistogram.h,v 1.6 2001/09/26 16:26:23 rainy Exp $

  $Log: MeterHistogram.h,v $
  Revision 1.6  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.5  2001/09/01 12:58:48  rainy
  Removed MaxValues (i.e. they aren't stored anymore).
  Fixed a bug in bitmap histogram placement.

  Revision 1.4  2001/08/25 17:07:28  rainy
  Added support for background images behind the curves.

  Revision 1.3  2001/08/19 09:13:13  rainy
  Invert moved to the measures.

  Revision 1.2  2001/08/12 15:38:54  Rainy
  Adjusted Update()'s interface.
  Added invert for the secondary measure.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#ifndef __METERHISTOGRAM_H__
#define __METERHISTOGRAM_H__

#include "Meter.h"
#include "MeterWindow.h"

class CMeterHistogram : public CMeter
{
public:
	CMeterHistogram();
	virtual ~CMeterHistogram();

	virtual void ReadConfig(const char* filename, const char* section);
	virtual void Initialize(CMeterWindow& meterWindow);
	virtual void Draw(CMeterWindow& meterWindow);
	virtual void BindMeasure(std::list<CMeasure*>& measures);

private:
	void DrawColors(CMeterWindow& meterWindow);
	void DrawImages(CMeterWindow& meterWindow);
	void PaintColors(CMeterWindow& meterWindow, HDC dc);
	void PaintImages(CMeterWindow& meterWindow, HDC dc);
	void MaskBlit(HDC destDC, HDC scrDC, HDC tmpDC, HBITMAP maskBitmap, int yOffset);

	std::string m_SecondaryMeasureName;
	CMeasure* m_SecondaryMeasure;
	COLORREF m_PrimaryColor;
	COLORREF m_SecondaryColor;
	COLORREF m_BothColor;

	HBITMAP m_HistogramBitmap;
	int m_MeterPos;
	HPEN m_PrimaryPen;
	HPEN m_SecondaryPen;
	HPEN m_BothPen;
	HPEN m_TransparentPen;

	std::string m_PrimaryImageName;
	std::string m_SecondaryImageName;
	std::string m_BothImageName;

	HBITMAP m_MaskBitmap;
	HBITMAP m_PrimaryBitmap;
	HBITMAP m_SecondaryBitmap;
	HBITMAP m_BothBitmap;
};

#endif
