/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Rainmeter.h,v 1.8 2002/01/16 16:05:25 rainy Exp $

  $Log: Rainmeter.h,v $
  Revision 1.8  2002/01/16 16:05:25  rainy
  Version 0.6

  Revision 1.7  2001/12/23 10:11:32  rainy
  Refresh gets another parameter.

  Revision 1.6  2001/09/26 16:23:23  rainy
  Changed the version number

  Revision 1.5  2001/09/01 12:56:44  rainy
  Added refresh bang.

  Revision 1.4  2001/08/25 18:07:57  rainy
  Version is now 0.4.

  Revision 1.3  2001/08/25 17:06:24  rainy
  Changed few methods to inlines.
  Now the wharf data is stored fully.

  Revision 1.2  2001/08/19 09:03:28  rainy
  Added VERSION string.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#ifndef __RAINMETER_H__
#define __RAINMETER_H__

#include <windows.h>
#include <lsapi/lsapi.h>
#include <wharf/wharf.h>
#include "MeterWindow.h"

#define MAX_LINE_LENGTH 4096

#define BEGIN_MESSAGEPROC switch(uMsg) {
#define MESSAGE(handler, msg) case msg: return Window?Window->handler(wParam, lParam):DefWindowProc(hWnd, uMsg, wParam, lParam);
#define REJECT_MESSAGE(msg) case msg: return 0;
#define END_MESSAGEPROC } return DefWindowProc(hWnd, uMsg, wParam, lParam);

#define APPNAME "Rainmeter"
#define VERSION "0.6"

#define DLLDECL __declspec( dllexport )

class CRainmeter
{
public:
	CRainmeter();
	~CRainmeter();

	int Initialize(HWND Parent, HINSTANCE Instance, wharfDataType *wd, LPCSTR szPath);
	void Quit(HINSTANCE dllInst);
	HRGN GetRegion(int xOffset, int yOffset);

	void Hide() { m_Meter.Hide(); };
	void Show() { m_Meter.Show(); };
	void Refresh() { m_Meter.Refresh(false, NULL); };

	wharfDataType* GetWharfData() { return m_WharfData; };

	static void SetDummyLitestep(bool Dummy) { c_DummyLitestep = Dummy; };
	static bool GetDummyLitestep() { return c_DummyLitestep; };
	static void SetCommandLine(LPCSTR CmdLine) { c_CmdLine = CmdLine;};
	static LPCSTR GetCommandLine() { return c_CmdLine; };

private:
	CMeterWindow m_Meter;

	wharfDataType* m_WharfData;

	static bool c_DummyLitestep;
	static LPCSTR c_CmdLine;
};

extern "C"
{
	DLLDECL int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd);
	DLLDECL void quitWharfModule(HINSTANCE dll);
	DLLDECL HRGN getLSRegion(int xoffset, int yoffset);
	DLLDECL int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
	DLLDECL void quitModule(HINSTANCE dllInst);
	DLLDECL void Initialize(bool DummyLS, LPCSTR CmdLine);
}

#endif
