/*
  $Header: //rainbox/cvsroot/Rainmeter/MBM5Plugin/MBM5Plugin.cpp,v 1.1 2002/04/26 18:19:02 rainy Exp $

  $Log: MBM5Plugin.cpp,v $
  Revision 1.1  2002/04/26 18:19:02  rainy
  Initial version

*/

#pragma warning(disable: 4786)

#include <windows.h>
#include <math.h>
#include <string>
#include <map>
#include "vcmbm51sm.h"

/* The exported functions */
extern "C"
{
__declspec( dllexport ) UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id);
__declspec( dllexport ) void Finalize(HMODULE instance, UINT id);
__declspec( dllexport ) UINT Update(UINT id);
}

enum TYPE
{
	TEMPERATURE,
	FAN,
	VOLTAGE
};

static MBMCAF_c g_MBM;
static std::map<UINT, TYPE> g_Types;
static std::map<UINT, UINT> g_Numbers;

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	char tmpSz[4096];

	/* Read our own settings from the ini-file */
	if(GetPrivateProfileString(section, "MBM5Type", "TEMPERATURE", tmpSz, 255, iniFile) > 0) 
	{
		if (stricmp("TEMPERATURE", tmpSz) == 0)
		{
			g_Types[id] = TEMPERATURE;
		} 
		else if (stricmp("FAN", tmpSz) == 0)
		{
			g_Types[id] = FAN;
		} 
		else if (stricmp("VOLTAGE", tmpSz) == 0)
		{
			g_Types[id] = VOLTAGE;
		} 
		else
		{
			std::string error = "No such MBM5Type: ";
			error += tmpSz;
			MessageBox(NULL, tmpSz, "Rainmeter", MB_OK);
		}
	}

	// TODO: Add MHZ & CPUs & CPUload

	g_Numbers[id] = GetPrivateProfileInt(section, "MBM5Number", 0, iniFile);

	return 0;
}

/*
  This function is called when new value should be measured.
  The function returns the new value.
*/
UINT Update(UINT id)
{
	UINT value = 0; 

	std::map<UINT, TYPE>::iterator type = g_Types.find(id);
	std::map<UINT, UINT>::iterator number = g_Numbers.find(id);

	if(type == g_Types.end() || number == g_Numbers.end())
	{
		return 0;		// No id in the map. How this can be ????
	}

	switch ((*type).second)
	{
	case TEMPERATURE:
		value = g_MBM.GetTemp((*number).second);
		break;

	case FAN:
		value = g_MBM.GetFan((*number).second);
		break;

	case VOLTAGE:
		double dVal = g_MBM.GetVoltage((*number).second);
		value = UINT(dVal * 1000);
	};

	return value;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	g_Types.clear();
	g_Numbers.clear();
}
