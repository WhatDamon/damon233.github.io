#include <windows.h>
#include "PerfData.h"
#include <string>
#include <map>

ULONGLONG GetPerfData(PCTSTR ObjectName, PCTSTR InstanceName, PCTSTR CounterName);

struct PerfMeasure
{
	std::string ObjectName;
	std::string CounterName;
	std::string InstanceName;
	bool        Difference;
	ULONGLONG   OldValue;
	bool        FirstTime;
};

static CPerfTitleDatabase g_CounterTitles( PERF_TITLE_COUNTER );
static std::map<UINT, PerfMeasure*> g_Measures;

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	char buffer[256];
	PerfMeasure* measure = new PerfMeasure;
	measure->Difference = false;
	measure->FirstTime = true;
	measure->OldValue = 0;

	if(GetPrivateProfileString( section, "PerfMonObject", "", buffer, 255, iniFile) > 0) 
	{
 		measure->ObjectName = buffer;
	}

	if(GetPrivateProfileString( section, "PerfMonCounter", "", buffer, 255, iniFile) > 0) 
	{
 		measure->CounterName = buffer;
	}

	if(GetPrivateProfileString( section, "PerfMonInstance", "", buffer, 255, iniFile) > 0) 
	{
 		measure->InstanceName = buffer;
	}

	measure->Difference = 0!=GetPrivateProfileInt(section, "PerfMonDifference", 1, iniFile);

	// Store the measure
	g_Measures[id] = measure;

	return GetPrivateProfileInt(section, "PerfMonMaxValue", 0, iniFile);
}

/*
  This function is called when new value should be measured.
  The function returns the new value.
*/
UINT Update(UINT id)
{
	UINT value = 0;

	std::map<UINT, PerfMeasure*>::iterator i = g_Measures.find(id);
	if(i != g_Measures.end())
	{
		PerfMeasure* measure = (*i).second;

		if(measure)
		{
			// Check the platform
			OSVERSIONINFO osvi;
			ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
			osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
			if(GetVersionEx((OSVERSIONINFO*)&osvi) && osvi.dwPlatformId == VER_PLATFORM_WIN32_NT && osvi.dwMajorVersion > 4)
			{
				ULONGLONG longvalue = 0;
				longvalue = GetPerfData(measure->ObjectName.c_str(), 
										measure->InstanceName.c_str(), 
										measure->CounterName.c_str());

				if(measure->Difference)
				{
					// Compare with the old value
					if(!measure->FirstTime) 
					{
						value = (UINT)(longvalue - measure->OldValue);
					}
					measure->OldValue = longvalue;
					measure->FirstTime = false;
				}
				else
				{
					value = (UINT)longvalue;
				}
			}
			else
			{
				MessageBox(NULL, "PerfMon works only in Win2K/XP.", "Rainmeter PerfMon", MB_OK);
			}
		}
	}

	return value;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	// delete the measure
	std::map<UINT, PerfMeasure*>::iterator i = g_Measures.find(id);
	if(i != g_Measures.end())
	{
		delete (*i).second;
		g_Measures.erase(i);
	}
}

/*
  This method gets value of the given perfmon counter.
*/
ULONGLONG GetPerfData(PCTSTR ObjectName, PCTSTR InstanceName, PCTSTR CounterName)
{
	CPerfObject* pPerfObj;
	CPerfObjectInstance* pObjInst;
	CPerfCounter* pPerfCntr;
	BYTE data[256];
	char name[256];
	ULONGLONG value = 0;

	if(ObjectName == NULL || CounterName == NULL || strlen(ObjectName) == 0 || strlen(CounterName) == 0)
	{
		// Unable to continue
		return 0;
	}


	CPerfSnapshot snapshot(&g_CounterTitles);
	CPerfObjectList objList(&snapshot, &g_CounterTitles);

	if(snapshot.TakeSnapshot(ObjectName))
	{
		pPerfObj = objList.GetPerfObject(ObjectName);

		if(pPerfObj)
		{
			for(pObjInst = pPerfObj->GetFirstObjectInstance();
				pObjInst != NULL;
				pObjInst = pPerfObj->GetNextObjectInstance())
			{
				if (InstanceName != NULL && strlen(InstanceName) > 0)
				{
					if(pObjInst->GetObjectInstanceName(name, 256))
					{
						if(_stricmp(InstanceName, name) != 0) continue;
					}
					else
					{
						continue;
					}
				}

				pPerfCntr = pObjInst->GetCounterByName(CounterName);
				if(pPerfCntr != NULL)
				{
					pPerfCntr->GetData(data, 256, NULL);
					
					if(pPerfCntr->GetSize() == 1)
					{
						value = *(BYTE*)data;
					} 
					else if(pPerfCntr->GetSize() == 2)
					{
						value = *(WORD*)data;
					}
					else if(pPerfCntr->GetSize() == 4)
					{
						value = *(DWORD*)data;
					}
					else if(pPerfCntr->GetSize() == 8)
					{
						value = *(ULONGLONG*)data;
					}

					delete pPerfCntr;
					delete pObjInst;
					break;	// No need to continue
				}
				delete pObjInst;
			}
			delete pPerfObj;
		}
	}

	return value;
}



