/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasurePlugin.cpp,v 1.4 2002/04/26 18:24:15 rainy Exp $

  $Log: MeasurePlugin.cpp,v $
  Revision 1.4  2002/04/26 18:24:15  rainy
  Modified the Update method to support disabled measures.

  Revision 1.3  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.2  2001/12/23 10:17:02  rainy
  The plugins get unique ID automatically.
  The plugins are also loaded from the Rainmeter's folder.

  Revision 1.1  2001/10/28 09:07:19  rainy
  Inital version

*/

#include "MeasurePlugin.h"
#include "Rainmeter.h"
#include "Error.h"

/*
** CMeasureMemory
**
** The constructor
**
*/
CMeasurePlugin::CMeasurePlugin() : CMeasure()
{
	m_Plugin = NULL;
	InitializeFunc = NULL;
	UpdateFunc = NULL;
	FinalizeFunc = NULL;
	m_ID = 0;
}

/*
** ~CMeasureMemory
**
** The destructor
**
*/
CMeasurePlugin::~CMeasurePlugin()
{
	if (m_Plugin)
	{
		if(FinalizeFunc) FinalizeFunc(m_Plugin, m_ID);
		FreeLibrary(m_Plugin);
	}
}

/*
** Update
**
** Gets the current value from the plugin
**
*/
bool CMeasurePlugin::Update(CMeterWindow& meterWindow)
{
	if (!CMeasure::Update(meterWindow)) return false;

	if(UpdateFunc)
	{
		// Update the plugin
		m_Value = UpdateFunc(m_ID);
	}

	return true;
}

/*
** ReadConfig
**
** Reads the configs and loads & initializes the plugin
**
*/
void CMeasurePlugin::ReadConfig(const char* filename, const char* section)
{
	static UINT id = 1;
	char tmpSz[MAX_LINE_LENGTH];

	CMeasure::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "Plugin", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_PluginName = tmpSz;
	}

	m_Plugin = LoadLibrary(m_PluginName.c_str());
	
	if(m_Plugin == NULL)
	{
		// Try to load from Rainmeter.dll's folder
		GetModuleFileName(GetModuleHandle("Rainmeter.dll"), tmpSz, MAX_LINE_LENGTH);
		tmpSz[strlen(tmpSz) - 13] = 0;	// Remove the DLL name
		strcat(tmpSz, m_PluginName.c_str());
		m_Plugin = LoadLibrary(tmpSz);

		if(m_Plugin == NULL)
		{
			throw CError(std::string("Rainmeter plugin ") + m_PluginName + " not found!", __LINE__, __FILE__);
		}
	}

	InitializeFunc = (INITIALIZE)GetProcAddress(m_Plugin, "Initialize");
	FinalizeFunc = (FINALIZE)GetProcAddress(m_Plugin, "Finalize");
	UpdateFunc = (UPDATE)GetProcAddress(m_Plugin, "Update");

	if(UpdateFunc == NULL)
	{
		FreeLibrary(m_Plugin);
		throw CError(std::string("Rainmeter plugin ") + m_PluginName + " doesn't export Update-function!", __LINE__, __FILE__);
	}

	// Initialize the plugin
	m_ID = id++;
	if(InitializeFunc) m_MaxValue = InitializeFunc(m_Plugin, filename, section, m_ID);

	if(m_MaxValue == 0)
	{
		m_MaxValue = 1;
		m_LogMaxValue = true;
	}
}
