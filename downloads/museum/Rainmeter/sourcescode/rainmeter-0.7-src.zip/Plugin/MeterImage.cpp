/*
  Copyright (C) 2002 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterImage.cpp,v 1.1 2002/04/27 10:28:31 rainy Exp $

  $Log: MeterImage.cpp,v $
  Revision 1.1  2002/04/27 10:28:31  rainy
  Intial version.

*/

#include "MeterImage.h"
#include "Measure.h"
#include "Error.h"
#include <lsapi\lsapi.h>

/*
** CMeterImage
**
** The constructor
**
*/
CMeterImage::CMeterImage() : CMeter()
{
	m_Bitmap = NULL;
}

/*
** ~CMeterImage
**
** The destructor
**
*/
CMeterImage::~CMeterImage()
{
	if(m_Bitmap != NULL) DeleteObject(m_Bitmap);
}

/*
** Initialize
**
** Load the image and get the dimensions of the meter from it.
**
*/
void CMeterImage::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	// Load the bitmap if defined
	if(!m_ImageName.empty())
	{
		m_Bitmap = LoadLSImage(m_ImageName.c_str(), NULL);

		if(m_Bitmap == NULL)
		{
            throw CError(std::string("Bitmap image not found: ") + m_ImageName, __LINE__, __FILE__);
		}
		else
		{
			// Get the size form the Image
			BITMAP bm;
			GetObject(m_Bitmap, sizeof(BITMAP), &bm);
			m_W = bm.bmWidth;
			m_H = bm.bmHeight;
		}
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterImage::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "ImageName", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_ImageName = tmpSz;
	}
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterImage::Draw(CMeterWindow& meterWindow)
{
	if(m_Bitmap == NULL || IsHidden()) return;	// Unable to continue

	// Blit the image
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC dc = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_Bitmap);

	TransparentBltLS(bufferDC,
					 m_X,
					 m_Y,
					 m_W,
					 m_H,
					 dc,
					 0,
					 0,
					 RGB(255,0,255));

	SelectObject(dc, oldBM);
	DeleteDC(dc);
}

/*
** BindMeasure
**
** Overridden method. The Image meters need not to be bound on anything
**
*/
void CMeterImage::BindMeasure(std::list<CMeasure*>& measures)
{
	// Do nuthing
}

