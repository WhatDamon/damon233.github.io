/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterWindow.cpp,v 1.18 2002/05/05 10:48:56 rainy Exp $

  $Log: MeterWindow.cpp,v $
  Revision 1.18  2002/05/05 10:48:56  rainy
  Fixed few bugs.

  Revision 1.17  2002/05/04 08:16:35  rainy
  There can be any number of ini files in the config folders.
  WM_COPYDATA can be used to deliver the bangs.
  Added support for per meter actions.

  Revision 1.16  2002/04/27 10:27:42  rainy
  Added hide/show to meters and enable/disable to measures

  Revision 1.15  2002/04/01 15:36:10  rainy
  Added PLAY, PLAYSTOP and PLAYLOOP build-in commands.

  Revision 1.14  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.13  2002/03/29 16:32:58  rainy
  Fixed a typo

  Revision 1.12  2002/01/16 16:06:29  rainy
  The file doesn't need to be named Rainmeter.ini anymore.
  If the old config doesn't exist, we'll yse the first one instead.

  Revision 1.11  2001/12/23 10:14:09  rainy
  Added support for different configs.
  The position of the window is now remembered.

  Revision 1.10  2001/10/28 10:15:21  rainy
  Added left and right mouse up actions.
  IsNT() can now identify different OS more precisely.

  Revision 1.9  2001/10/14 07:27:58  rainy
  Changed the errorhandling.
  Stats now include the date when they were started to collect.

  Revision 1.8  2001/09/26 16:25:44  rainy
  Added support for statistics.
  Meters and Measures are now stored here.

  Revision 1.7  2001/09/01 12:57:13  rainy
  Added support for Bar and Bitmap meters.

  Revision 1.6  2001/08/25 18:08:34  rainy
  Added mousebutton actions.
  The About dialog has now the build date.

  Revision 1.5  2001/08/25 17:15:52  rainy
  Added context menu, which can show the about dialog, refresh the configuration or quit the program.
  The ini-file can be defined in the step.rc also.

  Revision 1.4  2001/08/19 09:43:29  rainy
  Mouse over hid the window even if it was not wanted.

  Revision 1.3  2001/08/19 09:12:12  rainy
  Added support for GetRevID.
  Added StartHidden.

  Revision 1.2  2001/08/12 15:36:55  Rainy
  The ini-file's exsistance is checked.
  Added String meter.
  Improved mouse over hiding.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "MeterWindow.h"
#include "Rainmeter.h"
#include "Error.h"
#include <math.h>
#include <time.h>
#include "Meter.h"
#include "Measure.h"
#include "resource.h"
#include <assert.h>

#define METERTIMER 1
#define STATSTIMER 2

/* 
** CMeterWindow
**
** Constructor
**
*/
CMeterWindow::CMeterWindow()
{
	m_DC = NULL;
	m_Background = NULL;
	m_DoubleBuffer = NULL;
	m_Window = NULL;
	m_Instance = NULL;

	m_WindowX = 0;
	m_WindowY = 0;
	m_WindowW = 0;
	m_WindowH = 0;
	m_WindowAlwaysOnTop = false;
	m_WindowDraggable = false;
	m_WindowUpdate = 1000;
	m_WindowHide = false;
	m_Hidden = false;
	m_WindowStartHidden = false;
	m_Rainmeter = NULL;
	m_GatherStats = false;
	m_ResetRegion = false;

	// Set the stats-date string
	struct tm *newtime;
    time_t long_time;
    time(&long_time);
    newtime = localtime(&long_time);
	m_StatsDate = asctime(newtime);
	m_StatsDate.resize(m_StatsDate.size() - 1);
}

/* 
** ~CMeterWindow
**
** Destructor
**
*/
CMeterWindow::~CMeterWindow()
{
	if(m_GatherStats)
	{
		WriteStats();
	}

	WriteConfig();

	// Destroy the measures
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		delete (*i);
	}

	// Destroy the meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		delete (*j);
	}

	if(m_DC) DeleteObject(m_DC);
	if(m_Background) DeleteObject(m_Background);
	if(m_DoubleBuffer) DeleteObject(m_DoubleBuffer);

	if(m_Window) DestroyWindow(m_Window);

	BOOL Result;
	int counter = 0;
	do {
		// Wait for the window to die
		Result = UnregisterClass("RainmeterMeterWindow", m_Instance);
		Sleep(100);
		counter += 1;
	} while(!Result && counter < 10);
}

/* 
** Initialize
**
** Initializes the window, creates the class and the window.
**
*/
int CMeterWindow::Initialize(CRainmeter& Rainmeter, HWND Parent, HINSTANCE Instance)
{
	int flags;
	WNDCLASSEX wc;

	if(Parent==NULL || Instance==NULL) 
	{
		throw CError(CError::ERROR_NULL_PARAMETER, __LINE__, __FILE__);
	}

	m_Instance = Instance;
	m_Rainmeter = &Rainmeter;

	// Register the windowclass
	memset(&wc, 0, sizeof(WNDCLASSEX));
	wc.style = CS_NOCLOSE;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.lpfnWndProc = WndProc;
	wc.hInstance = Instance;
	wc.lpszClassName = "RainmeterMeterWindow";
	
	if(!RegisterClassEx(&wc))
	{
		throw CError(CError::ERROR_REGISTER_WINDOWCLASS, __LINE__, __FILE__);
	}

	if(Rainmeter.GetWharfData() != NULL)
	{
		// If we're in lsBox or in wharf, this is a childwindow
		flags = WS_CHILD;
	}
	else
	{
		// ... otherwise this is normal popup window
		flags = WS_POPUP;
	}

	m_Window = CreateWindowEx(WS_EX_TOOLWINDOW, 
							"RainmeterMeterWindow", 
							NULL, 
							flags,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							Parent,
							NULL,
							Instance,
							this);

	if(m_Window == NULL) 
	{ 
		throw CError(CError::ERROR_CREATE_WINDOW, __LINE__, __FILE__);
	}

	SetWindowLong(m_Window, GWL_USERDATA, magicDWord);

	Refresh(true);

	return 0;
}

/*
** Refresh
**
** This deletes everyting and rebuilds the config again.
**
*/
void CMeterWindow::Refresh(bool init, const std::string configName, const std::string configIniFile)
{
	assert(m_Rainmeter != NULL);

	if(!init)
	{
		// First destroy everything

		if(m_GatherStats)
		{
			WriteStats();
		}

		WriteConfig();

		ShowWindow(m_Window, SW_HIDE);
		
		KillTimer(m_Window, METERTIMER);	// Kill the timer
		KillTimer(m_Window, STATSTIMER);	// Kill the timer

		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			delete (*i);
		}
		m_Measures.clear();

		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			delete (*j);
		}
		m_Meters.clear();

		if(m_DC) DeleteObject(m_DC);
		m_DC = NULL;
		if(m_Background) DeleteObject(m_Background);
		m_Background = NULL;
		if(m_DoubleBuffer) DeleteObject(m_DoubleBuffer);
		m_DoubleBuffer = NULL;

		m_BackgroundName.erase();
	}

	// Load the config and recreate everything
	GetCurrentConfig(m_Rainmeter->GetCommandLine(), configName, configIniFile);
	ReadConfig();
	InitializeMeters();

	if(m_Rainmeter->GetWharfData() != NULL)
	{
		// Running in a wharf. Let's add the border.
		m_WindowX += m_Rainmeter->GetWharfData()->borderSize;
		m_WindowY += m_Rainmeter->GetWharfData()->borderSize;
	}

	if(m_WindowStartHidden && init)
	{
		SetWindowPos(m_Window, HWND_TOPMOST, m_WindowX, m_WindowY, m_WindowW, m_WindowH, 0);
	}
	else
	{
		if(m_WindowAlwaysOnTop && m_Rainmeter->GetWharfData() == NULL) 
		{
			SetWindowPos(m_Window, HWND_TOPMOST, m_WindowX, m_WindowY, m_WindowW, m_WindowH, SWP_NOACTIVATE | SWP_SHOWWINDOW);
		} 
		else
		{
			SetWindowPos(m_Window, NULL, m_WindowX, m_WindowY, m_WindowW, m_WindowH, SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
		}
	}

	// Set the window region
	CreateRegion(true);	// Clear the region
	Update();
	CreateRegion(false);

	// Start the timers
	if(0 == SetTimer(m_Window, METERTIMER, m_WindowUpdate, NULL) ||
	   0 == SetTimer(m_Window, STATSTIMER, 60000, NULL))	// Stats are written once per minute
	{
		throw CError("Unable to create a timer!", __LINE__, __FILE__);
	}

	if(m_GatherStats)
	{
		ReadStats();
	}
}

/*
** Hide
**
** Hides the window
**
*/
void CMeterWindow::Hide()
{
	if(m_Window) ShowWindow(m_Window, SW_HIDE);
}

/*
** Show
**
** Shows the window
**
*/
void CMeterWindow::Show()
{
	if(m_Window) ShowWindow(m_Window, SW_SHOWNOACTIVATE);
}

/*
** ShowMeter
**
** Shows the given meter
**
*/
void CMeterWindow::ShowMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->Show();
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** HideMeter
**
** Hides the given meter
**
*/
void CMeterWindow::HideMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->Hide();
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** ToggleMeter
**
** Toggles the given meter
**
*/
void CMeterWindow::ToggleMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			if ((*j)->IsHidden())
			{
				(*j)->Show();
			}
			else
			{
				(*j)->Hide();
			}
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** EnableMeasure
**
** Enables the given measure
**
*/
void CMeterWindow::EnableMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			(*i)->Enable();
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** DisableMeasure
**
** Disables the given measure
**
*/
void CMeterWindow::DisableMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			(*i)->Disable();
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** ToggleMeasure
**
** Toggless the given measure
**
*/
void CMeterWindow::ToggleMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			if ((*i)->IsDisabled())
			{
				(*i)->Enable();
			}
			else
			{
				(*i)->Disable();
			}
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** ReadCurrentConfigName
**
** Gets the name of the current config from registry
**
*/
void CMeterWindow::ReadCurrentConfigName()
{
    HKEY hKey = NULL;

    if (RegOpenKeyEx(HKEY_CURRENT_USER,
					 TEXT("Software\\Rainlities\\Rainmeter"),
                     0,
                     KEY_READ,
                     &hKey) == ERROR_SUCCESS) 
	{
		DWORD size = 256;
		char str[256];

		if(RegQueryValueEx(hKey, "Config", NULL, NULL, (LPBYTE)&str, (LPDWORD)&size) == ERROR_SUCCESS)
		{
			m_ConfigName = str;
		}
		size = 256;
		if(RegQueryValueEx(hKey, "ConfigIniFile", NULL, NULL, (LPBYTE)&str, (LPDWORD)&size) == ERROR_SUCCESS)
		{
			m_ConfigIniFile = str;
		}

		RegCloseKey(hKey);
	}
}

/*
** WriteCurrentConfigName
**
** Writes the name of the current config to the registry.
** This is done so the the next time Rainmeter is started we can select
** the previously used config as active.
**
*/
void CMeterWindow::WriteCurrentConfigName()
{
    HKEY hKey = NULL;

    if (RegOpenKeyEx(HKEY_CURRENT_USER,
					 TEXT("Software\\Rainlities\\Rainmeter"),
                     0,
                     KEY_WRITE,
                     &hKey) != ERROR_SUCCESS) 
	{
		// Try to create the key
		RegCreateKeyEx(HKEY_CURRENT_USER,
					   TEXT("Software\\Rainlities\\Rainmeter"),
					   NULL,
					   NULL,
					   REG_OPTION_NON_VOLATILE,
					   KEY_WRITE,
					   NULL,
					   &hKey,
					   NULL);
	}

	if(hKey != NULL)
	{
		const char* str;
		if(m_ConfigName.empty())
		{
			str = "";
		}
		else
		{
			str = m_ConfigName.c_str();
		}
		RegSetValueEx(hKey, "Config", NULL, REG_SZ, (LPBYTE)str, strlen(str) + 1);
	
		if(m_ConfigIniFile.empty())
		{
			str = "";
		}
		else
		{
			str = m_ConfigIniFile.c_str();
		}
		RegSetValueEx(hKey, "ConfigIniFile", NULL, REG_SZ, (LPBYTE)str, strlen(str) + 1);

		RegCloseKey(hKey);
	}
}

/*
** ReadStats
**
** Reads the statistics from the registry
**
*/
void CMeterWindow::ReadStats()
{
    HKEY hKey = NULL;

    if (RegOpenKeyEx(HKEY_CURRENT_USER,
					 TEXT("Software\\Rainlities\\Rainmeter"),
                     0,
                     KEY_READ,
                     &hKey) == ERROR_SUCCESS) 
	{
		// Get the date for statistics
		DWORD size = 256;
		char timeStr[256];

		if(RegQueryValueEx(hKey,
						"Since",
						NULL,
						NULL,
						(LPBYTE)&timeStr,
						(LPDWORD)&size) == ERROR_SUCCESS)
		{
			m_StatsDate = timeStr;
		}

		// Read other stats
		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			try 
			{
				(*i)->ReadStats(hKey);
			}
			catch (CError& error)
			{
				MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
			}
		}

		RegCloseKey(hKey);
	}
}

/*
** WriteStats
**
** Writes the statistics to the registry
**
*/
void CMeterWindow::WriteStats()
{
    HKEY hKey = NULL;

    if (RegOpenKeyEx(HKEY_CURRENT_USER,
					 TEXT("Software\\Rainlities\\Rainmeter"),
                     0,
                     KEY_WRITE,
                     &hKey) != ERROR_SUCCESS) 
	{
		// Try to create the key
		RegCreateKeyEx(HKEY_CURRENT_USER,
					   TEXT("Software\\Rainlities\\Rainmeter"),
					   NULL,
					   NULL,
					   REG_OPTION_NON_VOLATILE,
					   KEY_WRITE,
					   NULL,
					   &hKey,
					   NULL);
	}

	if(hKey != NULL)
	{
		// Write the date for statistics
		const char* dateStr = m_StatsDate.c_str();

		RegSetValueEx(hKey,
					  "Since",
					  NULL,
					  REG_SZ,
					  (LPBYTE)dateStr,
					  strlen(dateStr) + 1);
	
		// Write the other stats
		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			try 
			{
				(*i)->WriteStats(hKey);
			}
			catch (CError& error)
			{
				MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
			}
		}

		RegCloseKey(hKey);
	}
}

/*
** GetCurrentConfig
**
** The config can be gives as a path, in which case all the subfolders are
** scanned for ini-files. Or the config (i.e. the ini-file) can be given explicitely.
**
*/
void CMeterWindow::GetCurrentConfig(LPCSTR cmdLine, const std::string& configName, const std::string& configIniFile)
{
	char iniFile[MAX_LINE_LENGTH];

	if(cmdLine == NULL || cmdLine[0]=='\0') 
	{
		iniFile[0] = 0;

		if(!m_Rainmeter->GetDummyLitestep()) 
		{
			GetRCString("RainmeterIniFile", iniFile, "", MAX_LINE_LENGTH - 1);
		}

		if(strlen(iniFile) == 0)
		{
			// No arguments, so we'll try to use the DLL's directory
			GetModuleFileName(GetModuleHandle("Rainmeter.dll"), iniFile, MAX_LINE_LENGTH);

			// Remove the module's name from the path
			char* pos = strrchr(iniFile, '\\');
			if(pos) 
			{
				*(pos + 1)='\0';
			} 
			else 
			{
				iniFile[0]='\0';
			}
		}
	} 
	else 
	{
		strncpy(iniFile, cmdLine, MAX_LINE_LENGTH);
		iniFile[MAX_LINE_LENGTH - 1] = '\0';
	}

	int len = strlen(iniFile);
	if(len >= 4 && _strcmpi(iniFile + len - 4, ".ini") == 0)
	{
		// The iniFile is an actual Rainmeter.ini-file
		m_CurrentConfig = iniFile;
		m_ConfigPath = "";
		m_ConfigName = "";
		m_ConfigIniFile = "";
	}
	else
	{
		// The iniFile is given as path
		m_ConfigPath = iniFile;

		// Add \ if it's missing
		if(*(m_ConfigPath.end() - 1) != '\\') m_ConfigPath += "\\";

		// Read the folder and fill the configs to the context menu
		GetConfigFolders(m_ConfigPath.c_str());

		if(m_ConfigStrings.empty())
		{
			throw CError(std::string("There are no configurations available in folder ") + iniFile, __LINE__, __FILE__);
		}

		if(!configName.empty())
		{
			if (!configIniFile.empty())
			{
				m_ConfigIniFile = configIniFile;
			}
			else
			{
				m_ConfigIniFile = "Rainmeter.ini";
			}

			m_CurrentConfig = m_ConfigPath + configName + "\\" + m_ConfigIniFile;
			// Switch to the desired config
			m_ConfigName = configName;
		}
		else
		{
			ReadCurrentConfigName();	// Read the configname from registry
			if(m_ConfigName.empty())
			{
				m_ConfigName = m_ConfigStrings[0].path;
				m_ConfigIniFile = m_ConfigStrings[0].iniFiles[0];
			} 
			else
			{
				// Check that the config exists
				std::vector<CONFIG>::iterator i = m_ConfigStrings.begin();
				for(; i != m_ConfigStrings.end(); i++)
				{
					if ((*i).path == m_ConfigName) 
					{
						std::vector<std::string>::iterator j = (*i).iniFiles.begin();
						for(; j != (*i).iniFiles.end(); j++)
						{
							if ((*j) == m_ConfigIniFile) break; 
						}

						if(j == (*i).iniFiles.end()) 
						{
							m_ConfigIniFile = m_ConfigStrings[0].iniFiles[0];	// Use the first ini file
						}

						break;	// Found match
					}
				}

				if(i == m_ConfigStrings.end()) 
				{
					m_ConfigName = m_ConfigStrings[0].path;	// No match, use the first as default
					m_ConfigIniFile = m_ConfigStrings[0].iniFiles[0];
				}
			}
			m_CurrentConfig = m_ConfigPath + m_ConfigName + "\\" + m_ConfigIniFile;
		}
	}
	WriteCurrentConfigName();		// Write the config name to registry
}

/*
** GetConfigFolders
**
** Scans all the subfolders and locates the ini-files.
**
*/
void CMeterWindow::GetConfigFolders(const std::string& folder)
{
    WIN32_FIND_DATA fileData;      // Data structure describes the file found
    WIN32_FIND_DATA fileDataIni;   // Data structure describes the file found
    HANDLE hSearch;                // Search handle returned by FindFirstFile
    HANDLE hSearchIni;             // Search handle returned by FindFirstFile

	m_ConfigStrings.clear();

    // Start searching for .ini files in the given directory.
	std::string files = folder + "*";
    hSearch = FindFirstFile(files.c_str(), &fileData);
	do
	{
		if(hSearch == INVALID_HANDLE_VALUE) break;    // No more files found

		if(fileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY && 
			strcmp(".", fileData.cFileName) != 0 &&
			strcmp("..", fileData.cFileName) != 0)
		{
			CONFIG config;
			config.path = fileData.cFileName;

			// Scan all .ini files from the subfolder
			std::string inis = folder;
			inis += fileData.cFileName;
			inis += "\\*.ini";
			hSearchIni = FindFirstFile(inis.c_str(), &fileDataIni);

			do
			{
				if(hSearchIni == INVALID_HANDLE_VALUE) break;    // No more files found
				config.iniFiles.push_back(fileDataIni.cFileName);

			} while (FindNextFile(hSearchIni, &fileDataIni));

			if (!config.iniFiles.empty())
			{
				m_ConfigStrings.push_back(config);
			}
		}
	} while(FindNextFile(hSearch, &fileData));

    FindClose(hSearch);
}

/*
** ReadConfig
**
** Reads the current config, creates the meters and measures and does the bindings.
**
*/
void CMeterWindow::ReadConfig()
{
	char tmpSz[MAX_LINE_LENGTH];

	if(m_CurrentConfig.empty())
	{
        throw CError("Failed to read the configuration file.", __LINE__, __FILE__);
	}

	// Check that the file exists
	FILE* file = fopen(m_CurrentConfig.c_str(), "r");
	if(file == NULL)
	{
		throw CError(std::string("No such ini-file: ") + m_CurrentConfig, __LINE__, __FILE__);
	}
	else
	{
		fclose(file);
	}

	// Set the current directory so that the graphics can be found
	std::string path = m_CurrentConfig;
	int pathpos = path.find_last_of('\\');
	if (pathpos != -1)
	{
		path.erase(path.begin() + pathpos, path.end());	// Remove Rainmeter.ini
		SetCurrentDirectory(path.c_str());
	}

	// Global settings
	if(GetPrivateProfileString( "Rainmeter", "Background", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_BackgroundName = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "RightMouseDownAction", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0) 
	{
 		m_RightMouseDownAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "LeftMouseDownAction", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0) 
	{
 		m_LeftMouseDownAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "RightMouseUpAction", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0) 
	{
 		m_RightMouseUpAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "LeftMouseUpAction", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0) 
	{
 		m_LeftMouseUpAction = tmpSz;
	}

	m_WindowX = GetPrivateProfileInt( "Rainmeter", "WindowX", 0, m_CurrentConfig.c_str());
	m_WindowY = GetPrivateProfileInt( "Rainmeter", "WindowY", 0, m_CurrentConfig.c_str());

	m_WindowAlwaysOnTop = 0!=GetPrivateProfileInt( "Rainmeter", "AlwaysOnTop", 0, m_CurrentConfig.c_str());
	m_WindowDraggable = 0!=GetPrivateProfileInt( "Rainmeter", "Draggable", 0, m_CurrentConfig.c_str());
	m_WindowUpdate = GetPrivateProfileInt( "Rainmeter", "Update", 1000, m_CurrentConfig.c_str());
	m_WindowHide = 0!=GetPrivateProfileInt( "Rainmeter", "HideOnMouseOver", 0, m_CurrentConfig.c_str());
	m_WindowStartHidden = 0!=GetPrivateProfileInt( "Rainmeter", "StartHidden", 0, m_CurrentConfig.c_str());
	m_GatherStats = 0!=GetPrivateProfileInt( "Rainmeter", "GatherStatistics", 0, m_CurrentConfig.c_str());
	m_SavePosition = 0!=GetPrivateProfileInt( "Rainmeter", "SavePosition", 0, m_CurrentConfig.c_str());

	// Create the meters and measures

	// Get all the sections (i.e. different meters)
	GetPrivateProfileString( NULL, NULL, NULL, tmpSz, MAX_LINE_LENGTH, m_CurrentConfig.c_str());
	char* pos = tmpSz;
	while(strlen(pos) > 0)
	{
		if(strcmp("Rainmeter", pos) != 0)
		{
			// Check if the item is a meter or a measure (or perhaps something else)
			if(GetPrivateProfileString(pos, "Measure", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0)
			{
				try
				{
					// It's a measure
					CMeasure* measure = CMeasure::Create(tmpSz);
					measure->SetName(pos);
					measure->ReadConfig(m_CurrentConfig.c_str(), pos);
					m_Measures.push_back(measure);
				}
				catch (CError& error)
				{
					MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
				}
			} 
			else if(GetPrivateProfileString(pos, "Meter", "", tmpSz, 255, m_CurrentConfig.c_str()) > 0)
			{
				try
				{
					// It's a meter
					CMeter* meter = CMeter::Create(tmpSz);
					meter->SetName(pos);
					meter->ReadConfig(m_CurrentConfig.c_str(), pos);
					m_Meters.push_back(meter);
				}
				catch (CError& error)
				{
					MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
				}
			} 
			else
			{
				// It's something else
                throw CError(std::string("Section [") + pos + "] is not a meter or a measure!", __LINE__, __FILE__);
            }
		}
		pos = pos + strlen(pos) + 1;
	}

	if (m_Meters.empty())
	{
		MessageBox(m_Window, "Your configuration file doesn't contain any meters!\nYour rainmeter.ini might be out of date.", APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}
	else
	{
		// Bind the meters to the measures
		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			try
			{
				(*j)->BindMeasure(m_Measures);
			}
			catch (CError& error)
			{
				MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
			}
		}
	}
}

/*
** WriteConfig
**
** Writes the new settings to the config
**
*/
void CMeterWindow::WriteConfig()
{
	char buffer[256];

	if(!m_CurrentConfig.empty())
	{
		// If position neews to be save, do so.
		if(m_SavePosition)
		{
			sprintf(buffer, "%i", m_WindowX < 0 ? 0 : m_WindowX);
			WritePrivateProfileString("Rainmeter", "WindowX", buffer, m_CurrentConfig.c_str());
			sprintf(buffer, "%i", m_WindowY < 0 ? 0 : m_WindowY);
			WritePrivateProfileString("Rainmeter", "WindowY", buffer, m_CurrentConfig.c_str());
		}
	}
}

/*
** InitializeMeters
**
** Initializes all the meters and the background
**
*/
void CMeterWindow::InitializeMeters()
{
	// Handle negative coordinates
	RECT r;
	GetClientRect(GetDesktopWindow(), &r); 
	if(m_WindowX < 0) m_WindowX += r.right;
	if(m_WindowY < 0) m_WindowY += r.bottom;

	// Load the background
	if(!m_BackgroundName.empty())
	{
		char tmpSz[256];
		strcpy(tmpSz, m_BackgroundName.c_str());
		m_Background = LoadLSImage(tmpSz, NULL);

		if(m_Background == NULL)
		{
            throw CError(std::string("Background not found: ") + m_BackgroundName, __LINE__, __FILE__);
		}
	}

	// Calculate the window dimensions
	if(m_Background)
	{
		// Get the size form the background bitmap
		BITMAP bm;
		GetObject(m_Background, sizeof(BITMAP), &bm);

		m_WindowW = bm.bmWidth;
		m_WindowH = bm.bmHeight;
	} 
	else
	{
		// No background -> Get the largest meter point
		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			m_WindowW = max(m_WindowW, (*j)->GetX() + (*j)->GetW());
			m_WindowH = max(m_WindowH, (*j)->GetY() + (*j)->GetH());
		}
	}

	if(m_WindowW == 0 || m_WindowH == 0)
	{
		throw CError("The window's dimensions are zero.", __LINE__, __FILE__);
	}

	// Create DC and doublebuffer
	HWND desktop = GetDesktopWindow();
	HDC DDC = GetDC(desktop);
	m_DC = CreateCompatibleDC(DDC);
	m_DoubleBuffer = CreateCompatibleBitmap(DDC, m_WindowW, m_WindowH);
	
	// If Background is not set, take a copy from the desktop
	if(m_Background == NULL) 
	{
		m_Background = CreateCompatibleBitmap(DDC, m_WindowW, m_WindowH);
		HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_Background);
		BitBlt(m_DC, 0, 0, m_WindowW, m_WindowH, DDC, m_WindowX, m_WindowY, SRCCOPY);
		SelectObject(m_DC, oldBM);
	}

	ReleaseDC(desktop, DDC);

	HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_Background);

	// Initalize all meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Initialize(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	SelectObject(m_DC, oldBM);
}

/*
** CreateRegion
**
** Creates/Clears a window region
**
*/
void CMeterWindow::CreateRegion(bool clear)
{
	if (clear)
	{
		SetWindowRgn(m_Window, NULL, TRUE);
	}
	else
	{
		// Set window region if needed
		if(!m_BackgroundName.empty()) 
		{
			// For some reason the BitmapToRegion doens't work with m_DoubleBuffer
			// if called another time. That's why we have to make a copy of the bitmap.

			HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);

			HDC dc = CreateCompatibleDC(m_DC);
			HBITMAP bitmap = CreateCompatibleBitmap(m_DC, m_WindowW, m_WindowH);
			HBITMAP oldBM2 = (HBITMAP)SelectObject(dc, bitmap);
			BitBlt(dc, 0, 0, m_WindowW, m_WindowH, m_DC, 0, 0, SRCCOPY);
			SelectObject(dc, oldBM2);
			SelectObject(m_DC, oldBM);

			HRGN region = BitmapToRegion(bitmap, RGB(255,0,255), 0x101010, 0, 0);
			SetWindowRgn(m_Window, region, TRUE);

			DeleteObject(bitmap);
			DeleteObject(dc);
		}
	}
}

/*
** Update
**
** Updates all the measures and redraws the meters
**
*/
void CMeterWindow::Update()
{
	// Copy the background over the doublebuffer
	HBITMAP oldBM2 = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);

	HDC tmpDC = CreateCompatibleDC(m_DC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_Background);
	BitBlt(m_DC, 0, 0, m_WindowW, m_WindowH, tmpDC, 0, 0, SRCCOPY);
	SelectObject(tmpDC, oldBM);
	DeleteDC(tmpDC);

	// Update all measures
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		try
		{
			(*i)->Update(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	// Draw the meters (m_DC must hold the Doublebuffer)
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Draw(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	SelectObject(m_DC, oldBM2);
}

/*
** OnPaint
**
** Repaints the window. This does not cause update of the measures.
**
*/
LRESULT CMeterWindow::OnPaint(WPARAM wParam, LPARAM lParam) 
{
	PAINTSTRUCT ps;
	RECT rect;
	HDC winDC = BeginPaint(m_Window, &ps);

	GetClientRect(m_Window, &rect);

	// Just blit the doublebuffer to the window
	HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);
	BitBlt(winDC, 0, 0, rect.right, rect.bottom, m_DC, 0, 0, SRCCOPY);
	SelectObject(m_DC, oldBM);

	EndPaint(m_Window, &ps);
	return 0;
}

/*
** OnTimer
**
** Handles the timers. The METERTIMER updates all the measures and
** STATSTIMER writes the stats to registry.
**
*/
LRESULT CMeterWindow::OnTimer(WPARAM wParam, LPARAM lParam) 
{
	static int Count=1;

	if(wParam == METERTIMER) 
	{
		ShowWindowIfAppropriate();
		
		if (m_ResetRegion) CreateRegion(true);
		Update();
		if (m_ResetRegion) CreateRegion(false);
		m_ResetRegion = false;

		// Just blit the doublebuffer to the window
		RECT rect;
		GetClientRect(m_Window, &rect);
		HDC winDC = GetWindowDC(m_Window);
		SelectObject(m_DC, m_DoubleBuffer);
		BitBlt(winDC, 0, 0, rect.right, rect.bottom, m_DC, 0, 0, SRCCOPY);
		ReleaseDC(m_Window, winDC);
	}
	else if(wParam == STATSTIMER)
	{
		WriteStats();
	}

	return 0;
}

/*
** ShowWindowIfAppropriate
**
** Show the window if it is temporarely hidden.
**
*/
void CMeterWindow::ShowWindowIfAppropriate()
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not show the window
			return;
		}

		bool inside = false;
		POINT pos;
		RECT rect;

		GetCursorPos(&pos);
		GetWindowRect(m_Window, &rect);

		if(rect.left <= pos.x && rect.right >= pos.x &&
		   rect.top <= pos.y && rect.bottom >= pos.y) inside = true;

		if(m_Hidden && !inside)
		{
			// Show window
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
			m_Hidden = false;
		}
	}
}

/*
** OnMouseMove
**
** When we get WM_MOUSEMOVE messages, hide the window as the mouse is over it.
**
*/
LRESULT CMeterWindow::OnMouseMove(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not hide the window
			return 0;
		}

		// Hide window if it is visible
		if(IsWindowVisible(m_Window))
		{
			ShowWindow(m_Window, SW_HIDE);
			m_Hidden = true;
		}
	}

	return 0;
}

/*
** OnCreate
**
** During window creation we do nothing.
**
*/
LRESULT CMeterWindow::OnCreate(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/*
** OnCommand
**
** Handle the menu commands.
**
*/
LRESULT CMeterWindow::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	try 
	{
		if(wParam == ID_CONTEXT_ABOUT)
		{
			ShowAboutBox();
		} 
		else if(wParam == ID_CONTEXT_REFRESH)
		{
			Refresh(false);
		} 
		else if(wParam == ID_CONTEXT_QUIT)
		{
			QuitRainmeter();
		}
		else if(wParam >= ID_CONFIG_FIRST)
		{
			// Check which config was selected
			int index = 0;
			
			for (int i = 0; i < m_ConfigStrings.size(); i++)
			{
				for (int j = 0; j < m_ConfigStrings[i].iniFiles.size(); j++)
				{
					if (index == wParam - ID_CONFIG_FIRST)
					{
						Refresh(false, m_ConfigStrings[i].path, m_ConfigStrings[i].iniFiles[j]);
						return 0;
					}
					index++;
				}
			}
		}
	} 
    catch(CError& error) 
    {
		MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return 0;
}

/*
** QuitRainmeter
**
** Quits Rainmeter and kills the window.
**
*/
void CMeterWindow::QuitRainmeter()
{
	// This doesn't free all allocated memory, but we are quitting anyway so it doesn't matter.

	PostQuitMessage(0);
	quitModule(m_Instance);
}

/*
** ShowAboutBox
**
** Opens the About dialog.
**
*/
void CMeterWindow::ShowAboutBox()
{
	std::string sz;
	sz = "Rainmeter version ";
	sz += VERSION;
	sz += "\n(Build on ";
	sz += __DATE__;
	sz += ")\n\nGet the latest version from:\nwww.iki.fi/rainy\n\n";
						
	if(m_GatherStats)
	{
		sz += "Statistics (since ";
		sz += m_StatsDate;
		sz += "):\n";

		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			sz += (*i)->GetStats();
		}
	}

	MessageBox(m_Window, sz.c_str(), "Rainmeter", MB_OK);
}

/*
** OnNcHitTest
**
** This is overwritten so that the window can be dragged
**
*/
LRESULT CMeterWindow::OnNcHitTest(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowDraggable)
	{
		return HTCAPTION;
	}
	return HTCLIENT;
}

/*
** OnWindowPosChanging
**
** Called when windows position is about to change
**
*/
LRESULT CMeterWindow::OnWindowPosChanging(WPARAM wParam, LPARAM lParam) 
{
	if(!m_WindowAlwaysOnTop)
	{
		// do not change the z-order. This keeps the window on bottom.
		LPWINDOWPOS wp=(LPWINDOWPOS)lParam;
		wp->flags|=SWP_NOZORDER;
	}

	return 0;
}

/*
** OnDestroy
**
** During destruction of the window do nothing.
**
*/
LRESULT CMeterWindow::OnDestroy(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/*
** OnGetRevID
**
** Litestep revision control. This string is shown in the Litestep's about box.
** Not rcs-style but who cares
**
*/
LRESULT CMeterWindow::OnGetRevID(WPARAM wParam, LPARAM lParam) 
{
	char* Buffer=(char*)lParam;

	if(Buffer != NULL)
	{
		if(wParam==0) 
		{
			sprintf(Buffer, "Rainmeter.dll: %s", VERSION);
		} 
		else if(wParam==1) 
		{
			sprintf(Buffer, "Rainmeter.dll: %s %s, Rainy", VERSION, __DATE__);
		} 
		else
		{
			Buffer[0] = 0;
		}

		return strlen(Buffer);
	}

	return 0;
}

/*
** ExecuteCommand
**
** Runs the given command or bang
**
*/
void CMeterWindow::ExecuteCommand(const char* command) 
{
	if (command == NULL) return;

	// Check for build-ins
	if (strncmp("PLAY ", command, 5) == 0)
	{
		PlaySound(command + 5, NULL, SND_ASYNC | SND_FILENAME | SND_NODEFAULT);
		return;
	}
	else if (strncmp("PLAYSTOP", command, 8) == 0)
	{
		PlaySound(NULL, NULL, SND_PURGE);
		return;
	}
	else if (strncmp("PLAYLOOP ", command, 9) == 0)
	{
		PlaySound(command + 9, NULL, SND_ASYNC | SND_FILENAME | SND_LOOP | SND_NODEFAULT);
		return;
	}
	
	// Run the command
	if(!m_Rainmeter->GetDummyLitestep())
	{
		// This can run bangs also
		LSExecute(NULL, command, SW_SHOWNORMAL);
	}
	else
	{
		// The normal way
		if(command[0] != '!')	// Bangs not allowed
		{
			ShellExecute(NULL, "open", command, NULL, NULL, SW_SHOWNORMAL);
		}
		else
		{
			// Mimic WM_COPY to deliver bangs

			COPYDATASTRUCT CopyDataStruct;
			CopyDataStruct.cbData = strlen(command) + 1;
			CopyDataStruct.dwData = 1;
			CopyDataStruct.lpData = (void*)command;
			OnCopyData(NULL, (LPARAM)&CopyDataStruct);
		}
	}
}

/*
** OnLeftButtonDown
**
** Runs the action when left mouse button is down
**
*/
LRESULT CMeterWindow::OnLeftButtonDown(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCLBUTTONDOWN)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	if(!DoAction(x, y, MOUSE_LMB_DOWN, false))
	{
		// Run the DefWindowProc so the dragging works
		return DefWindowProc(m_Window, m_Message, wParam, lParam);
	}

	return 0;
}

/*
** OnLeftButtonUp
**
** Runs the action when left mouse button is up
**
*/
LRESULT CMeterWindow::OnLeftButtonUp(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCLBUTTONUP)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	DoAction(x, y, MOUSE_LMB_UP, false);

	return 0;
}

/*
** OnRightButtonDown
**
** Runs the action when right mouse button is down
**
*/
LRESULT CMeterWindow::OnRightButtonDown(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCRBUTTONDOWN)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	DoAction(x, y, MOUSE_RMB_DOWN, false);

	return 0;
}

/*
** OnRightButtonUp
**
** Runs the action when right mouse button is up
**
*/
LRESULT CMeterWindow::OnRightButtonUp(WPARAM wParam, LPARAM lParam) 
{
	if (!DoAction(LOWORD(lParam), HIWORD(lParam), MOUSE_RMB_UP, false))
	{
		// Run the DefWindowProc so the contextmenu works
		return DefWindowProc(m_Window, WM_RBUTTONUP, wParam, lParam);
	}

	return 0;
}

/*
** OnContextMenu
**
** Handles the context menu. The menu is recreated every time it is shown.
**
*/
LRESULT CMeterWindow::OnContextMenu(WPARAM wParam, LPARAM lParam) 
{
	int xPos = LOWORD(lParam); 
	int yPos = HIWORD(lParam); 

	// Transform the point to client rect
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 
	RECT rect;
	GetWindowRect(m_Window, &rect);
	x = x - rect.left;
	y = y - rect.top;

	// If RMB up or RMB down cause actions, do not show the menu!
	if (DoAction(x, y, MOUSE_RMB_UP, false) || DoAction(x, y, MOUSE_RMB_DOWN, true))
	{
		return 0;
	}

	// Show context menu, if no actions were executed
	HMENU menu = LoadMenu(m_Instance, MAKEINTRESOURCE(IDR_CONTEXT_MENU));

	if(menu)
	{
		HMENU subMenu = GetSubMenu(menu, 0);
		if(subMenu)
		{
			if(!m_Rainmeter->GetDummyLitestep())
			{
				// Disable Quit if ran as a Litestep plugin
				EnableMenuItem(subMenu, ID_CONTEXT_QUIT, MF_BYCOMMAND | MF_GRAYED);
			}
			if(m_ConfigStrings.size() > 0)
			{
				int index = 0;

				// Fill the menu with all the configs
				HMENU configMenu = CreatePopupMenu();
				if(configMenu)
				{
					InsertMenu(subMenu, 1, MF_BYPOSITION | MF_POPUP, (UINT_PTR)configMenu, "Configs");

					for(int i = 0; i < m_ConfigStrings.size(); i++)
					{
						if (m_ConfigStrings[i].iniFiles.size() > 1)
						{
							HMENU iniMenu = CreatePopupMenu();
							InsertMenu(configMenu, i, MF_BYPOSITION | MF_POPUP, (UINT_PTR)iniMenu, m_ConfigStrings[i].path.c_str());
							for(int j = 0; j < m_ConfigStrings[i].iniFiles.size(); j++)
							{
								std::string iniName = m_ConfigStrings[i].iniFiles[j].c_str();
								iniName.erase(iniName.end() - 4, iniName.end());
								InsertMenu(iniMenu, j, MF_BYPOSITION, ID_CONFIG_FIRST + index++, iniName.c_str());

								if(m_ConfigStrings[i].path == m_ConfigName && m_ConfigStrings[i].iniFiles[j] == m_ConfigIniFile)
								{
									CheckMenuItem(iniMenu, j, MF_BYPOSITION | MF_CHECKED);
								}
							}
						}
						else
						{
							InsertMenu(configMenu, i, MF_BYPOSITION, ID_CONFIG_FIRST + index++, m_ConfigStrings[i].path.c_str());

							if(m_ConfigStrings[i].path == m_ConfigName)
							{
								CheckMenuItem(configMenu, i, MF_BYPOSITION | MF_CHECKED);
							}
						}
					}
				}
			}

			TrackPopupMenu(
			  subMenu,
			  TPM_RIGHTBUTTON | TPM_LEFTALIGN, 
			  xPos,
			  yPos,
			  0,
			  m_Window,
			  NULL
			);		
		}

		DestroyMenu(menu);
	}

	return 0;
}

/*
** DoAction
**
** Executes the action if such are defined. Returns true, if action was executed.
** If the test is true, the action is not executed.
**
*/
bool CMeterWindow::DoAction(int x, int y, MOUSE mouse, bool test) 
{
	// Check if the hitpoint was over some meter
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		// Hidden meters are ignored
		if ((*j)->IsHidden()) continue;

		if (x >= (*j)->GetX() && x <= (*j)->GetX() + (*j)->GetW() &&
			y >= (*j)->GetY() && y <= (*j)->GetY() + (*j)->GetH())
		{
			switch (mouse)
			{
			case MOUSE_LMB_DOWN:
				if (!((*j)->GetLeftMouseDownAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetLeftMouseDownAction().c_str());
					return true;
				}
				break;

			case MOUSE_LMB_UP:
				if (!((*j)->GetLeftMouseUpAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetLeftMouseUpAction().c_str());
					return true;
				}
				break;

			case MOUSE_RMB_DOWN:
				if (!((*j)->GetRightMouseDownAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetRightMouseDownAction().c_str());
					return true;
				}
				break;

			case MOUSE_RMB_UP:
				if (!((*j)->GetRightMouseUpAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetRightMouseUpAction().c_str());
					return true;
				}
				break;
			}
		}
	}

	// If no meters caused actions, do the default actions
	switch (mouse)
	{
	case MOUSE_LMB_DOWN:
		if (!m_LeftMouseDownAction.empty())
		{
			if (!test) ExecuteCommand(m_LeftMouseDownAction.c_str());
			return true;
		}
		break;

	case MOUSE_LMB_UP:
		if (!m_LeftMouseUpAction.empty())
		{
			if (!test) ExecuteCommand(m_LeftMouseUpAction.c_str());
			return true;
		}
		break;

	case MOUSE_RMB_DOWN:
		if (!m_RightMouseDownAction.empty())
		{
			if (!test) ExecuteCommand(m_RightMouseDownAction.c_str());
			return true;
		}
		break;

	case MOUSE_RMB_UP:
		if (!m_RightMouseUpAction.empty())
		{
			if (!test) ExecuteCommand(m_RightMouseUpAction.c_str());
			return true;
		}
		break;
	}

	return false;
}


/*
** OnMove
**
** Stores the new place of the window so that it can be written in the config file.
**
*/
LRESULT CMeterWindow::OnMove(WPARAM wParam, LPARAM lParam) 
{
	// Store the new window position
	m_WindowX = LOWORD(lParam);
	m_WindowY = HIWORD(lParam);

	return 0;
}

/* 
** WndProc
**
** The window procedure for the Meter
**
*/
LRESULT CALLBACK CMeterWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static CMeterWindow* Window = NULL;

	if (Window) Window->m_Message = uMsg;

	if(uMsg == WM_CREATE) 
	{
		// Fetch this window-object from the CreateStruct
		Window=(CMeterWindow*)((LPCREATESTRUCT)lParam)->lpCreateParams;
	}

	BEGIN_MESSAGEPROC
	MESSAGE(OnPaint, WM_PAINT)
	MESSAGE(OnMove, WM_MOVE)
	MESSAGE(OnCreate, WM_CREATE)
	MESSAGE(OnDestroy, WM_DESTROY)
	MESSAGE(OnTimer, WM_TIMER)
	MESSAGE(OnCommand, WM_COMMAND)
	MESSAGE(OnNcHitTest, WM_NCHITTEST)
	MESSAGE(OnMouseMove, WM_MOUSEMOVE)
	MESSAGE(OnMouseMove, WM_NCMOUSEMOVE)
	MESSAGE(OnContextMenu, WM_CONTEXTMENU)
	MESSAGE(OnRightButtonDown, WM_NCRBUTTONDOWN)
	MESSAGE(OnRightButtonDown, WM_RBUTTONDOWN)
	MESSAGE(OnRightButtonUp, WM_RBUTTONUP)
	MESSAGE(OnContextMenu, WM_NCRBUTTONUP)
	MESSAGE(OnLeftButtonDown, WM_NCLBUTTONDOWN)
	MESSAGE(OnLeftButtonDown, WM_LBUTTONDOWN)
	MESSAGE(OnLeftButtonUp, WM_LBUTTONUP)
	MESSAGE(OnLeftButtonUp, WM_NCLBUTTONUP)
	MESSAGE(OnWindowPosChanging, WM_WINDOWPOSCHANGING)
	MESSAGE(OnGetRevID, LM_GETREVID)
	MESSAGE(OnCopyData, WM_COPYDATA)
	END_MESSAGEPROC
}

/*
** IsNT
**
** Checks which OS you are running
**
*/
PLATFORM CMeterWindow::IsNT()
{
	// Check if you are running a real OS

	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if(!GetVersionEx((OSVERSIONINFO*)&osvi))
	{
		// Something's wrong, lets assime Win9x
		return PLATFORM_9X;
	}

	if(osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// You got NT
		if(osvi.dwMajorVersion <= 4) return PLATFORM_NT4;
		if(osvi.dwMajorVersion == 5) return PLATFORM_2K;
		return PLATFORM_XP;
	}
	
	return PLATFORM_9X;	// Wintendo alert!
}

/*
** OnCopyData
**
** Handles bangs from the exe
**
*/
LRESULT CMeterWindow::OnCopyData(WPARAM wParam, LPARAM lParam)
{
	COPYDATASTRUCT* pCopyDataStruct = (COPYDATASTRUCT*) lParam;

	if (pCopyDataStruct && (pCopyDataStruct->dwData == 1) && (pCopyDataStruct->cbData > 0))
	{
		if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterRefresh", 17) == 0)
		{
			// This one takes arguments
			if (strlen((const char*)pCopyDataStruct->lpData) > 18)
			{
				RainmeterRefresh(m_Window, (const char*)pCopyDataStruct->lpData + 18);
			}
			else
			{
				RainmeterRefresh(m_Window, NULL);
			}
		}
		else if (stricmp((const char*)pCopyDataStruct->lpData, "!RainmeterHide") == 0)
		{
			RainmeterHide(m_Window, NULL);
		}
		else if (stricmp((const char*)pCopyDataStruct->lpData, "!RainmeterShow") == 0)
		{
			RainmeterShow(m_Window, NULL);
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterHideMeter", 19) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 20)
			{
				RainmeterHideMeter(m_Window, (const char*)pCopyDataStruct->lpData + 20);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterShowMeter", 19) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 20)
			{
				RainmeterShowMeter(m_Window, (const char*)pCopyDataStruct->lpData + 20);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterToggleMeter", 21) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 22)
			{
				RainmeterToggleMeter(m_Window, (const char*)pCopyDataStruct->lpData + 22);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterDisableMeasure", 24) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 25)
			{
				RainmeterDisableMeasure(m_Window, (const char*)pCopyDataStruct->lpData + 25);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterEnableMeasure", 23) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 24)
			{
				RainmeterEnableMeasure(m_Window, (const char*)pCopyDataStruct->lpData + 24);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterToggleMeasure", 23) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 24)
			{
				RainmeterToggleMeasure(m_Window, (const char*)pCopyDataStruct->lpData + 24);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterChangeConfig", 22) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 23)
			{
				RainmeterChangeConfig(m_Window, (const char*)pCopyDataStruct->lpData + 23);
			}
		}
		else
		{
			std::string error = "Unknown !bang: ";
			error += (const char*)pCopyDataStruct->lpData;
			MessageBox(m_Window, error.c_str(), "Rainmeter", MB_OK);
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
	
	return TRUE;
}
