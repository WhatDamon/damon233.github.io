/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureNet.cpp,v 1.6 2002/07/01 15:34:23 rainy Exp $

  $Log: MeasureNet.cpp,v $
  Revision 1.6  2002/07/01 15:34:23  rainy
  Now it is possible to select the NIC.

  Revision 1.5  2002/04/26 18:24:16  rainy
  Modified the Update method to support disabled measures.

  Revision 1.4  2002/04/01 15:38:25  rainy
  Some on the implementation from NetIn/Out is moved here.
  Added TrafficAction and TrafficValue.

  Revision 1.3  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.2  2001/08/12 15:45:34  Rainy
  Changed UpdateTable() to be a class method.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "MeasureNet.h"
#include "Rainmeter.h"

MIB_IFTABLE* CMeasureNet::c_Table = NULL;
int CMeasureNet::c_NumOfTables = 0;

/*
** CMeasureNet
**
** The constructor. This is the base class for the net-meters. 
**
*/
CMeasureNet::CMeasureNet() : CMeasure()
{
	m_Total.QuadPart = 0;
	m_TrafficValue = 0;
	m_CurrentTraffic = 0;
	m_Interface = 0;
}

/*
** ~CMeasureNet
**
** The destructor
**
*/
CMeasureNet::~CMeasureNet()
{
	delete [] c_Table;
	c_Table = NULL;
}

/*
** Update
**
** Checks if Action should be executed.
**
*/
bool CMeasureNet::Update(CMeterWindow& meterWindow)
{
	if (!CMeasure::Update(meterWindow)) return false;

	if (!m_TrafficAction.empty())
	{
		if (m_CurrentTraffic > m_TrafficValue)
		{
			m_CurrentTraffic = 0;
			meterWindow.ExecuteCommand(m_TrafficAction.c_str());
		}

		m_CurrentTraffic += m_Value;
	}

	return true;
}

/*
** UpdateTable
**
** Reads the tables for all net interfaces
**
*/
void CMeasureNet::UpdateTable(int counter)
{
	static int lastCounter = -1;

	if(counter == lastCounter)
	{
		// The table is already up-to-date
		return;
	}

	lastCounter = counter;

	if(c_Table == NULL)
	{
		// Gotta reserve few bytes for the tables
		DWORD value;
		if(GetNumberOfInterfaces(&value) == NO_ERROR)
		{
			c_NumOfTables = value;

			if(c_NumOfTables > 0)
			{
				DWORD size = sizeof(MIB_IFTABLE) + sizeof(MIB_IFROW) * c_NumOfTables;
				c_Table = (MIB_IFTABLE*)new char[size];
			}
		}
	}

	if(c_Table)
	{
		DWORD size = sizeof(MIB_IFTABLE) + sizeof(MIB_IFROW) * c_NumOfTables;
		if(GetIfTable(c_Table, &size, false) != NO_ERROR)
		{
			delete [] c_Table;
			c_Table = (MIB_IFTABLE*)new char[size];
			if(GetIfTable(c_Table, &size, false) != NO_ERROR)
			{
				// Something's wrong. Unable to get the table.
				delete [] c_Table;
				c_Table = NULL;
			}
		}
	}
}

/*
** GetNetOctets
**
** Reads the amount of octets. This is the same for in, out and total.
** the net-parameter informs which inherited class called this method.
**
*/
UINT CMeasureNet::GetNetOctets(NET net)
{
	UINT value = 0;

	if (m_Interface == 0)
	{
		// Get all interfaces
		for(int i = 0; i < c_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)c_Table->table[i].bDescr, "MS TCP Loopback interface") != 0)
			{
				switch (net)
				{
				case NET_IN:
					value += c_Table->table[i].dwInOctets;
					break;

				case NET_OUT:
					value += c_Table->table[i].dwOutOctets;
					break;

				case NET_TOTAL:
					value += c_Table->table[i].dwInOctets;
					value += c_Table->table[i].dwOutOctets;
					break;
				}
			}
		}
	}
	else
	{
		// Get the selected interface
		if (c_NumOfTables <= m_Interface)
		{
			switch (net)
			{
			case NET_IN:
				value += c_Table->table[m_Interface - 1].dwInOctets;
				break;

			case NET_OUT:
				value += c_Table->table[m_Interface - 1].dwOutOctets;
				break;

			case NET_TOTAL:
				value += c_Table->table[m_Interface - 1].dwInOctets;
				value += c_Table->table[m_Interface - 1].dwOutOctets;
				break;
			}
		}
	}

	return value;
}

/*
** ReadConfig
**
** Reads the measure specific configs. This is the same for in, out and total.
** the net-parameter informs which inherited class called this method.
**
*/
void CMeasureNet::ReadConfig(const char* filename, const char* section, NET net)
{
	char tmpSz[MAX_LINE_LENGTH];
	int value;
	const char* netName = NULL;
	
	if (net == NET_IN)
	{
		netName = "NetInSpeed";
	}
	else if (net == NET_OUT)
	{
		netName = "NetOutSpeed";
	}
	else
	{
		netName = "NetTotalSpeed";
	}

	value = GetPrivateProfileInt(section, netName, 0, filename);

	m_Interface = GetPrivateProfileInt(section, "Interface", 0, filename);

	m_TrafficValue = GetPrivateProfileInt(section, "TrafficValue", 0, filename);
	if(GetPrivateProfileString( section, "TrafficAction", "", tmpSz, 255, filename) > 0) 
	{
 		m_TrafficAction = tmpSz;
	}

	if(value == 0)
	{
		m_MaxValue = 1;
		m_LogMaxValue = true;
	}
	else
	{
		m_MaxValue = value / 8;
	}
}

/*
** ReadStats
**
** Reads statistics from the registry.
**
*/
void CMeasureNet::ReadStats(HKEY hKey, NET net)
{
	const char* netName = NULL;
	
	if (net == NET_IN)
	{
		netName = "TotalNetIn";
	}
	else if (net == NET_OUT)
	{
		netName = "TotalNetOut";
	}
	else
	{
		netName = "TotalNetTotal";
	}

	DWORD size = sizeof(ULARGE_INTEGER);

	RegQueryValueEx(hKey,
					netName,
                    NULL,
                    NULL,
                    (LPBYTE)&m_Total,
                    (LPDWORD)&size);
}

/*
** WriteStats
**
** Writes statistics to the registry.
**
*/
void CMeasureNet::WriteStats(HKEY hKey, NET net)
{
	const char* netName = NULL;
	
	if (net == NET_IN)
	{
		netName = "TotalNetIn";
	}
	else if (net == NET_OUT)
	{
		netName = "TotalNetOut";
	}
	else
	{
		netName = "TotalNetTotal";
	}

	RegSetValueEx(hKey,
				  netName,
				  NULL,
				  REG_QWORD,
				  (LPBYTE)&m_Total,
				  sizeof(ULARGE_INTEGER));
}

/*
** GetStats
**
** Returns the statistics as a string so that they can be shown in the about dialog.
**
*/
const char* CMeasureNet::GetStats(NET net)
{
	static std::string str;
	static std::string newStr;
	const char* netName = NULL;
	
	if (net == NET_IN)
	{
		netName = "Net In: ";
	}
	else if (net == NET_OUT)
	{
		netName = "Net Out: ";
	}
	else
	{
		netName = "Net Total: ";
	}

	// Swap the value so that GetStringValue returns what we want
	UINT value = m_Value;
	m_Value = (UINT)(m_Total.QuadPart / 1000);	// Only count kilobytes

	const char* buffer = GetStringValue(true, 1, 2, false);
	newStr = buffer;
	int len = newStr.length();

	// The values are given as kilos so we need to change the postfix
	if(newStr[len-1] == 'G')
	{
		newStr[len-1] = 'T';
	}
	else if(newStr[len-1] == 'M')
	{
		newStr[len-1] = 'G';
	}
	else if(newStr[len-1] == 'k')
	{
		newStr[len-1] = 'M';
	}
	else
	{
		newStr += "k";
	}

	str = netName;
	str += newStr;
	str += "b\n";

	m_Value = value;

	return str.c_str();
}

