/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureNetTotal.cpp,v 1.3 2002/07/01 15:34:38 rainy Exp $

  $Log: MeasureNetTotal.cpp,v $
  Revision 1.3  2002/07/01 15:34:38  rainy
  The measuring is done in the base class.

  Revision 1.2  2002/04/26 18:24:15  rainy
  Modified the Update method to support disabled measures.

  Revision 1.1  2002/04/01 15:35:27  rainy
  Initial version.


*/

#include "MeasureNetTotal.h"

/*
** CMeasureNetTotal
**
** The constructor
**
*/
CMeasureNetTotal::CMeasureNetTotal() : CMeasureNet()
{
	m_Counter = 0;
	m_FirstTime = true;
}

/*
** ~CMeasureNetTotal
**
** The destructor
**
*/
CMeasureNetTotal::~CMeasureNetTotal()
{
}

/*
** Update
**
** Updates the current net total value. 
**
*/
bool CMeasureNetTotal::Update(CMeterWindow& meterWindow)
{
	static UINT totalOctets;

	if (!CMeasureNet::Update(meterWindow)) return false;

	UpdateTable(m_Counter++);

	if(c_Table == NULL) return false;

	if(!m_FirstTime) 
	{
		m_Value = GetNetOctets(NET_TOTAL);
		UINT tmpValue = m_Value;
		m_Value -= totalOctets;
		totalOctets = tmpValue;
	}
	else
	{
		totalOctets = GetNetOctets(NET_TOTAL);
		m_FirstTime = false;
	}

	m_Total.QuadPart += m_Value;

	return true;
}

/*
** ReadConfig
**
** Reads the measure specific configs.
**
*/
void CMeasureNetTotal::ReadConfig(const char* filename, const char* section)
{
	CMeasure::ReadConfig(filename, section);
	CMeasureNet::ReadConfig(filename, section, NET_TOTAL);
}

/*
** ReadStats
**
** Reads statistics from the registry.
**
*/
void CMeasureNetTotal::ReadStats(HKEY hKey)
{
	CMeasureNet::ReadStats(hKey, NET_TOTAL);
}

/*
** WriteStats
**
** Writes statistics to the registry.
**
*/
void CMeasureNetTotal::WriteStats(HKEY hKey)
{
	CMeasureNet::WriteStats(hKey, NET_TOTAL);
}

/*
** GetStats
**
** Returns the statistics as a string so that they can be shown in the about dialog.
**
*/
const char* CMeasureNetTotal::GetStats()
{
	return CMeasureNet::GetStats(NET_TOTAL);
}
