/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterBitmap.cpp,v 1.8 2002/07/01 15:32:51 rainy Exp $

  $Log: MeterBitmap.cpp,v $
  Revision 1.8  2002/07/01 15:32:51  rainy
  Removed include to lsapi.h

  Revision 1.7  2002/04/26 18:22:02  rainy
  Added possibility to hide the meter.

  Revision 1.6  2002/03/31 20:32:29  rainy
  Added ZeroFrame, which uses the first frame only for value 0.

  Revision 1.5  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.4  2001/12/23 10:15:04  rainy
  Added one sanity check.

  Revision 1.3  2001/10/14 07:32:33  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.2  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.1  2001/09/01 12:56:25  rainy
  Initial version.


*/

#include "MeterBitmap.h"
#include "Measure.h"
#include "Error.h"

/*
** CMeterBitmap
**
** The constructor
**
*/
CMeterBitmap::CMeterBitmap() : CMeter()
{
	m_Bitmap = NULL;
	m_FrameCount = 0;
	m_ZeroFrame = false;
}

/*
** ~CMeterBitmap
**
** The destructor
**
*/
CMeterBitmap::~CMeterBitmap()
{
	if(m_Bitmap != NULL) DeleteObject(m_Bitmap);
}

/*
** Initialize
**
** Load the image and get the dimensions of the meter from it.
**
*/
void CMeterBitmap::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	// Load the bitmaps if defined
	if(!m_ImageName.empty())
	{
		m_Bitmap = LoadLSImage(m_ImageName.c_str(), NULL);

		if(m_Bitmap == NULL)
		{
            throw CError(std::string("Bitmap image not found: ") + m_ImageName, __LINE__, __FILE__);
		}
		else
		{
			// Get the size form the bitmap
			BITMAP bm;
			GetObject(m_Bitmap, sizeof(BITMAP), &bm);
			m_W = bm.bmWidth;
			m_H = bm.bmHeight;
		}
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterBitmap::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "BitmapImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_ImageName = tmpSz;
	}

	m_FrameCount = GetPrivateProfileInt( section, "BitmapFrames", 0, filename);

	m_ZeroFrame = (1 == GetPrivateProfileInt( section, "BitmapZeroFrame", 0, filename));
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterBitmap::Draw(CMeterWindow& meterWindow)
{
	if(m_Measure == NULL || IsHidden()) return;

	int newH, newW, newY, newX;

	if(m_FrameCount == 0 || m_Bitmap == NULL) return;	// Unable to continue

	int frame = 0;

	if (m_ZeroFrame)
	{
		// Use the first frame only if the value is zero
		if (m_Measure->GetValue() > 0)
		{
			double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetMaxValue());
			frame = (int)(value * (m_FrameCount - 1));
			frame = min(frame, (m_FrameCount - 2)) + 1;
		}
	}
	else
	{
		// Select the correct frame linearly
		double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetMaxValue());
		frame = (int)(value * m_FrameCount);
		frame = min(frame, (m_FrameCount - 1));
	}

	if(m_H > m_W)
	{
		newH = m_H / m_FrameCount;
		newW = m_W;
		newX = 0;
		newY = frame * newH;
	}
	else
	{
		newW = m_W / m_FrameCount;
		newH = m_H;
		newX = frame * newW;
		newY = 0;
	}


	// Blit the image
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC dc = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_Bitmap);

	TransparentBltLS(bufferDC,
					 m_X,
					 m_Y,
					 newW,
					 newH,
					 dc,
					 newX,
					 newY,
					 RGB(255,0,255));

	SelectObject(dc, oldBM);
	DeleteDC(dc);
}

