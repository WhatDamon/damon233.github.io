/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterHistogram.cpp,v 1.14 2002/07/01 15:32:51 rainy Exp $

  $Log: MeterHistogram.cpp,v $
  Revision 1.14  2002/07/01 15:32:51  rainy
  Removed include to lsapi.h

  Revision 1.13  2002/05/04 08:14:11  rainy
  Histogram now draws the lines one pixel higher.

  Revision 1.12  2002/04/26 18:28:17  rainy
  The meter is not updated if both measures are disabled.

  Revision 1.11  2002/04/26 18:22:02  rainy
  Added possibility to hide the meter.

  Revision 1.10  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.9  2001/12/23 10:14:51  rainy
  Hex color values are now also supported.

  Revision 1.8  2001/10/28 10:19:40  rainy
  Fixed a bug with secondary measure not set correctly

  Revision 1.7  2001/10/14 07:32:33  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.6  2001/09/26 16:26:37  rainy
  Small adjustement to the interfaces.
  Implemented BindMeasure()

  Revision 1.5  2001/09/01 12:58:48  rainy
  Removed MaxValues (i.e. they aren't stored anymore).
  Fixed a bug in bitmap histogram placement.

  Revision 1.4  2001/08/25 17:07:28  rainy
  Added support for background images behind the curves.

  Revision 1.3  2001/08/19 09:13:13  rainy
  Invert moved to the measures.

  Revision 1.2  2001/08/12 15:38:54  Rainy
  Adjusted Update()'s interface.
  Added invert for the secondary measure.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "MeterHistogram.h"
#include "Measure.h"
#include "Error.h"

/*
** CMeterHistogram
**
** The constructor
**
*/
CMeterHistogram::CMeterHistogram() : CMeter()
{
	m_SecondaryMeasure = NULL;
	m_PrimaryColor = 0;
	m_SecondaryColor = 0;
	m_BothColor = 0;
	m_HistogramBitmap = NULL;
	m_MeterPos = 0;
	m_PrimaryPen = NULL;
	m_SecondaryPen = NULL;
	m_BothPen = NULL;
	m_TransparentPen = NULL;
	m_PrimaryBitmap = NULL;
	m_SecondaryBitmap = NULL;
	m_BothBitmap = NULL;
	m_MaskBitmap = NULL;
}

/*
** ~CMeterHistogram
**
** The destructor
**
*/
CMeterHistogram::~CMeterHistogram()
{
	DeleteObject(m_HistogramBitmap);
	DeleteObject(m_PrimaryPen);
	DeleteObject(m_SecondaryPen);
	DeleteObject(m_BothPen);
	DeleteObject(m_TransparentPen);

	if(m_PrimaryBitmap != NULL) DeleteObject(m_PrimaryBitmap);
	if(m_SecondaryBitmap != NULL) DeleteObject(m_SecondaryBitmap);
	if(m_BothBitmap != NULL) DeleteObject(m_BothBitmap);
	if(m_MaskBitmap != NULL) DeleteObject(m_MaskBitmap);
}

/*
** Initialize
**
** Load the images and calculate the dimensions of the meter from them.
** Or create the brushes if solid color histogram is used.
**
*/
void CMeterHistogram::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	HBITMAP oldBM = NULL;
	RECT rect;
	rect.left = 0;
	rect.right = m_W;
	rect.top = 0;
	rect.bottom = m_H;

	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);

	// Load the bitmaps if defined
	if(!m_PrimaryImageName.empty())
	{
		m_PrimaryBitmap = LoadLSImage(m_PrimaryImageName.c_str(), NULL);

		if(m_PrimaryBitmap == NULL)
		{
            throw CError(std::string("PrimaryImage not found: ") + m_PrimaryImageName, __LINE__, __FILE__);
		}
	}

	if(!m_SecondaryImageName.empty())
	{
		m_SecondaryBitmap = LoadLSImage(m_SecondaryImageName.c_str(), NULL);

		if(m_SecondaryBitmap == NULL)
		{
            throw CError(std::string("SecondaryImage not found: ") + m_SecondaryImageName, __LINE__, __FILE__);
		}
	}

	if(!m_BothImageName.empty())
	{
		m_BothBitmap = LoadLSImage(m_BothImageName.c_str(), NULL);

		if(m_BothBitmap == NULL)
		{
            throw CError(std::string("BothImage not found: ") + m_BothImageName, __LINE__, __FILE__);
		}
	}

	// A sanity check
	if(m_SecondaryMeasure && !m_PrimaryImageName.empty() && (m_BothImageName.empty() || m_SecondaryImageName.empty()))
	{
        throw CError(std::string("You need to define SecondaryImage and BothImage also!"), __LINE__, __FILE__);
	}

	// Calculate the meter dimensions 
	if(m_PrimaryBitmap)
	{
		// Get the size form the bitmap
		BITMAP bm;
		GetObject(m_PrimaryBitmap, sizeof(BITMAP), &bm);
		m_W = bm.bmWidth;
		m_H = bm.bmHeight;
		rect.right = bm.bmWidth;
		rect.bottom = bm.bmHeight * 3;		// We'll use 3 times as large bitmap for masking primary, secondary and both bitmaps

		// Create the bitmap for the Histogram graph (we'll use this as temp bitmap for mask-blitting)
		m_HistogramBitmap = CreateCompatibleBitmap(bufferDC, m_W, m_H);

		// Create the bitmap for the mask
		m_MaskBitmap = CreateCompatibleBitmap(bufferDC, rect.right, rect.bottom);

		// Fill it with black so it'll be transparent in the mask
		HBRUSH brush = CreateSolidBrush( RGB(0, 0, 0) );
		oldBM = (HBITMAP)SelectObject(tmpDC, m_MaskBitmap);
		FillRect(tmpDC, &rect, brush);
		DeleteObject(brush);

		// The pens are white and black
		m_PrimaryPen = CreatePen(PS_SOLID, 0, RGB(255, 255, 255));
		m_SecondaryPen = CreatePen(PS_SOLID, 0, RGB(255, 255, 255));
		m_BothPen = CreatePen(PS_SOLID, 0, RGB(255, 255, 255));
		m_TransparentPen = CreatePen(PS_SOLID, 0, RGB(0, 0, 0));
	} 
	else
	{
		// Create the bitmap for the Histogram graph
		m_HistogramBitmap = CreateCompatibleBitmap(bufferDC, m_W, m_H);

		// Fill it with pink so it'll be transparent
		HBRUSH brush = CreateSolidBrush( RGB(255, 0, 255) );
		oldBM = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);
		FillRect(tmpDC, &rect, brush);
		DeleteObject(brush);

		m_PrimaryPen = CreatePen(PS_SOLID, 0, m_PrimaryColor);
		m_SecondaryPen = CreatePen(PS_SOLID, 0, m_SecondaryColor);
		m_BothPen = CreatePen(PS_SOLID, 0, m_BothColor);
		m_TransparentPen = CreatePen(PS_SOLID, 0, RGB(255, 0, 255));
	}

	SelectObject(tmpDC, oldBM);
	DeleteObject(tmpDC);
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterHistogram::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	// Read configs for Histogram meter
	if(GetPrivateProfileString(section, "PrimaryColor", "0, 255, 0", tmpSz, 255, filename) > 0) 
	{
		m_PrimaryColor = ParseColor(tmpSz);
	}

	if(GetPrivateProfileString(section, "SecondaryColor", "255, 0, 0", tmpSz, 255, filename) > 0) 
	{
		m_SecondaryColor = ParseColor(tmpSz);
	}

	if(GetPrivateProfileString(section, "BothColor", "255, 255, 0", tmpSz, 255, filename) > 0) 
	{
		m_BothColor = ParseColor(tmpSz);
	}

	if(GetPrivateProfileString(section, "SecondaryMeasureName", "", tmpSz, 255, filename) > 0) 
	{
		m_SecondaryMeasureName = tmpSz;
	}

	if(GetPrivateProfileString(section, "PrimaryImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_PrimaryImageName = tmpSz;
	}

	if(GetPrivateProfileString(section, "SecondaryImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_SecondaryImageName = tmpSz;
	}

	if(GetPrivateProfileString(section, "BothImage", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_BothImageName = tmpSz;
	}
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterHistogram::Draw(CMeterWindow& meterWindow)
{
	if (m_Measure == NULL) return;

	if (IsHidden()) 
	{
		if (m_SecondaryMeasure == NULL && m_Measure->IsDisabled()) return;
		if (m_SecondaryMeasure != NULL && m_SecondaryMeasure->IsDisabled() && m_Measure->IsDisabled()) return;
	}

	if(m_PrimaryBitmap == NULL)
	{
		DrawColors(meterWindow);
	}
	else
	{
		DrawImages(meterWindow);
	}
}

/*
** DrawColors
**
** Draws the meter as solid colors. This method draws the histogram to a 
** temporary bitmap from where the image is then blitted to the double buffer.
** Only the current value is drawn on the bitmap.
**
*/
void CMeterHistogram::DrawColors(CMeterWindow& meterWindow)
{
	int primaryValue = 0;
	int secondaryValue = 0;

	// Update the graph
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);
	HPEN oldPen = (HPEN)SelectObject(tmpDC, m_BothPen);

	// Draw a line
	int X = m_MeterPos;
	int Y = m_H - 1;
	MoveToEx(tmpDC, X, Y, NULL);

	double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetMaxValue());
	primaryValue = (int)(m_H * value);
	primaryValue = min(m_H, primaryValue);

	if(m_SecondaryMeasure)
	{
		value = ((double)m_SecondaryMeasure->GetValue() / (double)m_SecondaryMeasure->GetMaxValue());
		secondaryValue = (int)(m_H * value);
		secondaryValue = min(m_H, secondaryValue);

		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, Y - 1);

		if(primaryValue < secondaryValue) 
		{
			SelectObject(tmpDC, m_SecondaryPen);
			Y = m_H - secondaryValue;
		} 
		else 
		{
			SelectObject(tmpDC, m_PrimaryPen);
			Y = m_H - primaryValue;
		}
	}
	else
	{
		SelectObject(tmpDC, m_PrimaryPen);
		Y = m_H - primaryValue;
	}
	LineTo(tmpDC, X, Y - 1);	// The last pixel is not included

	// Draw the rest as transparent
	if (Y > 0)
	{
		SelectObject(tmpDC, m_TransparentPen);
		LineTo(tmpDC, X, -1);
	}

	m_MeterPos++;
	m_MeterPos %= m_W;

	PaintColors(meterWindow, tmpDC);

	SelectObject(tmpDC, oldBM);
	SelectObject(tmpDC, oldPen);
	DeleteObject(tmpDC);
}

/*
** PaintColors
**
** This method does the actual painting. The blitting is done in two parts.
** This way we dont need to shift the bitmap each time new value is drawn.
**
*/
void CMeterHistogram::PaintColors(CMeterWindow& meterWindow, HDC dc)
{
	if(IsHidden()) return;

	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_HistogramBitmap);

	// Blit the graph in two phases so that we'll get scrolling
	if(m_MeterPos > 0) 
	{
		TransparentBltLS(bufferDC,
						 m_X + m_W - m_MeterPos,
						 m_Y,
						 m_MeterPos,
						 m_H,
						 dc,
						 0,
						 0,
						 RGB(255,0,255));
	}

	if(m_MeterPos < m_W) 
	{
		TransparentBltLS(bufferDC,
						 m_X,
						 m_Y,
						 m_W - m_MeterPos,
						 m_H,
						 dc,
						 m_MeterPos,
						 0,
						 RGB(255,0,255));
	}

	SelectObject(dc, oldBM);
}

/*
** DrawImages
**
** Draws the meter as bitmaps. This is very similar as the DrawColors, except 
** that we need to create a masks for bitmap blitting.
**
*/
void CMeterHistogram::DrawImages(CMeterWindow& meterWindow)
{
	int primaryValue = 0;
	int secondaryValue = 0;

	// Update the masks
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_MaskBitmap);
	HPEN oldPen = (HPEN)SelectObject(tmpDC, m_TransparentPen);

	double value = ((double)m_Measure->GetValue() / (double)m_Measure->GetMaxValue());
	primaryValue = (int)(m_H * value);
	primaryValue = min(m_H, primaryValue);

	if(m_SecondaryMeasure)
	{
		value = ((double)m_SecondaryMeasure->GetValue() / (double)m_SecondaryMeasure->GetMaxValue());
		secondaryValue = (int)(m_H * value);
		secondaryValue = min(m_H, secondaryValue);
	}

	// Draw a primary line
	int X = m_MeterPos;
	int Y = m_H - 1;
	MoveToEx(tmpDC, X, Y, NULL);

	if(m_SecondaryMeasure)
	{
		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, Y - 1);

		if(primaryValue > secondaryValue) 
		{
			SelectObject(tmpDC, m_PrimaryPen);
			Y = m_H - primaryValue;
			LineTo(tmpDC, X, Y - 1);
		}
	}
	else
	{
		SelectObject(tmpDC, m_PrimaryPen);
		Y = m_H - primaryValue;
		LineTo(tmpDC, X, Y - 1);
	}
	SelectObject(tmpDC, m_TransparentPen);
	LineTo(tmpDC, X, -1);

	// Draw Secondary and Both lines
	if(m_SecondaryMeasure)
	{
		// Secondary
		MoveToEx(tmpDC, X, m_H * 2 - 1, NULL);
		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, m_H + Y - 1);

		if(secondaryValue > primaryValue) 
		{
			SelectObject(tmpDC, m_SecondaryPen);
			Y = m_H - secondaryValue;
			LineTo(tmpDC, X, m_H + Y - 1);
		}
		SelectObject(tmpDC, m_TransparentPen);
		LineTo(tmpDC, X, m_H - 1);

		// Both
		MoveToEx(tmpDC, X, m_H * 3 - 1, NULL);
		Y = max( m_H - primaryValue, m_H - secondaryValue);
		SelectObject(tmpDC, m_BothPen);
		LineTo(tmpDC, X, m_H * 2 + Y - 1);
		SelectObject(tmpDC, m_TransparentPen);
		LineTo(tmpDC, X, m_H * 2 - 1);
	}

	m_MeterPos++;
	m_MeterPos %= m_W;

	PaintImages(meterWindow, tmpDC);

	SelectObject(tmpDC, oldBM);
	SelectObject(tmpDC, oldPen);
	DeleteObject(tmpDC);
}

/*
** PaintImages
**
** This method maskblits the meter bitmaps on the double buffer
**
*/
void CMeterHistogram::PaintImages(CMeterWindow& meterWindow, HDC dc)
{
	if(IsHidden()) return;

	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_PrimaryBitmap);

	HDC tmpDC = CreateCompatibleDC(dc);
	HBITMAP oldBM2 = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);

	MaskBlit(bufferDC, dc, tmpDC, m_MaskBitmap, 0);

	if(m_SecondaryBitmap)
	{
		SelectObject(dc, m_SecondaryBitmap);
		MaskBlit(bufferDC, dc, tmpDC, m_MaskBitmap, m_H);

		SelectObject(dc, m_BothBitmap);
		MaskBlit(bufferDC, dc, tmpDC, m_MaskBitmap, m_H * 2);
	}

	SelectObject(dc, oldBM);
	SelectObject(tmpDC, oldBM2);
	DeleteObject(tmpDC);
}

/*
** MaskBlit
**
** This is the mask blit method. The source is blitted over the destination
** in such way that only the parts in the mask are drawn over.
**
*/
void CMeterHistogram::MaskBlit(HDC destDC, HDC scrDC, HDC tmpDC, HBITMAP maskBitmap, int yOffset)
{
	// Take a copy of the source image
	BitBlt(tmpDC, 0, 0, m_W, m_H, scrDC, 0, 0, SRCCOPY);

	// Blit the graph in two phases so that we'll get scrolling

	SelectObject(scrDC, m_MaskBitmap);
	BitBlt(scrDC, 0, yOffset, m_W, m_H, scrDC, 0, 0, DSTINVERT);	// Invert the mask

	// Mask the destination
	if(m_MeterPos > 0) 
	{
		BitBlt(destDC,
				m_X + m_W - m_MeterPos,
				m_Y,
				m_MeterPos,
				m_H,
				scrDC,
				0,
				yOffset,
				SRCAND);
	}

	if(m_MeterPos < m_W) 
	{
		BitBlt(destDC,
				m_X,
				m_Y,
				m_W - m_MeterPos,
				m_H,
				scrDC,
				m_MeterPos,
				yOffset,
				SRCAND);
	}

	BitBlt(scrDC, 0, yOffset, m_W, m_H, scrDC, 0, 0, DSTINVERT);	// Invert the mask
	
	// Mask the source
	if(m_MeterPos > 0) 
	{
		BitBlt(tmpDC,
				0 + m_W - m_MeterPos,
				0,
				m_MeterPos,
				m_H,
				scrDC,
				0,
				yOffset,
				SRCAND);
	}

	if(m_MeterPos < m_W) 
	{
		BitBlt(tmpDC,
				0,
				0,
				m_W - m_MeterPos,
				m_H,
				scrDC,
				m_MeterPos,
				yOffset,
				SRCAND);
	}

	// XOR the masked source bitmap over the masked destination
	BitBlt(destDC,
			m_X,
			m_Y,
			m_W,
			m_H,
			tmpDC,
			0,
			0,
			SRCINVERT);
}

/*
** BindMeasure
**
** Overwritten method to handle the secondary mearuse binding.
**
*/
void CMeterHistogram::BindMeasure(std::list<CMeasure*>& measures)
{
	CMeter::BindMeasure(measures);

	if(!m_SecondaryMeasureName.empty())
	{
		// Go through the list and check it there is a secondary measure for us
		std::list<CMeasure*>::iterator i = measures.begin();
		for( ; i != measures.end(); i++)
		{
			if(_stricmp((*i)->GetName(), m_SecondaryMeasureName.c_str()) == 0)
			{
				m_SecondaryMeasure = (*i);
				return;
			}
		}

        throw CError(std::string("The meter [") + m_Name + "] cannot be bound with [" + m_SecondaryMeasureName + "]!", __LINE__, __FILE__);
	}
}
