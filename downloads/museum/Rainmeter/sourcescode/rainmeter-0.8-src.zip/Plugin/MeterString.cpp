/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterString.cpp,v 1.8 2002/07/01 15:32:20 rainy Exp $

  $Log: MeterString.cpp,v $
  Revision 1.8  2002/07/01 15:32:20  rainy
  Added NumOfDecimals

  Revision 1.7  2002/04/26 18:22:02  rainy
  Added possibility to hide the meter.

  Revision 1.6  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.5  2001/12/23 10:14:33  rainy
  Hex color values are now also supported.

  Revision 1.4  2001/10/14 07:32:32  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.3  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.2  2001/09/01 12:57:33  rainy
  Added support for percentual measuring.

  Revision 1.1  2001/08/12 15:35:08  Rainy
  Inital Version


*/

#include "Rainmeter.h"
#include "MeterString.h"
#include "Measure.h"
#include "Error.h"

/*
** CMeterString
**
** The constructor
**
*/
CMeterString::CMeterString() : CMeter()
{
	m_Color = RGB(255, 255, 255);
	m_AutoScale = true;
	m_Align = LEFT;
	m_Font = NULL;
	m_Style = NORMAL;
	m_FontSize = 10;
	m_Scale = 1.0;
	m_NoDecimals = true;
	m_Percentual = true;
	m_NumOfDecimals = -1;
}

/*
** ~CMeterString
**
** The destructor
**
*/
CMeterString::~CMeterString()
{
	if(m_Font)
	{
		DeleteObject(m_Font);
	}
}

/*
** Initialize
**
** Create the font that is used to draw the text.
**
*/
void CMeterString::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	int weight = FW_NORMAL;
	BYTE italic = FALSE;

	switch(m_Style)
	{
	case ITALIC:
		italic = TRUE;
		break;

	case BOLD:
		weight = FW_BOLD;
		break;

	case BOLDITALIC:
		italic = TRUE;
		weight = FW_BOLD;
		break;
	}

	int height = -MulDiv(m_FontSize, GetDeviceCaps(meterWindow.GetDoubleBuffer(), LOGPIXELSY), 72);

	m_Font = CreateFont( height, 0, 0, 0, weight, italic, 0, 0, 0, 
					OUT_DEVICE_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
					DEFAULT_PITCH, m_FontFace.c_str());
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterString::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	// Read configs for String meter
	if(GetPrivateProfileString(section, "FontColor", "0, 255, 0", tmpSz, 255, filename) > 0) 
	{
		m_Color = ParseColor(tmpSz);
	}

	if(GetPrivateProfileString(section, "Prefix", "", tmpSz, 255, filename) > 0) 
	{
		m_Prefix = tmpSz;
	}

	if(GetPrivateProfileString(section, "Postfix", "", tmpSz, 255, filename) > 0) 
	{
		m_Postfix = tmpSz;
	}

	m_Percentual = 0!=GetPrivateProfileInt(section, "Percentual", 0, filename);
	m_AutoScale = 0!=GetPrivateProfileInt(section, "AutoScale", 0, filename);
	m_FontSize = GetPrivateProfileInt(section, "FontSize", 0, filename);
	m_NumOfDecimals = GetPrivateProfileInt(section, "NumOfDecimals", -1, filename);

	if(GetPrivateProfileString(section, "Scale", "1", tmpSz, 255, filename) > 0) 
	{
		if(strchr(tmpSz, '.') == NULL)
		{
			m_NoDecimals = true;
		}
		else
		{
			m_NoDecimals = false;
		}
		m_Scale = atof(tmpSz);
	}

	if(GetPrivateProfileString(section, "FontFace", "Arial", tmpSz, 255, filename) > 0) 
	{
		m_FontFace = tmpSz;
	}

	if(GetPrivateProfileString(section, "StringAlign", "LEFT", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp(tmpSz, "LEFT") == 0)
		{
			m_Align = LEFT;
		}
		else if(_stricmp(tmpSz, "RIGHT") == 0)
		{
			m_Align = RIGHT;
		}
		else if(_stricmp(tmpSz, "CENTER") == 0)
		{
			m_Align = CENTER;
		}
		else
		{
            throw CError(std::string("No such StringAlign: ") + tmpSz, __LINE__, __FILE__);
		}
	}

	if(GetPrivateProfileString(section, "StringStyle", "NORMAL", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp(tmpSz, "NORMAL") == 0)
		{
			m_Style = NORMAL;
		}
		else if(_stricmp(tmpSz, "BOLD") == 0)
		{
			m_Style = BOLD;
		}
		else if(_stricmp(tmpSz, "ITALIC") == 0)
		{
			m_Style = ITALIC;
		}
		else if(_stricmp(tmpSz, "BOLDITALIC") == 0)
		{
			m_Style = BOLDITALIC;
		}
		else
		{
            throw CError(std::string("No such StringStyle: ") + tmpSz, __LINE__, __FILE__);
		}
	}
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterString::Draw(CMeterWindow& meterWindow)
{
	if(m_Measure == NULL || IsHidden()) return;
		
	char buffer[MAX_LINE_LENGTH];
	HDC bufferDC = meterWindow.GetDoubleBuffer();

	SetTextColor(bufferDC, m_Color);
	SetBkMode(bufferDC, TRANSPARENT); 
	HFONT oldFont = (HFONT)SelectObject(bufferDC, m_Font);

	switch(m_Align)
	{
	case CENTER:
		SetTextAlign(bufferDC, TA_CENTER);
		break;

	case RIGHT:
		SetTextAlign(bufferDC, TA_RIGHT);
		break;

	case LEFT:
		SetTextAlign(bufferDC, TA_LEFT);
		break;
	}

	int decimals = (m_NoDecimals && !m_AutoScale) ? 0 : 1;
	if (m_NumOfDecimals != -1) decimals = m_NumOfDecimals;
	
	sprintf(buffer, "%s%s%s", m_Prefix.c_str(), 
		m_Measure->GetStringValue(m_AutoScale, m_Scale, decimals, m_Percentual), 
							  m_Postfix.c_str());

	TextOut(bufferDC, m_X, m_Y, buffer, strlen(buffer));

	SelectObject(bufferDC, oldFont);
}

