/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Rainmeter.cpp,v 1.11 2002/07/01 15:01:18 rainy Exp $

  $Log: Rainmeter.cpp,v $
  Revision 1.11  2002/07/01 15:01:18  rainy
  Wharfdata is not used anymore.
  Added Toggle.

  Revision 1.10  2002/05/05 10:47:50  rainy
  Fixed the Regresh and ChangeConfig bangs

  Revision 1.9  2002/05/04 08:10:46  rainy
  Added the new bangs.

  Revision 1.8  2002/04/27 10:27:13  rainy
  Added bangs to hide/show meters and measures

  Revision 1.7  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.6  2001/10/14 07:32:32  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.5  2001/09/26 16:24:57  rainy
  Cleaned up the code

  Revision 1.4  2001/09/01 12:56:44  rainy
  Added refresh bang.

  Revision 1.3  2001/08/25 17:06:38  rainy
  Changed few methods to inlines.
  Now the wharf data is stored fully.

  Revision 1.2  2001/08/19 09:03:50  rainy
  Added support for Litestep's GetRevID.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "Rainmeter.h"
#include "Error.h"
#include <assert.h>

CRainmeter* Rainmeter; // The module

bool CRainmeter::c_DummyLitestep=false;
std::string CRainmeter::c_CmdLine;

/*
** initWharfModule
**
** This function is called when the plugin is initialized by wharf or lsbox.
**
*/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, void* wd)
{
	int Result=1;
	
	try {
		Rainmeter=new CRainmeter;

		if(Rainmeter) 
        {
			Result=Rainmeter->Initialize(ParentWnd, dllInst, wd, NULL);
		}

	} 
    catch(CError& error) 
    {
		MessageBox(ParentWnd, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return Result;
}

/*
** quitWharfModule
**
** This is called when the wharf plugin quits.
**
*/
void quitWharfModule(HINSTANCE dllInst)
{
	quitModule(dllInst);
}

/*
** getLSRegion
**
** Returns the window region for the wharf
**
*/
HRGN getLSRegion(int xOffset, int yOffset)
{
	if(Rainmeter) return Rainmeter->GetRegion(xOffset, yOffset);

	return NULL;
}

/*
** initModuleEx
**
** This is called when the plugin is initialized
**
*/
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int Result=1;
	
	try {
		Rainmeter=new CRainmeter;

		if(Rainmeter) {
			Result=Rainmeter->Initialize(ParentWnd, dllInst, NULL, szPath);
		}

	} 
    catch(CError& error) 
    {
		MessageBox(ParentWnd, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return Result;
}

/*
** quitModule
**
** This is called when the plugin quits.
**
*/
void quitModule(HINSTANCE dllInst)
{
	if(Rainmeter) 
	{
		Rainmeter->Quit(dllInst);
		delete Rainmeter;
		Rainmeter = NULL;
	}
}

/*
** Initialize
**
** Init Rainmeter
**
*/
void Initialize(bool DummyLS, LPCSTR CmdLine)
{
	CRainmeter::SetDummyLitestep(DummyLS);
	CRainmeter::SetCommandLine(CmdLine);

}

/*
** RainmeterHide
**
** Callback for the !RainmeterHide bang
**
*/
void RainmeterHide(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->Hide();
}

/*
** RainmeterShow
**
** Callback for the !RainmeterShow bang
**
*/
void RainmeterShow(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->Show();
}

/*
** RainmeterToggle
**
** Callback for the !RainmeterToggle bang
**
*/
void RainmeterToggle(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->Toggle();
}

/*
** RainmeterHideMeter
**
** Callback for the !RainmeterHideMeter bang
**
*/
void RainmeterHideMeter(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->HideMeter(arg);
}

/*
** RainmeterShowMeter
**
** Callback for the !RainmeterShowMeter bang
**
*/
void RainmeterShowMeter(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->ShowMeter(arg);
}

/*
** RainmeterToggleMeter
**
** Callback for the !RainmeterToggleMeter bang
**
*/
void RainmeterToggleMeter(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->ToggleMeter(arg);
}

/*
** RainmeterHideMeasure
**
** Callback for the !RainmeterHideMeasure bang
**
*/
void RainmeterDisableMeasure(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->DisableMeasure(arg);
}

/*
** RainmeterShowMeasure
**
** Callback for the !RainmeterShowMeasure bang
**
*/
void RainmeterEnableMeasure(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->EnableMeasure(arg);
}

/*
** RainmeterToggleMeasure
**
** Callback for the !RainmeterToggleMeasure bang
**
*/
void RainmeterToggleMeasure(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->ToggleMeasure(arg);
}

/*
** RainmeterRefresh
**
** Callback for the !RainmeterRefresh bang
**
*/
void RainmeterRefresh(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->Refresh(arg);
}

/*
** RainmeterChangeConfig
**
** Callback for the !RainmeterChangeConfig bang
**
*/
void RainmeterChangeConfig(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->ChangeConfig(arg);
}

/* 
** CRainmeter
**
** Constructor
**
*/
CRainmeter::CRainmeter()
{
	m_WharfData = false;
}

/* 
** ~CRainmeter
**
** Destructor
**
*/
CRainmeter::~CRainmeter()
{
}

/* 
** Initialize
**
** The main initialization function for the module.
** May throw CErrors !!!!
**
*/
int CRainmeter::Initialize(HWND Parent, HINSTANCE Instance, void* wd, LPCSTR szPath)
{
	int Result=0;

	if(Parent==NULL || Instance==NULL) 
	{
		throw CError(CError::ERROR_NULL_PARAMETER, __LINE__, __FILE__);
	}	

	m_WharfData = (wd != NULL);

	if(!c_DummyLitestep) InitalizeLitestep();

	// Create the meter window and initialize it
	Result = m_Meter.Initialize(*this, Parent, Instance);

	// If we're running as Litestep's plugin, register the !bangs
	if(!c_DummyLitestep) 
	{
		int Msgs[] = { LM_GETREVID, 0 };
		// Register RevID message to Litestep
		::SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)m_Meter.GetWindow(), (LPARAM)Msgs);

		AddBangCommand("!RainmeterRefresh", RainmeterRefresh);
		AddBangCommand("!RainmeterHide", RainmeterHide);
		AddBangCommand("!RainmeterShow", RainmeterShow);
		AddBangCommand("!RainmeterToggle", RainmeterToggle);
		AddBangCommand("!RainmeterHideMeter", RainmeterHideMeter);
		AddBangCommand("!RainmeterShowMeter", RainmeterShowMeter);
		AddBangCommand("!RainmeterToggleMeter", RainmeterToggleMeter);
		AddBangCommand("!RainmeterDisableMeasure", RainmeterDisableMeasure);
		AddBangCommand("!RainmeterEnableMeasure", RainmeterEnableMeasure);
		AddBangCommand("!RainmeterToggleMeasure", RainmeterToggleMeasure);
		AddBangCommand("!RainmeterChangeConfig", RainmeterChangeConfig);
	}

	return Result;	// Alles OK
}

/* 
** Quit
**
** Called when the module quits
**
*/
void CRainmeter::Quit(HINSTANCE dllInst)
{
	// If we're running as Litestep's plugin, unregister the !bangs
	if(!c_DummyLitestep) 
	{
		int Msgs[] = { LM_GETREVID, 0 };
		// Unregister RevID message
		if(m_Meter.GetWindow()) ::SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)m_Meter.GetWindow(), (LPARAM)Msgs);

		RemoveBangCommand("!RainmeterRefresh");
		RemoveBangCommand("!RainmeterHide");
		RemoveBangCommand("!RainmeterShow");
		RemoveBangCommand("!RainmeterToggle");
		RemoveBangCommand("!RainmeterHideMeter");
		RemoveBangCommand("!RainmeterShowMeter");
		RemoveBangCommand("!RainmeterToggleMeter");
		RemoveBangCommand("!RainmeterHideMeasure");
		RemoveBangCommand("!RainmeterShowMeasure");
		RemoveBangCommand("!RainmeterToggleMeasure");
		RemoveBangCommand("!RainmeterChangeConfig");
	}
}

/* 
** GetRegion
**
** Function returns the window region for the Wharf. Probably should 
** add the implementation to here for better combatibility with wharf 
** and lsbox.
**
*/
HRGN CRainmeter::GetRegion(int xOffset, int yOffset)
{
	return NULL;
}

/* 
** Refresh
**
** Refreshes Rainmeter. If argument is given the new config name and ini-file
** are used instead of the currently active.
*/
void CRainmeter::Refresh(const char* arg)
{
	std::string config, iniFile;

	if (arg != NULL && strlen(arg) > 0) 
	{
		char* token;
		char* str = new char[strlen(arg) + 1];
		strcpy(str, arg);

		// Separate the config name
		token = strtok(str, " ");
		if(token)
		{
			config = token;
		}
		// Separate the inifile name
		token = strtok( NULL, " ");
		if(token)
		{
			iniFile = token;
		}

		delete str;
	}

	try 
	{
		m_Meter.Refresh(false, config, iniFile);
	} 
    catch(CError& error) 
    {
		MessageBox(m_Meter.GetWindow(), error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}
}

/* 
** ChangeConfig
**
** Changes the config (path) to the given and refreshes Rainmeter
*/
void CRainmeter::ChangeConfig(const char* arg)
{
	if (arg != NULL && strlen(arg) > 0) 
	{
		try 
		{
			char tmpSz[MAX_LINE_LENGTH];
			VarExpansion(tmpSz, arg);		// Expand litestep variables
			SetCommandLine(tmpSz);
			m_Meter.Refresh(false);
		} 
		catch(CError& error) 
		{
			MessageBox(m_Meter.GetWindow(), error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}
}
