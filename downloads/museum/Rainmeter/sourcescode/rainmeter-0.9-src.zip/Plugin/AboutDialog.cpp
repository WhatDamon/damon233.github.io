/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/AboutDialog.cpp,v 1.2 2002/12/23 14:26:33 rainy Exp $

  $Log: AboutDialog.cpp,v $
  Revision 1.2  2002/12/23 14:26:33  rainy
  Made the dialog resizable.

  Revision 1.1  2002/07/01 15:35:55  rainy
  Intial version

*/

#pragma warning(disable: 4786)

#include "Rainmeter.h"
#include "MeterWindow.h"
#include "Measure.h"
#include "resource.h"

extern CRainmeter* Rainmeter;

INT_PTR CALLBACK AboutProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam);
HWND g_DialogWin = NULL;

HWND OpenAboutDialog(HWND hwndOwner, HINSTANCE instance)
{
	if (g_DialogWin == NULL)
	{
		g_DialogWin = CreateDialog(instance, MAKEINTRESOURCE(IDD_ABOUT_DIALOG), hwndOwner, AboutProc);
	}
	ShowWindow(g_DialogWin, SW_SHOWNORMAL);

	return g_DialogWin;
}

void UpdateAboutStatistics()
{
	if (g_DialogWin != NULL && IsWindowVisible(g_DialogWin))
	{
		HWND widget = GetDlgItem(g_DialogWin, IDC_STATISTICS);
		std::list<CMeasure*>& measures = Rainmeter->GetMeterWindow().GetMeasures();

		SendMessage(widget, WM_SETREDRAW, 0, 0);
		SendMessage(widget, LB_RESETCONTENT, 0, 0);

		std::list<CMeasure*>::iterator i = measures.begin();
		for( ; i != measures.end(); i++)
		{
			const char* sz = (*i)->GetStats();
			if (sz && strlen(sz) > 0)
			{
				SendMessage(widget, LB_ADDSTRING, 0, (LPARAM)sz);
			}
		}
		SendMessage(widget, WM_SETREDRAW, 1, 0);
	}
}

BOOL OnInitAboutDialog(HWND window) 
{
	char tmpSz[256];
	HWND widget;

	widget = GetDlgItem(window, IDC_VERSION_STRING);
	sprintf(tmpSz, "%s version %s", APPNAME, APPVERSION);
	SetWindowText(widget, tmpSz);

	widget = GetDlgItem(window, IDC_BUILD_STRING);
	sprintf(tmpSz, "(Build on %s)", __DATE__);
	SetWindowText(widget, tmpSz);

	g_DialogWin = window;

	const std::string& sz = Rainmeter->GetMeterWindow().GetStatsDate();
	if (!sz.empty())
	{
		widget = GetDlgItem(window, IDC_STATISTICS_STRING);
		sprintf(tmpSz, "Statistics (since %s)", sz.c_str());
		SetWindowText(widget, tmpSz);
	}

	UpdateAboutStatistics();

	return TRUE;
}

INT_PTR CALLBACK AboutProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam) 
{
    switch (message) 
    { 
        case WM_INITDIALOG:
			return OnInitAboutDialog(hwndDlg);

		case WM_WINDOWPOSCHANGING:
			{
				WINDOWPOS* pos = (WINDOWPOS*)lParam;

				// Do not allow resizing of width
				RECT r;
				GetWindowRect(hwndDlg, &r);
				if (r.right - r.left != pos->cx)
				{
					pos->cx = r.right - r.left;
				}

				// Do not height must be larger than 300
				if (pos->cy < 250)
				{
					pos->cy = 250;
				}
			}
			break;

		case WM_SIZE:
			{
				RECT r;
				HWND widget;

				GetClientRect(hwndDlg, &r);

				// Reposition the statistics widgets
				widget = GetDlgItem(hwndDlg, IDC_STATISTICS_STRING);
				SetWindowPos(widget, NULL, 0, 0, r.right - 22, r.bottom - 150, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDC_STATISTICS);
				SetWindowPos(widget, NULL, 0, 0, r.right - 44, r.bottom - 180, SWP_NOMOVE | SWP_NOZORDER);
				widget = GetDlgItem(hwndDlg, IDOK);
				SetWindowPos(widget, NULL, 101, r.bottom - 34, 75, 23, SWP_NOZORDER);
			}
			break;

		case WM_CLOSE:
			DestroyWindow(hwndDlg);
			g_DialogWin = NULL;
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
				DestroyWindow(hwndDlg);
				g_DialogWin = NULL;
				return TRUE;
			}
			break;
	}
    return FALSE;
}

