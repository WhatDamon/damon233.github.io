/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/Measure.cpp,v 1.15 2003/02/10 18:13:49 rainy Exp $

  $Log: Measure.cpp,v $
  Revision 1.15  2003/02/10 18:13:49  rainy
  Added median filter to max value.

  Revision 1.14  2002/12/23 14:26:21  rainy
  Stats are gathered a bit different way now.

  Revision 1.13  2002/05/05 10:49:16  rainy
  Disabled measures return 0.

  Revision 1.12  2002/05/04 08:12:33  rainy
  Measure update is not tied to the update rate directly anymore.

  Revision 1.11  2002/04/26 18:24:16  rainy
  Modified the Update method to support disabled measures.

  Revision 1.10  2002/04/01 15:39:09  rainy
  Fixed IfBelow and IfAbove actions.
  Added NetTotal measure.

  Revision 1.9  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.8  2001/12/23 10:18:52  rainy
  Added Time and removed Perfmon.

  Revision 1.7  2001/10/28 10:23:59  rainy
  GetStringValue uses consts.
  Added IfAbove/Below actions.
  Added Plugin and Registry Measures.

  Revision 1.6  2001/10/14 07:32:03  rainy
  Minor monifications to remove few warnings with VC.NET.
  In error situations CError is thrown instead just a boolean value.

  Revision 1.5  2001/09/26 16:27:15  rainy
  Changed the interfaces a bit.

  Revision 1.4  2001/09/01 13:00:41  rainy
  Slight changes in the interface. The value is now measured only once if possible.
  Added support for logging the max value.

  Revision 1.3  2001/08/19 09:15:41  rainy
  Invert was moved here from the meter.

  Revision 1.2  2001/08/12 15:47:00  Rainy
  Adjusted Update()'s interface.
  Added GetStringValue() method.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include "Measure.h"
#include "MeasureCPU.h"
#include "MeasureMemory.h"
#include "MeasurePhysicalMemory.h"
#include "MeasureVirtualMemory.h"
#include "MeasureNetIn.h"
#include "MeasureNetOut.h"
#include "MeasureNetTotal.h"
#include "MeasureDiskSpace.h"
#include "MeasureUptime.h"
#include "MeasurePlugin.h"
#include "MeasureRegistry.h"
#include "MeasureTime.h"
#include "Rainmeter.h"
#include "Error.h"
#include <algorithm>

const int MEDIAN_SIZE = 7;

/*
** CMeasure
**
** The constructor
**
*/
CMeasure::CMeasure()
{
	m_Invert = false;
	m_LogMaxValue = false;
	m_MaxValue = 1;
	m_Value = 0;
	m_IfAboveValue = 0;
	m_IfBelowValue = 0;
	m_IfAboveCommited = false;
	m_IfBelowCommited = false;
	m_Disabled = false;
	m_UpdateDivider = 1;
	m_UpdateCounter = 0;
	m_MedianPos = 0;
}

/*
** ~CMeasure
**
** The destructor
**
*/
CMeasure::~CMeasure()
{
}

/*
** ReadConfig
**
** Reads the common configs for all Measures. The inherited classes
** must call the base implementation if they overwrite this method.
** 
*/
void CMeasure::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[MAX_LINE_LENGTH];

	m_Invert = 0!=GetPrivateProfileInt(section, "InvertMeasure", 0, filename);
	m_Disabled = 0!=GetPrivateProfileInt(section, "Disabled", 0, filename);
	m_UpdateDivider = GetPrivateProfileInt(section, "UpdateDivider", 1, filename);
	m_UpdateCounter = m_UpdateDivider;

	// The ifabove/ifbelow define actions that are ran when the value goes above/below the given number.
	m_IfAboveValue = GetPrivateProfileInt(section, "IfAboveValue", 0, filename);
	m_IfBelowValue = GetPrivateProfileInt(section, "IfBelowValue", 0, filename);

	if(GetPrivateProfileString( section, "IfAboveAction", "", tmpSz, 255, filename) > 0) 
	{
 		m_IfAboveAction = tmpSz;
	}

	if(GetPrivateProfileString( section, "IfBelowAction", "", tmpSz, 255, filename) > 0) 
	{
 		m_IfBelowAction = tmpSz;
	}
}

/*
** Update
**
** The base implementation of the update method. This includes the code
** that is common for all measures. This is called every time the measure 
** is updated. The inherited classes must call the base implementation if 
** they overwrite this method. If this method returns false, the update
** needs not to be done.
** 
*/
bool CMeasure::Update(CMeterWindow& meterWindow)
{
	if (IsDisabled()) 
	{
		m_Value = 0;	// Disable measures return 0 as value
		return false;
	}
	
	// Only update the counter if the divider 
	m_UpdateCounter++;
	if (m_UpdateCounter < m_UpdateDivider) return false;
	m_UpdateCounter = 0;

	// If we're logging the maximum value of the measure, check if
	// the new value is greater than the old one, and update if necessary.
	if(m_LogMaxValue)
	{
		if (m_MedianValues.empty())
		{
			m_MedianValues.resize(MEDIAN_SIZE, 0);
		}

		m_MedianValues[m_MedianPos] = m_Value;
		m_MedianPos++;
		m_MedianPos %= MEDIAN_SIZE;

		std::vector<UINT> medianArray = m_MedianValues;
		std::sort(medianArray.begin(), medianArray.end());

		m_MaxValue = max(m_MaxValue, medianArray[MEDIAN_SIZE / 2]);
	}

	// Check the IfAboveValue
	if(!m_IfAboveAction.empty())
	{
		if(m_Value > m_IfAboveValue)
		{
			if(!m_IfAboveCommited)
			{
				meterWindow.ExecuteCommand(m_IfAboveAction.c_str());
				m_IfAboveCommited = true;
			}
		}
		else
		{
			m_IfAboveCommited = false;
		}
	}

	// Check the IfBelowValue
	if(!m_IfBelowAction.empty())
	{
		if(m_Value < m_IfBelowValue)
		{
			if(!m_IfBelowCommited)
			{
				meterWindow.ExecuteCommand(m_IfBelowAction.c_str());
				m_IfBelowCommited = true;
			}
		}
		else
		{
			m_IfBelowCommited = false;
		}
	}

	return true;
}

/*
** GetValue
**
** Returns the value of the measure. If this method is overwritten
** remember to handle the m_Invert or use the base implementation.
** 
*/
UINT CMeasure::GetValue()
{
	// Invert if so requested
	if(m_Invert)
	{
		return m_MaxValue - m_Value;
	}

	return m_Value;
}

/*
** GetStringValue
**
** This method returns the value as text string. The actual value is
** get with GetValue() so we don't have to worry about m_Invert.
** 
** autoScale  If true, scale the value automaticallu to some sensible range.
** scale      The scale to use if autoScale is false.
** decimals   Number of decimals used in the value.
** percentual Return the value as % from the maximum value.
*/
const char* CMeasure::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char buffer[MAX_LINE_LENGTH];
	static char buffer2[MAX_LINE_LENGTH];
	static char format[16];
	double value;
	UINT theValue = GetValue();

	if(percentual)
	{
		sprintf(buffer, "%u", (UINT)(100.0 * (double)theValue / (double)GetMaxValue()));
	} 
	else if(autoScale)
	{
		if(decimals == 0)
		{
			strcpy(format, "%%.0f ");
		}
		else
		{
			sprintf(format, "%%.%if ", decimals);
		}

		if(theValue > 1000 * 1000 * 1000)
		{
			strcat(format, "G");
			value = (double)(theValue / (1024 * 1024)) / 1024.0;
		}
		else if(theValue > 1000 * 1000)
		{
			strcat(format, "M");
			value = (double)(theValue / 1024) / 1024.0;
		}
		else if(theValue > 1000)
		{
			strcat(format, "k");
			value = (double)(theValue) / 1024.0;
		}
		else
		{
			value = (double)theValue;
		}
		sprintf(buffer, format, value);
	}
	else 
	{
		if(decimals == 0)
		{
			sprintf(buffer, "%u", (UINT)(theValue * (1.0 / scale) + 0.5));
		}
		else
		{
			sprintf(buffer2, "%%.%if", decimals);
			sprintf(buffer, buffer2, (double)(theValue * (1.0 / scale)));
		}
	}

	return buffer;
}

/*
** ReadStats
**
** Base implementation of stats reading. The stats are stored in registry 
** and the key is given as parameter. The stats are measure specific, so
** we do nothing here.
** 
*/
void CMeasure::ReadStats(const std::string& iniFile)
{
	// Do nuthing
}

/*
** WriteStats
**
** Base implementation of stats writing. The stats are stored in registry 
** and the key is given as parameter. The stats are measure specific, so
** we do nothing here.
** 
*/
void CMeasure::WriteStats(const std::string& iniFile)
{
	// Do nuthing
}

/*
** GetStats
**
** Returns the stats as string. The stats are shown in the About dialog.
** The stats are measure specific, so we return only an empty string. 
*/
const char* CMeasure::GetStats()
{
	static std::string value;

	value = m_Name + ": " + GetStringValue(true, 1, 1, false);

	return value.c_str();
}

/*
** Create
**
** Creates the given measure. This is the factory method for the measures.
** If new measures are implemented this method needs to be updated.
** 
*/
CMeasure* CMeasure::Create(const char* measure)
{
	// Comparson is caseinsensitive

	if(_stricmp("", measure) == 0)
	{
		return NULL;
	}
	else if(_stricmp("CPU", measure) == 0)
	{
		return new CMeasureCPU;
	} 
	else if(_stricmp("Memory", measure) == 0)
	{
		return new CMeasureMemory;
	}
	else if(_stricmp("NetIn", measure) == 0)
	{
		return new CMeasureNetIn;
	}
	else if(_stricmp("NetOut", measure) == 0)
	{
		return new CMeasureNetOut;
	}
	else if(_stricmp("NetTotal", measure) == 0)
	{
		return new CMeasureNetTotal;
	}
	else if(_stricmp("PhysicalMemory", measure) == 0)
	{
		return new CMeasurePhysicalMemory;
	}
	else if(_stricmp("SwapMemory", measure) == 0)
	{
		return new CMeasureVirtualMemory;
	}
	else if(_stricmp("FreeDiskSpace", measure) == 0)
	{
		return new CMeasureDiskSpace;
	}
	else if(_stricmp("Uptime", measure) == 0)
	{
		return new CMeasureUptime;
	}
	else if(_stricmp("Time", measure) == 0)
	{
		return new CMeasureTime;
	}
	else if(_stricmp("Plugin", measure) == 0)
	{
		return new CMeasurePlugin;
	}
	else if(_stricmp("Registry", measure) == 0)
	{
		return new CMeasureRegistry;
	}

    // Error
    throw CError(std::string("No such measure: ") + measure, __LINE__, __FILE__);

	return NULL;
}
