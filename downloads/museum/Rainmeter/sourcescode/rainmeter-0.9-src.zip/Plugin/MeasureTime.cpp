/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeasureTime.cpp,v 1.4 2003/02/10 18:13:14 rainy Exp $

  $Log: MeasureTime.cpp,v $
  Revision 1.4  2003/02/10 18:13:14  rainy
  Returns the time in secs as value.

  Revision 1.3  2002/04/26 18:24:15  rainy
  Modified the Update method to support disabled measures.

  Revision 1.2  2002/03/31 09:58:54  rainy
  Added some comments

  Revision 1.1  2001/12/23 10:11:08  rainy
  Initial version.

*/

#include "MeasureTime.h"
#include "Rainmeter.h"
#include <time.h>

/*
** CMeasureTime
**
** The constructor
**
*/
CMeasureTime::CMeasureTime() : CMeasure()
{
	/* Set time zone from TZ environment variable. If TZ is not set,
     * the operating system is queried to obtain the default value 
     * for the variable. 
     */
    _tzset();

	m_DeltaHours = 0;
}

/*
** ~CMeasureTime
**
** The destructor
**
*/
CMeasureTime::~CMeasureTime()
{
}

/*
** Update
**
** Updates the current time
**
*/
bool CMeasureTime::Update(CMeterWindow& meterWindow)
{
	time_t ltime;

	if (!CMeasure::Update(meterWindow)) return false;

	time(&ltime);

	// Modify the ltime to match the current timezone
	// This way we can use the value also for the clock
	struct tm* today;
    today = localtime(&ltime);
	UINT thisHour = (ltime % 86400) / 3600;
	m_DeltaHours = today->tm_hour - thisHour;
	m_Value = ltime + m_DeltaHours * 3600;

	return true;
}

/*
** GetStringValue
**
** Returns the time as string.
**
*/
const char* CMeasureTime::GetStringValue(bool autoScale, double scale, int decimals, bool percentual)
{
	static char tmpSz[MAX_LINE_LENGTH];
	struct tm* today;
	time_t ltime;

	ltime = m_Value - m_DeltaHours * 3600;
    today = localtime(&ltime);

	// Create the string
    strftime(tmpSz, MAX_LINE_LENGTH, m_Format.c_str(), today);

	return tmpSz;
}

/*
** ReadConfig
**
** Reads the measure specific configs.
**
*/
void CMeasureTime::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[MAX_LINE_LENGTH];

	CMeasure::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "Format", "%H:%M:%S", tmpSz, 255, filename) > 0) 
	{
 		m_Format = tmpSz;
	}
}
