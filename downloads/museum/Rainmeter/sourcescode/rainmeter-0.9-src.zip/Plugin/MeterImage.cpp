/*
  Copyright (C) 2002 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterImage.cpp,v 1.3 2003/02/10 18:12:45 rainy Exp $

  $Log: MeterImage.cpp,v $
  Revision 1.3  2003/02/10 18:12:45  rainy
  Now uses GDI+

  Revision 1.2  2002/07/01 15:32:50  rainy
  Removed include to lsapi.h

  Revision 1.1  2002/04/27 10:28:31  rainy
  Intial version.

*/

#include "MeterImage.h"
#include "Measure.h"
#include "Error.h"

using namespace Gdiplus;

/*
** CMeterImage
**
** The constructor
**
*/
CMeterImage::CMeterImage() : CMeter()
{
	m_Bitmap = NULL;
}

/*
** ~CMeterImage
**
** The destructor
**
*/
CMeterImage::~CMeterImage()
{
	if(m_Bitmap != NULL) delete m_Bitmap;
}

/*
** Initialize
**
** Load the image and get the dimensions of the meter from it.
**
*/
void CMeterImage::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	// Load the bitmap if defined
	if(!m_ImageName.empty())
	{
		WCHAR* wideSz = ConvertToWide(m_ImageName.c_str());
		m_Bitmap = new Bitmap(wideSz);
		delete [] wideSz;

		Status status = m_Bitmap->GetLastStatus();
		if(Ok != status)
		{
            throw CError(std::string("Unable to load image: ") + m_ImageName, __LINE__, __FILE__);
		}

		m_W = m_Bitmap->GetWidth();
		m_H = m_Bitmap->GetHeight();
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterImage::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "ImageName", "", tmpSz, 255, filename) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_ImageName = tmpSz;
	}
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterImage::Draw(CMeterWindow& meterWindow)
{
	CMeter::Draw(meterWindow);

	if(m_Bitmap == NULL || IsHidden()) return;	// Unable to continue

	Graphics graphics(meterWindow.GetDoubleBuffer());

	// Copy the image over the doublebuffer
	graphics.DrawImage(m_Bitmap, m_X, m_Y, m_W, m_H);
}

/*
** BindMeasure
**
** Overridden method. The Image meters need not to be bound on anything
**
*/
void CMeterImage::BindMeasure(std::list<CMeasure*>& measures)
{
	// Do nuthing
}

