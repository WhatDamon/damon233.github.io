/*
  Copyright (C) 2002 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterRoundLine.cpp,v 1.2 2003/02/10 18:12:44 rainy Exp $

  $Log: MeterRoundLine.cpp,v $
  Revision 1.2  2003/02/10 18:12:44  rainy
  Now uses GDI+

  Revision 1.1  2002/12/26 18:15:41  rainy
  Initial version

*/

#include "MeterRoundLine.h"
#include "Measure.h"
#include "Error.h"
#include <crtdbg.h>
#include <math.h>
#include <gdiplus.h>

using namespace Gdiplus;

/*
** CMeterRoundLine
**
** The constructor
**
*/
CMeterRoundLine::CMeterRoundLine() : CMeter()
{
	m_AntiAlias = false;
	m_LineWidth = 1.0;
	m_LineLength = 20;
	m_StartAngle = 0.0;
	m_RotationAngle = 0.0;
	m_ValueReminder = 0;
}

/*
** ~CMeterRoundLine
**
** The destructor
**
*/
CMeterRoundLine::~CMeterRoundLine()
{
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterRoundLine::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	if(GetPrivateProfileString(section, "LineWidth", "1.0", tmpSz, 255, filename) > 0) 
	{
		m_LineWidth = atof(tmpSz);
	}
	if(GetPrivateProfileString(section, "LineLength", "20.0", tmpSz, 255, filename) > 0) 
	{
		m_LineLength = atof(tmpSz);
	}
	if(GetPrivateProfileString(section, "StartAngle", "0.0", tmpSz, 255, filename) > 0) 
	{
		m_StartAngle = atof(tmpSz);
	}
	if(GetPrivateProfileString(section, "RotationAngle", "6.2832", tmpSz, 255, filename) > 0) 
	{
		m_RotationAngle = atof(tmpSz);
	}

	m_AntiAlias = (1 == GetPrivateProfileInt(section, "AntiAlias", m_AntiAlias, filename));

	m_ValueReminder = GetPrivateProfileInt(section, "ValueReminder", 0, filename);
	
	if(GetPrivateProfileString(section, "LineColor", "0, 0, 0", tmpSz, 255, filename) > 0) 
	{
		m_LineColor = ParseColor(tmpSz);
	}
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterRoundLine::Draw(CMeterWindow& meterWindow)
{
	if (m_Measure == NULL || IsHidden()) return;

	CMeter::Draw(meterWindow);

	unsigned int maxValue = 0;
	unsigned int value = 0;

	if (m_ValueReminder > 0)
	{
		maxValue = m_ValueReminder;
		value = m_Measure->GetValue() % m_ValueReminder;
	}
	else
	{
		maxValue = m_Measure->GetMaxValue();
		value = m_Measure->GetValue();
	}

	Graphics graphics(meterWindow.GetDoubleBuffer());		//GDI+
	if (m_AntiAlias)
	{
		graphics.SetSmoothingMode(SmoothingModeAntiAlias);
	}
	Pen pen(m_LineColor, m_LineWidth);

	// Calculate the center of for the line
	REAL x, y;
	REAL cx = m_X + m_W / 2.0;
	REAL cy = m_Y + m_H / 2.0;

	// Calculate the end point of the line
	double ratio = (double)value / (double)maxValue;
	double angle = m_RotationAngle * ratio;

	y = sin(m_StartAngle + angle);
	x = cos(m_StartAngle + angle);

	// Set the length
	x = x * m_LineLength + cx;
	y = y * m_LineLength + cy;

	graphics.DrawLine(&pen, cx, cy, x, y);
}
