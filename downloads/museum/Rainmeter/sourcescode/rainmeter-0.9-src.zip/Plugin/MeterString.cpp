/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterString.cpp,v 1.9 2003/02/10 18:12:44 rainy Exp $

  $Log: MeterString.cpp,v $
  Revision 1.9  2003/02/10 18:12:44  rainy
  Now uses GDI+

  Revision 1.8  2002/07/01 15:32:20  rainy
  Added NumOfDecimals

  Revision 1.7  2002/04/26 18:22:02  rainy
  Added possibility to hide the meter.

  Revision 1.6  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.5  2001/12/23 10:14:33  rainy
  Hex color values are now also supported.

  Revision 1.4  2001/10/14 07:32:32  rainy
  In error situations CError is thrown instead just a boolean value.

  Revision 1.3  2001/09/26 16:26:23  rainy
  Small adjustement to the interfaces.

  Revision 1.2  2001/09/01 12:57:33  rainy
  Added support for percentual measuring.

  Revision 1.1  2001/08/12 15:35:08  Rainy
  Inital Version


*/

#include "MeterString.h"
#include "Rainmeter.h"
#include "Measure.h"
#include "Error.h"

using namespace Gdiplus;

/*
** CMeterString
**
** The constructor
**
*/
CMeterString::CMeterString() : CMeter()
{
	m_Color = RGB(255, 255, 255);
	m_AutoScale = true;
	m_Align = LEFT;
	m_Font = NULL;
	m_FontFamily = NULL;
	m_Style = NORMAL;
	m_FontSize = 10;
	m_Scale = 1.0;
	m_NoDecimals = true;
	m_Percentual = true;
	m_AntiAlias = false;
	m_NumOfDecimals = -1;
}

/*
** ~CMeterString
**
** The destructor
**
*/
CMeterString::~CMeterString()
{
	if(m_Font) delete m_Font;
	if(m_FontFamily) delete m_FontFamily;
}

/*
** Initialize
**
** Create the font that is used to draw the text.
**
*/
void CMeterString::Initialize(CMeterWindow& meterWindow)
{
	CMeter::Initialize(meterWindow);

	WCHAR* wideSz = ConvertToWide(m_FontFace.c_str());
	m_FontFamily = new FontFamily(wideSz);
	delete [] wideSz;

	Status status = m_FontFamily->GetLastStatus();
	if(Ok != status)
	{
		delete m_FontFamily;
		m_FontFamily = NULL;
	}

	FontStyle style = FontStyleRegular;

	switch(m_Style)
	{
	case ITALIC:
		style = FontStyleItalic;
		break;

	case BOLD:
		style = FontStyleBold;
		break;

	case BOLDITALIC:
		style = FontStyleBoldItalic;
		break;
	}

	if (m_FontFamily)
	{
		m_Font = new Font(m_FontFamily, m_FontSize, style);
	}
	else
	{
		m_Font = new Font(FontFamily::GenericSansSerif(), m_FontSize, style);
	}

	status = m_Font->GetLastStatus();
	if(Ok != status)
	{
	    throw CError(std::string("Unable to create font: ") + m_FontFace, __LINE__, __FILE__);
	}
}

/*
** ReadConfig
**
** Read the meter-specific configs from the ini-file.
**
*/
void CMeterString::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	// Read configs for String meter
	if(GetPrivateProfileString(section, "FontColor", "0, 255, 0", tmpSz, 255, filename) > 0) 
	{
		m_Color = ParseColor(tmpSz);
	}

	if(GetPrivateProfileString(section, "Prefix", "", tmpSz, 255, filename) > 0) 
	{
		m_Prefix = tmpSz;
	}

	if(GetPrivateProfileString(section, "Postfix", "", tmpSz, 255, filename) > 0) 
	{
		m_Postfix = tmpSz;
	}

	m_AntiAlias = 0!=GetPrivateProfileInt(section, "AntiAlias", 0, filename);
	m_Percentual = 0!=GetPrivateProfileInt(section, "Percentual", 0, filename);
	m_AutoScale = 0!=GetPrivateProfileInt(section, "AutoScale", 0, filename);
	m_FontSize = GetPrivateProfileInt(section, "FontSize", 0, filename);
	m_NumOfDecimals = GetPrivateProfileInt(section, "NumOfDecimals", -1, filename);

	if(GetPrivateProfileString(section, "Scale", "1", tmpSz, 255, filename) > 0) 
	{
		if(strchr(tmpSz, '.') == NULL)
		{
			m_NoDecimals = true;
		}
		else
		{
			m_NoDecimals = false;
		}
		m_Scale = atof(tmpSz);
	}

	if(GetPrivateProfileString(section, "FontFace", "Arial", tmpSz, 255, filename) > 0) 
	{
		m_FontFace = tmpSz;
	}

	if(GetPrivateProfileString(section, "StringAlign", "LEFT", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp(tmpSz, "LEFT") == 0)
		{
			m_Align = LEFT;
		}
		else if(_stricmp(tmpSz, "RIGHT") == 0)
		{
			m_Align = RIGHT;
		}
		else if(_stricmp(tmpSz, "CENTER") == 0)
		{
			m_Align = CENTER;
		}
		else
		{
            throw CError(std::string("No such StringAlign: ") + tmpSz, __LINE__, __FILE__);
		}
	}

	if(GetPrivateProfileString(section, "StringStyle", "NORMAL", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp(tmpSz, "NORMAL") == 0)
		{
			m_Style = NORMAL;
		}
		else if(_stricmp(tmpSz, "BOLD") == 0)
		{
			m_Style = BOLD;
		}
		else if(_stricmp(tmpSz, "ITALIC") == 0)
		{
			m_Style = ITALIC;
		}
		else if(_stricmp(tmpSz, "BOLDITALIC") == 0)
		{
			m_Style = BOLDITALIC;
		}
		else
		{
            throw CError(std::string("No such StringStyle: ") + tmpSz, __LINE__, __FILE__);
		}
	}
}

/*
** Draw
**
** Draws the meter on the double buffer
**
*/
void CMeterString::Draw(CMeterWindow& meterWindow)
{
	if(IsHidden()) return;
		
	CMeter::Draw(meterWindow);

	char buffer[MAX_LINE_LENGTH];
	Graphics graphics(meterWindow.GetDoubleBuffer());
	StringFormat stringFormat;
	
	if (m_AntiAlias)
	{
		graphics.SetTextRenderingHint(TextRenderingHintAntiAlias);
	}
	else
	{
		graphics.SetTextRenderingHint(TextRenderingHintSystemDefault);
	}

	switch(m_Align)
	{
	case CENTER:
		stringFormat.SetAlignment(StringAlignmentCenter);
		break;

	case RIGHT:
		stringFormat.SetAlignment(StringAlignmentFar);
		break;

	case LEFT:
		stringFormat.SetAlignment(StringAlignmentNear);
		break;
	}

	int decimals = (m_NoDecimals && !m_AutoScale) ? 0 : 1;
	if (m_NumOfDecimals != -1) decimals = m_NumOfDecimals;

	if (m_Measure == NULL)
	{
		sprintf(buffer, "%s%s", m_Prefix.c_str(), m_Postfix.c_str());
	}
	else
	{
		sprintf(buffer, "%s%s%s", m_Prefix.c_str(), m_Measure->GetStringValue(m_AutoScale, m_Scale, decimals, m_Percentual), m_Postfix.c_str());
	}

	PointF point(m_X, m_Y);
	SolidBrush solidBrush(m_Color);

	WCHAR* wideSz = ConvertToWide(buffer);
	graphics.DrawString(wideSz, -1, m_Font, point, &stringFormat, &solidBrush);
	delete [] wideSz;

}

/*
** BindMeasure
**
** Overridden method. The string meters need not to be bound on anything
**
*/
void CMeterString::BindMeasure(std::list<CMeasure*>& measures)
{
	if (m_MeasureName.empty()) return;	// Allow NULL measure binding

	CMeter::BindMeasure(measures);
}

