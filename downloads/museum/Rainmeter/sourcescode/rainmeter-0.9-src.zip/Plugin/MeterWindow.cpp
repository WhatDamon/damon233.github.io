/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox/cvsroot/Rainmeter/Plugin/MeterWindow.cpp,v 1.21 2003/02/10 18:11:33 rainy Exp $

  $Log: MeterWindow.cpp,v $
  Revision 1.21  2003/02/10 18:11:33  rainy
  Too much changes to mention :-)

  Revision 1.20  2002/12/23 14:25:21  rainy
  Separated skin and other settings.
  Stats are now written in ini file.

  Revision 1.19  2002/07/01 15:27:36  rainy
  AlwaysOnTop gets now three values.
  Added Toggle().
  Added RainmeterCurrentConfig and RainmeterCurrentConfigIni.
  The ini file's timestamp is checked before it is overwritten.
  AboutBox is now in separate source file.
  Added SnapEdges.

  Revision 1.18  2002/05/05 10:48:56  rainy
  Fixed few bugs.

  Revision 1.17  2002/05/04 08:16:35  rainy
  There can be any number of ini files in the config folders.
  WM_COPYDATA can be used to deliver the bangs.
  Added support for per meter actions.

  Revision 1.16  2002/04/27 10:27:42  rainy
  Added hide/show to meters and enable/disable to measures

  Revision 1.15  2002/04/01 15:36:10  rainy
  Added PLAY, PLAYSTOP and PLAYLOOP build-in commands.

  Revision 1.14  2002/03/31 09:58:53  rainy
  Added some comments

  Revision 1.13  2002/03/29 16:32:58  rainy
  Fixed a typo

  Revision 1.12  2002/01/16 16:06:29  rainy
  The file doesn't need to be named Rainmeter.ini anymore.
  If the old config doesn't exist, we'll yse the first one instead.

  Revision 1.11  2001/12/23 10:14:09  rainy
  Added support for different configs.
  The position of the window is now remembered.

  Revision 1.10  2001/10/28 10:15:21  rainy
  Added left and right mouse up actions.
  IsNT() can now identify different OS more precisely.

  Revision 1.9  2001/10/14 07:27:58  rainy
  Changed the errorhandling.
  Stats now include the date when they were started to collect.

  Revision 1.8  2001/09/26 16:25:44  rainy
  Added support for statistics.
  Meters and Measures are now stored here.

  Revision 1.7  2001/09/01 12:57:13  rainy
  Added support for Bar and Bitmap meters.

  Revision 1.6  2001/08/25 18:08:34  rainy
  Added mousebutton actions.
  The About dialog has now the build date.

  Revision 1.5  2001/08/25 17:15:52  rainy
  Added context menu, which can show the about dialog, refresh the configuration or quit the program.
  The ini-file can be defined in the step.rc also.

  Revision 1.4  2001/08/19 09:43:29  rainy
  Mouse over hid the window even if it was not wanted.

  Revision 1.3  2001/08/19 09:12:12  rainy
  Added support for GetRevID.
  Added StartHidden.

  Revision 1.2  2001/08/12 15:36:55  Rainy
  The ini-file's exsistance is checked.
  Added String meter.
  Improved mouse over hiding.

  Revision 1.1.1.1  2001/08/11 10:58:19  Rainy
  Added to CVS.

*/

#include <windows.h>
#include <gdiplus.h>
#include "MeterWindow.h"
#include "Rainmeter.h"
#include "Error.h"
#include <math.h>
#include <time.h>
#include "Meter.h"
#include "Measure.h"
#include "AboutDialog.h"
#include "resource.h"
#include "Litestep.h"
#include <Mmsystem.h>
#include <assert.h>
#include <tchar.h>

using namespace Gdiplus;

#define ULW_ALPHA               0x00000002
#define WS_EX_LAYERED           0x00080000

#define METERTIMER 1
#define STATSTIMER 2

#define SNAPDISTANCE 10

GlobalConfig CMeterWindow::c_GlobalConfig;

/* 
** CMeterWindow
**
** Constructor
**
*/
CMeterWindow::CMeterWindow()
{
	m_Background = NULL;
	m_DoubleBuffer = NULL;
	m_Window = NULL;
	m_Instance = NULL;

	m_WindowX = 0;
	m_WindowY = 0;
	m_WindowW = 0;
	m_WindowH = 0;
	m_WindowZPosition = ZPOSITION_NORMAL;
	m_WindowDraggable = false;
	m_WindowUpdate = 1000;
	m_WindowHide = false;
	m_Hidden = false;
	m_WindowStartHidden = false;
	m_SnapEdges = true;
	m_Rainmeter = NULL;
	m_ResetRegion = false;
	m_Refreshing = false;
	m_NativeTransparency = true;
	m_MeasuresToVariables = false;
	m_AllowNegativeCoordinates = false;
	m_SavePosition = false;

	m_BackgroundMode = BGMODE_IMAGE;
	m_SolidBevel = BEVELTYPE_NONE;

	c_GlobalConfig.netInSpeed = 0;
	c_GlobalConfig.netOutSpeed = 0;

	// Set the stats-date string
	struct tm *newtime;
    time_t long_time;
    time(&long_time);
    newtime = localtime(&long_time);
	m_StatsDate = asctime(newtime);
	m_StatsDate.resize(m_StatsDate.size() - 1);

    // Initialize GDI+.
    GdiplusStartupInput gdiplusStartupInput;
    GdiplusStartup(&m_GDIplusToken, &gdiplusStartupInput, NULL);

	m_User32Library = LoadLibrary("user32.dll");
}

/* 
** ~CMeterWindow
**
** Destructor
**
*/
CMeterWindow::~CMeterWindow()
{
	WriteStats();
	WriteConfig(m_CurrentConfig);

	// Destroy the measures
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		delete (*i);
	}

	// Destroy the meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		delete (*j);
	}

	if(m_Background) delete m_Background;
	if(m_DoubleBuffer) delete m_DoubleBuffer;

	GdiplusShutdown(m_GDIplusToken);

	if(m_Window) DestroyWindow(m_Window);

	BOOL Result;
	int counter = 0;
	do {
		// Wait for the window to die
		Result = UnregisterClass("RainmeterMeterWindow", m_Instance);
		Sleep(100);
		counter += 1;
	} while(!Result && counter < 10);

	FreeLibrary(m_User32Library);
}

/* 
** Initialize
**
** Initializes the window, creates the class and the window.
**
*/
int CMeterWindow::Initialize(CRainmeter& Rainmeter, HWND Parent, HINSTANCE Instance)
{
	int flags;
	WNDCLASSEX wc;

	if(Parent==NULL || Instance==NULL) 
	{
		throw CError(CError::ERROR_NULL_PARAMETER, __LINE__, __FILE__);
	}

	m_Instance = Instance;
	m_Rainmeter = &Rainmeter;

	// Register the windowclass
	memset(&wc, 0, sizeof(WNDCLASSEX));
	wc.style = CS_NOCLOSE;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.lpfnWndProc = WndProc;
	wc.hInstance = Instance;
	wc.lpszClassName = "RainmeterMeterWindow";
	
	if(!RegisterClassEx(&wc))
	{
		throw CError(CError::ERROR_REGISTER_WINDOWCLASS, __LINE__, __FILE__);
	}

	if(Rainmeter.IsWharfData())
	{
		// If we're in lsBox or in wharf, this is a childwindow
		flags = WS_CHILD;
	}
	else
	{
		// ... otherwise this is normal popup window
		flags = WS_POPUP;
		Parent = NULL;
	}

	m_Window = CreateWindowEx(WS_EX_TOOLWINDOW,
							"RainmeterMeterWindow", 
							NULL, 
							flags,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							Parent,
							NULL,
							Instance,
							this);

	if(m_Window == NULL) 
	{ 
		throw CError(CError::ERROR_CREATE_WINDOW, __LINE__, __FILE__);
	}

	SetWindowLong(m_Window, GWL_USERDATA, magicDWord);

	Refresh(true);

	LSLog(LOG_DEBUG, "Rainmeter", "Initialization successful.");

	return 0;
}

/*
** Refresh
**
** This deletes everyting and rebuilds the config again.
**
*/
void CMeterWindow::Refresh(bool init, const std::string configName, const std::string configIniFile)
{
	assert(m_Rainmeter != NULL);

	std::string dbg = "Refreshing (Name: " + configName;
	dbg += " �ni: " + configIniFile; 
	dbg += ")"; 
	LSLog(LOG_DEBUG, "Rainmeter", dbg.c_str());
	
	m_Refreshing = true;

	if(!init)
	{
		// First destroy everything

		WriteStats();
		WriteConfig(m_CurrentConfig);

		ShowWindow(m_Window, SW_HIDE);
		
		KillTimer(m_Window, METERTIMER);	// Kill the timer
		KillTimer(m_Window, STATSTIMER);	// Kill the timer

		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			delete (*i);
		}
		m_Measures.clear();

		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			delete (*j);
		}
		m_Meters.clear();

		if(m_Background) delete m_Background;
		m_Background = NULL;
		if(m_DoubleBuffer) delete m_DoubleBuffer;
		m_DoubleBuffer = NULL;

		m_BackgroundName.erase();
	}

	// Load the config and recreate everything
	GetCurrentConfig(m_Rainmeter->GetCommandLine());
	ReadConfig(m_CurrentConfig, true);
	SelectConfig(configName, configIniFile);
	ReadConfig(m_SkinPath + m_SkinName + "\\" + m_SkinIniFile, false);	// Read the overridden values from the skin's ini file

	char currentDir[MAX_LINE_LENGTH];
	GetCurrentDirectory(MAX_LINE_LENGTH, currentDir);

	// Set the current directory so that the graphics can be found
	std::string iniPath = m_SkinPath + m_SkinName;
	SetCurrentDirectory(iniPath.c_str());

	ReadSkin(m_SkinPath + m_SkinName + "\\" + m_SkinIniFile);
	InitializeMeters();

	// Make the current folder like it was before so that we don't break anything
	SetCurrentDirectory(currentDir);

	ChangeZPos(m_WindowZPosition);

	UINT flags;
	if(m_WindowStartHidden && init)
	{
		flags = 0;
	}
	else
	{
		flags = SWP_NOACTIVATE | SWP_SHOWWINDOW;
	}

	flags |= SWP_NOZORDER;

	SetWindowPos(m_Window, NULL, m_WindowX, m_WindowY, m_WindowW, m_WindowH, flags);

	// Set the window region
	CreateRegion(true);	// Clear the region
	Update();
	CreateRegion(false);

	// Start the timers
	if(0 == SetTimer(m_Window, METERTIMER, m_WindowUpdate, NULL) ||
	   0 == SetTimer(m_Window, STATSTIMER, 60000, NULL))	// Stats are written once per minute
	{
		throw CError("Unable to create a timer!", __LINE__, __FILE__);
	}

	ReadStats();

	// Write the current settings
	WriteConfig(m_CurrentConfig);

	UpdateTransparency(true);

	m_Refreshing = false;
}

/*
** MoveWindow
**
** Moves the window to a new place
**
*/
void CMeterWindow::MoveWindow(int x, int y)
{
	if (!m_AllowNegativeCoordinates)
	{
		RECT r;
		GetClientRect(GetDesktopWindow(), &r); 
		if(x < 0) x += r.right;
		if(y < 0) y += r.bottom;
	}

	SetWindowPos(m_Window, NULL, x, y, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
}

/*
** ChangeZPos
**
** Sets the window's z-position
**
*/
void CMeterWindow::ChangeZPos(ZPOSITION zPos)
{
	if(!m_Rainmeter->IsWharfData())
	{
		HWND winPos;
		m_WindowZPosition = zPos;

		switch (zPos)
		{
		case ZPOSITION_ONTOP:
			winPos = HWND_TOPMOST;
 			break;

		case ZPOSITION_ONBOTTOM:
			 winPos = HWND_BOTTOM;
			 break;

		default:
			winPos = HWND_NOTOPMOST;
		}

		SetWindowPos(m_Window, winPos, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	}
}

/*
** Hide
**
** Hides the window
**
*/
void CMeterWindow::Hide()
{
	if(m_Window) ShowWindow(m_Window, SW_HIDE);
}

/*
** Show
**
** Shows the window
**
*/
void CMeterWindow::Show()
{
	if(m_Window) ShowWindow(m_Window, SW_SHOWNOACTIVATE);
}

/*
** Toggle
**
** Toggle the window
**
*/
void CMeterWindow::Toggle()
{
	if(m_Window && IsWindowVisible(m_Window)) 
	{
		Hide();
	}
	else
	{
		Show();
	}
}

/*
** ShowMeter
**
** Shows the given meter
**
*/
void CMeterWindow::ShowMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->Show();
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** HideMeter
**
** Hides the given meter
**
*/
void CMeterWindow::HideMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			(*j)->Hide();
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}

/*
** ToggleMeter
**
** Toggles the given meter
**
*/
void CMeterWindow::ToggleMeter(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		if (strcmp((*j)->GetName(), name) == 0)
		{
			if ((*j)->IsHidden())
			{
				(*j)->Show();
			}
			else
			{
				(*j)->Hide();
			}
			m_ResetRegion = true;	// Need to recalculate the windowregion
			return;
		}
	}

	std::string error = "No such meter: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** EnableMeasure
**
** Enables the given measure
**
*/
void CMeterWindow::EnableMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			(*i)->Enable();
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** DisableMeasure
**
** Disables the given measure
**
*/
void CMeterWindow::DisableMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			(*i)->Disable();
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** ToggleMeasure
**
** Toggless the given measure
**
*/
void CMeterWindow::ToggleMeasure(const char* name)
{
	if (name == NULL || strlen(name) == 0) return;

	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		if (strcmp((*i)->GetName(), name) == 0)
		{
			if ((*i)->IsDisabled())
			{
				(*i)->Enable();
			}
			else
			{
				(*i)->Disable();
			}
			return;
		}
	}

	std::string error = "No such measure: ";
	error += name;
	MessageBox(m_Window, error.c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
}


/*
** ReadStats
**
** Reads the statistics from the registry
**
*/
void CMeterWindow::ReadStats()
{
	char tmpSz[MAX_LINE_LENGTH];

	if(GetPrivateProfileString( "Statistics", "Since", "", tmpSz, MAX_LINE_LENGTH, m_CurrentConfig.c_str()) > 0) 
	{
 		m_StatsDate = tmpSz;
	}

	// Read other stats
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		try 
		{
			(*i)->ReadStats(m_CurrentConfig);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	std::string dbg = "Read stats from: " + m_CurrentConfig;
	LSLog(LOG_DEBUG, "Rainmeter", dbg.c_str());
}

/*
** WriteStats
**
** Writes the statistics to the ini-file
**
*/
void CMeterWindow::WriteStats()
{
	// Write the date for statistics
	WritePrivateProfileString("Statistics", "Since", m_StatsDate.c_str(), m_CurrentConfig.c_str());

	// Write the other stats
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		try 
		{
			(*i)->WriteStats(m_CurrentConfig);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	std::string dbg = "Wrote stats to: " + m_CurrentConfig;
	LSLog(LOG_DEBUG, "Rainmeter", dbg.c_str());
}

/*
** GetCurrentConfig
**
** Finds out the name of the current skin & config file
**
*/
void CMeterWindow::GetCurrentConfig(LPCSTR cmdLine)
{
	char iniFile[MAX_LINE_LENGTH];
	char skinPath[MAX_LINE_LENGTH];

	// Check the command line for config file
	if(cmdLine == NULL || cmdLine[0]=='\0') 
	{
		iniFile[0] = 0;

		if(!m_Rainmeter->GetDummyLitestep()) 
		{
			GetRCString("RainmeterIniFile", iniFile, "", MAX_LINE_LENGTH - 1);
		}

		if(strlen(iniFile) == 0)
		{
			// No arguments, so we'll try to use the DLL's directory
			GetModuleFileName(GetModuleHandle("Rainmeter.dll"), iniFile, MAX_LINE_LENGTH);

			// Remove the module's name from the path
			char* pos = strrchr(iniFile, '\\');
			if(pos) 
			{
				*(pos + 1)='\0';
			} 
			else 
			{
				iniFile[0]='\0';
			}
		}
	} 
	else 
	{
		strncpy(iniFile, cmdLine, MAX_LINE_LENGTH);
		iniFile[MAX_LINE_LENGTH - 1] = '\0';
	}

	// Make sure that the path has a ini file attached
	if (strlen(iniFile) < 4 || stricmp(iniFile + strlen(iniFile) - 4, ".ini") != 0)
	{
		if (iniFile[strlen(iniFile) - 1] != '\\')
		{
			strcat(iniFile, "\\");
		}
		strcat(iniFile, "Rainmeter.ini");
	}

	// Get the skins path
	skinPath[0] = 0;

	if(!m_Rainmeter->GetDummyLitestep()) 
	{
		GetRCString("RainmeterSkinPath", skinPath, "", MAX_LINE_LENGTH - 1);
	}

	if(strlen(skinPath) == 0)
	{
		// No arguments, so we'll try to use the DLL's directory
		GetModuleFileName(GetModuleHandle("Rainmeter.dll"), skinPath, MAX_LINE_LENGTH);

		// Remove the module's name from the path
		char* pos = strrchr(skinPath, '\\');
		if(pos) 
		{
			*(pos + 1)='\0';
		} 
		else 
		{
			skinPath[0]='\0';
		}
		strcat(skinPath, "Skins\\");
	}
	else
	{
		if (skinPath[strlen(skinPath)] != '\\')
		{
			strcat(skinPath, "\\");
		}
	}
	m_SkinPath = skinPath;

	// The iniFile is an actual Rainmeter.ini-file
	m_CurrentConfig = iniFile;
}

void CMeterWindow::SelectConfig(const std::string& configName, const std::string& configIniFile)
{
	// Read the folder and fill the configs to the context menu
	GetSkinFolders(m_SkinPath.c_str());

	if(m_ConfigStrings.empty())
	{
		throw CError(std::string("There are no skins available in folder ") + m_SkinPath.c_str(), __LINE__, __FILE__);
	}

	// Check if the config name was given as parameter
	if(!configName.empty())
	{
		if (!configIniFile.empty())
		{
			m_SkinIniFile = configIniFile;
		}
		else
		{
			m_SkinIniFile = "Rainmeter.ini";
		}

		// Switch to the desired config
		m_SkinName = configName;
	}
	else
	{
		if(m_SkinName.empty())
		{
			m_SkinName = m_ConfigStrings[0].path;
			m_SkinIniFile = m_ConfigStrings[0].iniFiles[0];
		} 
		else
		{
			// Check that the config exists
			std::vector<CONFIG>::iterator i = m_ConfigStrings.begin();
			for(; i != m_ConfigStrings.end(); i++)
			{
				if ((*i).path == m_SkinName) 
				{
					std::vector<std::string>::iterator j = (*i).iniFiles.begin();
					for(; j != (*i).iniFiles.end(); j++)
					{
						if ((*j) == m_SkinIniFile) break; 
					}

					if(j == (*i).iniFiles.end()) 
					{
						m_SkinIniFile = (*i).iniFiles[0];	// Use the first ini file
					}

					break;	// Found match
				}
			}

			if(i == m_ConfigStrings.end()) 
			{
				m_SkinName = m_ConfigStrings[0].path;	// No match, use the first as default
				m_SkinIniFile = m_ConfigStrings[0].iniFiles[0];
			}
		}
	}
}

/*
** GetSkinFolders
**
** Scans all the subfolders and locates the ini-files.
**
*/
void CMeterWindow::GetSkinFolders(const std::string& folder)
{
    WIN32_FIND_DATA fileData;      // Data structure describes the file found
    WIN32_FIND_DATA fileDataIni;   // Data structure describes the file found
    HANDLE hSearch;                // Search handle returned by FindFirstFile
    HANDLE hSearchIni;             // Search handle returned by FindFirstFile

	m_ConfigStrings.clear();

    // Start searching for .ini files in the given directory.
	std::string files = folder + "*";
    hSearch = FindFirstFile(files.c_str(), &fileData);
	do
	{
		if(hSearch == INVALID_HANDLE_VALUE) break;    // No more files found

		if(fileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY && 
			strcmp(".", fileData.cFileName) != 0 &&
			strcmp("..", fileData.cFileName) != 0)
		{
			CONFIG config;
			config.path = fileData.cFileName;

			// Scan all .ini files from the subfolder
			std::string inis = folder;
			inis += fileData.cFileName;
			inis += "\\*.ini";
			hSearchIni = FindFirstFile(inis.c_str(), &fileDataIni);

			do
			{
				if(hSearchIni == INVALID_HANDLE_VALUE) break;    // No more files found
				config.iniFiles.push_back(fileDataIni.cFileName);

			} while (FindNextFile(hSearchIni, &fileDataIni));

			if (!config.iniFiles.empty())
			{
				m_ConfigStrings.push_back(config);
			}
		    FindClose(hSearchIni);
		}
	} while(FindNextFile(hSearch, &fileData));

    FindClose(hSearch);
}

/*
** ReadConfig
**
** Reads the current config
**
*/
void CMeterWindow::ReadConfig(const std::string& iniFile, bool generalConfig)
{
	char tmpSz[MAX_LINE_LENGTH];

	m_WindowX = GetPrivateProfileInt( "Rainmeter", "WindowX", m_WindowX, iniFile.c_str());
	m_WindowY = GetPrivateProfileInt( "Rainmeter", "WindowY", m_WindowY, iniFile.c_str());
	if(m_WindowX != 0 || m_WindowY != 0)
	{
		// TODO: check that pt is somewhere on screen
	}

	int zPos = GetPrivateProfileInt( "Rainmeter", "AlwaysOnTop", m_WindowZPosition, iniFile.c_str());
	if (zPos == -1)
	{
		m_WindowZPosition = ZPOSITION_ONBOTTOM;
	}
	else if (zPos == 1)
	{
		m_WindowZPosition = ZPOSITION_ONTOP;
	}
	else
	{
		m_WindowZPosition = ZPOSITION_NORMAL;
	}

	m_WindowDraggable = 0!=GetPrivateProfileInt( "Rainmeter", "Draggable", m_WindowDraggable, iniFile.c_str());
	m_WindowUpdate = GetPrivateProfileInt( "Rainmeter", "Update", m_WindowUpdate, iniFile.c_str());
	m_WindowHide = 0!=GetPrivateProfileInt( "Rainmeter", "HideOnMouseOver", m_WindowHide, iniFile.c_str());
	m_WindowStartHidden = 0!=GetPrivateProfileInt( "Rainmeter", "StartHidden", m_WindowStartHidden, iniFile.c_str());
	m_SavePosition = 0!=GetPrivateProfileInt( "Rainmeter", "SavePosition", m_SavePosition, iniFile.c_str());
	m_SnapEdges = 0!=GetPrivateProfileInt( "Rainmeter", "SnapEdges", m_SnapEdges, iniFile.c_str());
	m_MeasuresToVariables = 0!=GetPrivateProfileInt( "Rainmeter", "MeasuresToVariables", m_MeasuresToVariables, iniFile.c_str());
	m_AllowNegativeCoordinates = 0!=GetPrivateProfileInt( "Rainmeter", "AllowNegativeCoordinates", m_AllowNegativeCoordinates, iniFile.c_str());

	m_NativeTransparency = 0!=GetPrivateProfileInt( "Rainmeter", "NativeTransparency", m_NativeTransparency, iniFile.c_str());
	
	// Disable native transparency if not 2K/XP
	if(IsNT() == PLATFORM_9X || IsNT() ==PLATFORM_NT4)
	{
		m_NativeTransparency = 0;
	}

	c_GlobalConfig.netInSpeed = GetPrivateProfileInt( "Rainmeter", "NetInSpeed", c_GlobalConfig.netInSpeed, iniFile.c_str());
	c_GlobalConfig.netOutSpeed = GetPrivateProfileInt( "Rainmeter", "NetOutSpeed", c_GlobalConfig.netOutSpeed, iniFile.c_str());

	if (generalConfig)
	{
		if(GetPrivateProfileString( "Rainmeter", "CurrentConfig", "", tmpSz, 255, iniFile.c_str()) > 0) 
		{
 			m_SkinName = tmpSz;
		}
		if(GetPrivateProfileString( "Rainmeter", "CurrentConfigIni", "", tmpSz, 255, iniFile.c_str()) > 0) 
		{
 			m_SkinIniFile = tmpSz;
		}

		// Check if step.rc has overrides these values
		if(!m_Rainmeter->GetDummyLitestep()) 
		{
			GetRCString("RainmeterCurrentConfig", tmpSz, m_SkinName.c_str(), MAX_LINE_LENGTH - 1);
			m_SkinName = tmpSz;

			GetRCString("RainmeterCurrentConfigIni", tmpSz, m_SkinIniFile.c_str(), MAX_LINE_LENGTH - 1);
			m_SkinIniFile = tmpSz;
		}
	}
}

/*
** ReadSkin
**
** Reads the skin config, creates the meters and measures and does the bindings.
**
*/
void CMeterWindow::ReadSkin(const std::string& iniFile)
{
	char tmpSz[MAX_LINE_LENGTH];
	char buffer[MAX_LINE_LENGTH];

	if(iniFile.empty())
	{
        throw CError("Failed to read the configuration file.", __LINE__, __FILE__);
	}

	// Global settings
	if(GetPrivateProfileString( "Rainmeter", "Background", "", tmpSz, 255, iniFile.c_str()) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_BackgroundName = tmpSz;
	}

	m_BackgroundMode = (BGMODE)GetPrivateProfileInt( "Rainmeter", "BackgroundMode", 0, iniFile.c_str());
	m_SolidBevel = (BEVELTYPE)GetPrivateProfileInt( "Rainmeter", "BevelType", m_SolidBevel, iniFile.c_str());
	if(GetPrivateProfileString("Rainmeter", "SolidColor", "128, 128, 128", tmpSz, 255, iniFile.c_str()) > 0) 
	{
		m_SolidColor = CMeter::ParseColor(tmpSz);
	}

	if (m_BackgroundMode == BGMODE_IMAGE && m_BackgroundName.empty())
	{
		m_BackgroundMode = BGMODE_COPY;
	}

	if(GetPrivateProfileString( "Rainmeter", "RightMouseDownAction", "", tmpSz, MAX_LINE_LENGTH, iniFile.c_str()) > 0) 
	{
 		m_RightMouseDownAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "LeftMouseDownAction", "", tmpSz, MAX_LINE_LENGTH, iniFile.c_str()) > 0) 
	{
 		m_LeftMouseDownAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "RightMouseUpAction", "", tmpSz, MAX_LINE_LENGTH, iniFile.c_str()) > 0) 
	{
 		m_RightMouseUpAction = tmpSz;
	}

	if(GetPrivateProfileString( "Rainmeter", "LeftMouseUpAction", "", tmpSz, MAX_LINE_LENGTH, iniFile.c_str()) > 0) 
	{
 		m_LeftMouseUpAction = tmpSz;
	}

	// Create the meters and measures

	// Get all the sections (i.e. different meters)
	GetPrivateProfileString( NULL, NULL, NULL, buffer, MAX_LINE_LENGTH, iniFile.c_str());
	char* pos = buffer;
	while(strlen(pos) > 0)
	{
		if(strcmp("Rainmeter", pos) != 0)
		{
			// Check if the item is a meter or a measure (or perhaps something else)
			if(GetPrivateProfileString(pos, "Measure", "", tmpSz, 255, iniFile.c_str()) > 0)
			{
				try
				{
					// It's a measure
					CMeasure* measure = CMeasure::Create(tmpSz);
					measure->SetName(pos);
					measure->ReadConfig(iniFile.c_str(), pos);
					m_Measures.push_back(measure);
				}
				catch (CError& error)
				{
					MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
				}
			} 
			else if(GetPrivateProfileString(pos, "Meter", "", tmpSz, 255, iniFile.c_str()) > 0)
			{
				try
				{
					// It's a meter
					CMeter* meter = CMeter::Create(tmpSz);
					meter->SetName(pos);
					meter->ReadConfig(iniFile.c_str(), pos);
					m_Meters.push_back(meter);
				}
				catch (CError& error)
				{
					MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
				}
			} 
			else
			{
				// It's something else
                throw CError(std::string("Section [") + pos + "] is not a meter or a measure!", __LINE__, __FILE__);
            }
		}
		pos = pos + strlen(pos) + 1;
	}

	if (m_Meters.empty())
	{
		MessageBox(m_Window, "Your configuration file doesn't contain any meters!\nYour skin's ini-file might be out of date.", APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}
	else
	{
		// Bind the meters to the measures
		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			try
			{
				(*j)->BindMeasure(m_Measures);
			}
			catch (CError& error)
			{
				MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
			}
		}
	}
}

/*
** WriteConfig
**
** Writes the new settings to the config
**
*/
void CMeterWindow::WriteConfig(const std::string& iniFile)
{
	char buffer[256];

	if(!iniFile.empty())
	{
		// If position news to be save, do so.
		if(m_SavePosition)
		{
			int x = m_WindowX, y = m_WindowY;
			if (!m_AllowNegativeCoordinates)
			{
				x = max(0, x);
				y = max(0, y);
			}

			sprintf(buffer, "%i", x);
			WritePrivateProfileString("Rainmeter", "WindowX", buffer, iniFile.c_str());
			sprintf(buffer, "%i", y);
			WritePrivateProfileString("Rainmeter", "WindowY", buffer, iniFile.c_str());
		}
		// Write the current config
		WritePrivateProfileString("Rainmeter", "CurrentConfig", m_SkinName.c_str(), iniFile.c_str());
		WritePrivateProfileString("Rainmeter", "CurrentConfigIni", m_SkinIniFile.c_str(), iniFile.c_str());
	}
}

/*
** InitializeMeters
**
** Initializes all the meters and the background
**
*/
void CMeterWindow::InitializeMeters()
{
	// Initalize all meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Initialize(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	// Handle negative coordinates
	if (!m_AllowNegativeCoordinates)
	{
		RECT r;
		GetClientRect(GetDesktopWindow(), &r); 
		if(m_WindowX < 0) m_WindowX += r.right;
		if(m_WindowY < 0) m_WindowY += r.bottom;
	}

	// Reset size (this is calculated below)
	m_WindowW = 0;
	m_WindowH = 0;

	if (m_BackgroundMode == BGMODE_IMAGE && !m_BackgroundName.empty())
	{
		// Load the background
		WCHAR* wideSz = CMeter::ConvertToWide(m_BackgroundName.c_str());
		m_Background = new Bitmap(wideSz);
		delete [] wideSz;

		Status status = m_Background->GetLastStatus();
		if(Ok != status)
		{
			throw CError(std::string("Unable to load background: ") + m_BackgroundName, __LINE__, __FILE__);
		}

		// Calculate the window dimensions
		if(m_Background)
		{
			// Get the size form the background bitmap
			m_WindowW = m_Background->GetWidth();
			m_WindowH = m_Background->GetHeight();

			if (!m_NativeTransparency)
			{
				// Graph the desktop and place the background on top of it
				Bitmap* desktop = GrabDesktop(m_WindowX, m_WindowY, m_WindowW, m_WindowH);
				Graphics graphics(desktop);
				Rect r(0, 0, m_WindowW, m_WindowH);
				graphics.DrawImage(m_Background, r, 0, 0, m_WindowW, m_WindowH, UnitPixel);
				delete m_Background;
				m_Background = desktop;
			}
		} 
	} 
	else
	{
		// No background -> Get the largest meter point
		std::list<CMeter*>::iterator j = m_Meters.begin();
		for( ; j != m_Meters.end(); j++)
		{
			m_WindowW = max(m_WindowW, (*j)->GetX() + (*j)->GetW());
			m_WindowH = max(m_WindowH, (*j)->GetY() + (*j)->GetH());
		}
	}

	if(m_WindowW == 0 || m_WindowH == 0)
	{
		throw CError("The window's dimensions are zero.", __LINE__, __FILE__);
	}

	// Create the double buffer (32 bit)
	m_DoubleBuffer = new Bitmap(m_WindowW, m_WindowH, PixelFormat32bppARGB);

	// If Background is not set, take a copy from the desktop
	if(m_Background == NULL) 
	{
		if (m_BackgroundMode == BGMODE_COPY)
		{
			if (m_NativeTransparency)
			{
				// Create a transparent background
				m_Background = new Bitmap(m_WindowW, m_WindowH, PixelFormat32bppARGB);
				Graphics graphics(m_Background);
				graphics.Clear(Color(0, 0, 0, 0));
			}
			else
			{
				m_Background = GrabDesktop(m_WindowX, m_WindowY, m_WindowW, m_WindowH);
			}
		}
		else
		{
			// Create a solid color bitmap for the background
			m_Background = new Bitmap(m_WindowW, m_WindowH, PixelFormat32bppARGB);
			Graphics graphics(m_Background);
			graphics.Clear(m_SolidColor);

			if (m_SolidBevel != BEVELTYPE_NONE)
			{
				Pen light(Color(255, 255, 255, 255));
				Pen dark(Color(255, 0, 0, 0));

				if (m_SolidBevel == BEVELTYPE_DOWN)
				{
					light.SetColor(Color(255, 0, 0, 0));
					dark.SetColor(Color(255, 255, 255, 255));
				}
				Rect rect(0, 0, m_WindowW, m_WindowH);	
				CMeter::DrawBevel(graphics, rect, light, dark);
			}
		}
	}
}

/*
** GrabDesktop
** 
** Grabs a part of the desktop
*/
Bitmap* CMeterWindow::GrabDesktop(int x, int y, int w, int h)
{
	// If the new way fails, use the old way
	HDC winDC = GetWindowDC(GetDesktopWindow());
	HDC tmpDC = CreateCompatibleDC(winDC);

	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = x;
	bmi.bmiHeader.biHeight = y;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;         // four 8-bit components
	bmi.bmiHeader.biCompression = BI_RGB;
	bmi.bmiHeader.biSizeImage = w * h * 4;
	
	// create our DIB section and select the bitmap into the dc
	VOID* bits;
	HBITMAP wallpaper = CreateDIBSection(winDC, &bmi, DIB_RGB_COLORS, &bits, NULL, 0x0);

	// Fetch the background
	HBITMAP OldBitmap = (HBITMAP)SelectObject(tmpDC, wallpaper);
	BitBlt(tmpDC, 0, 0, w, h, winDC, x, y, SRCCOPY);
	
	ReleaseDC(GetDesktopWindow(), winDC);

	SelectObject(tmpDC, OldBitmap);
	DeleteDC(tmpDC);

	Bitmap* tmpBitmap = new Bitmap(wallpaper, NULL);
	Bitmap* background = new Bitmap(w, h, PixelFormat32bppARGB);
	Graphics graphics(background);
	Rect r(0, 0, w, h);
	graphics.DrawImage(tmpBitmap, r, 0, 0, w, h, UnitPixel);
	delete tmpBitmap;
	DeleteObject(wallpaper);

	return background;
}

/*
** CreateRegion
**
** Creates/Clears a window region
**
*/
void CMeterWindow::CreateRegion(bool clear)
{
	if (clear)
	{
		SetWindowRgn(m_Window, NULL, TRUE);
	}
	else
	{
		// Set window region if needed
		if(!m_BackgroundName.empty()) 
		{
			HBITMAP bitmap;
			m_DoubleBuffer->GetHBITMAP(Color(255, 255, 255, 255), &bitmap);
			HRGN region = BitmapToRegion(bitmap, RGB(255,0,255), 0x101010, 0, 0);
			SetWindowRgn(m_Window, region, TRUE);
			DeleteObject(bitmap);
		}
	}
}

/*
** Redraw
**
** Redraws the window
**
*/
void CMeterWindow::Redraw() 
{
	if (m_ResetRegion) CreateRegion(true);
	Update();
	if (m_ResetRegion) CreateRegion(false);
	m_ResetRegion = false;

	UpdateTransparency(false);

	// Just blit the doublebuffer to the window
	HDC winDC = GetWindowDC(m_Window);
	Graphics graphics(winDC);
	graphics.DrawImage(m_DoubleBuffer, 0, 0);
	ReleaseDC(m_Window, winDC);
}

/*
** Update
**
** Updates all the measures and redraws the meters
**
*/
void CMeterWindow::Update()
{
	Graphics graphics(m_DoubleBuffer);
	graphics.SetCompositingMode(CompositingModeSourceCopy);
	// Copy the background over the doublebuffer
	Rect r(0, 0, m_WindowW, m_WindowH);
	graphics.DrawImage(m_Background, r, 0, 0, m_WindowW, m_WindowH, UnitPixel);

	// Update all measures
	std::list<CMeasure*>::iterator i = m_Measures.begin();
	for( ; i != m_Measures.end(); i++)
	{
		try
		{
			(*i)->Update(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	// Draw the meters
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		try
		{
			(*j)->Draw(*this);
		}
		catch (CError& error)
		{
			MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
		}
	}

	if (m_MeasuresToVariables)	// BUG: LSSetVariable doens't seem to work here for some reason.
	{
		std::list<CMeasure*>::iterator i = m_Measures.begin();
		for( ; i != m_Measures.end(); i++)
		{
			const char* sz = (*i)->GetStringValue(true, 1, 1, false);
			if (sz && strlen(sz) > 0)
			{
				WCHAR* wideSz = CMeter::ConvertToWide(sz);
				WCHAR* wideName = CMeter::ConvertToWide((*i)->GetName());
				LSSetVariable(wideName, wideSz);
				delete [] wideSz;
				delete [] wideName;
			}
		}
	
	}
}

/*
** UpdateTransparency
**
** Updates the native Windows transparency
*/
void CMeterWindow::UpdateTransparency(bool reset)
{
	if (m_NativeTransparency)
	{
		if (reset)
		{
			// Add the window flag
			LONG style = GetWindowLong(m_Window, GWL_EXSTYLE);
			SetWindowLong(m_Window, GWL_EXSTYLE, style | WS_EX_LAYERED);
		}

		RECT r;
		GetWindowRect(m_Window, &r);

		typedef BOOL (WINAPI * FPUPDATELAYEREDWINDOW)(HWND hWnd, HDC hdcDst, POINT *pptDst, SIZE *psize, HDC hdcSrc, POINT *pptSrc, COLORREF crKey, BLENDFUNCTION *pblend, DWORD dwFlags);
		FPUPDATELAYEREDWINDOW UpdateLayeredWindow = (FPUPDATELAYEREDWINDOW)GetProcAddress(m_User32Library, "UpdateLayeredWindow");

		BLENDFUNCTION blendPixelFunction= {AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
		POINT ptWindowScreenPosition = {r.left, r.top};
		POINT ptSrc = {0, 0};
		SIZE szWindow = {m_WindowW, m_WindowH};
		
		HDC dcScreen = GetDC(GetDesktopWindow());
		HDC dcMemory = CreateCompatibleDC(dcScreen);

		HBITMAP dbBitmap;
		m_DoubleBuffer->GetHBITMAP(Color(0, 0, 0, 0), &dbBitmap);
		HBITMAP oldBitmap = (HBITMAP)SelectObject(dcMemory, dbBitmap);
		UpdateLayeredWindow(m_Window, dcScreen, &ptWindowScreenPosition, &szWindow, dcMemory, &ptSrc, 0, &blendPixelFunction, ULW_ALPHA);
		ReleaseDC(GetDesktopWindow(), dcScreen);
		SelectObject(dcMemory, oldBitmap);
		DeleteDC(dcMemory);
		DeleteObject(dbBitmap);
	}
	else
	{
		if (reset)
		{
			// Remove the window flag
			LONG style = GetWindowLong(m_Window, GWL_EXSTYLE);
			SetWindowLong(m_Window, GWL_EXSTYLE, style & ~WS_EX_LAYERED);
		}
	}
}

/*
** OnPaint
**
** Repaints the window. This does not cause update of the measures.
**
*/
LRESULT CMeterWindow::OnPaint(WPARAM wParam, LPARAM lParam) 
{
	PAINTSTRUCT ps;
	HDC winDC = BeginPaint(m_Window, &ps);

	Graphics graphics(winDC);
	graphics.DrawImage(m_DoubleBuffer, 0, 0);

	EndPaint(m_Window, &ps);
	return 0;
}

/*
** OnTimer
**
** Handles the timers. The METERTIMER updates all the measures and
** STATSTIMER writes the stats to registry.
**
*/
LRESULT CMeterWindow::OnTimer(WPARAM wParam, LPARAM lParam) 
{
	static int Count=1;

	if(wParam == METERTIMER) 
	{
		UpdateAboutStatistics();

		ShowWindowIfAppropriate();

		Redraw();
	}
	else if(wParam == STATSTIMER)
	{
		WriteStats();
	}

	return 0;
}

/*
** ShowWindowIfAppropriate
**
** Show the window if it is temporarely hidden.
**
*/
void CMeterWindow::ShowWindowIfAppropriate()
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not show the window
			return;
		}

		bool inside = false;
		POINT pos;
		RECT rect;

		GetCursorPos(&pos);
		GetWindowRect(m_Window, &rect);

		if(rect.left <= pos.x && rect.right >= pos.x &&
		   rect.top <= pos.y && rect.bottom >= pos.y) inside = true;

		if(m_Hidden && !inside)
		{
			// Show window
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
			m_Hidden = false;
		}
	}
}

/*
** OnMouseMove
**
** When we get WM_MOUSEMOVE messages, hide the window as the mouse is over it.
**
*/
LRESULT CMeterWindow::OnMouseMove(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not hide the window
			return 0;
		}

		// Hide window if it is visible
		if(IsWindowVisible(m_Window))
		{
			ShowWindow(m_Window, SW_HIDE);
			m_Hidden = true;
		}
	}

	return 0;
}

/*
** OnCreate
**
** During window creation we do nothing.
**
*/
LRESULT CMeterWindow::OnCreate(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/*
** OnCommand
**
** Handle the menu commands.
**
*/
LRESULT CMeterWindow::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	try 
	{
		if(wParam == ID_CONTEXT_ABOUT)
		{
			OpenAboutDialog(m_Window, m_Instance);
		} 
		else if(wParam == ID_CONTEXT_REFRESH)
		{
			Refresh(false);
		} 
		else if(wParam == ID_CONTEXT_QUIT)
		{
			QuitRainmeter();
		}
		else if(wParam >= ID_CONFIG_FIRST)
		{
			// Check which config was selected
			int index = 0;
			
			for (int i = 0; i < m_ConfigStrings.size(); i++)
			{
				for (int j = 0; j < m_ConfigStrings[i].iniFiles.size(); j++)
				{
					if (index == wParam - ID_CONFIG_FIRST)
					{
						Refresh(false, m_ConfigStrings[i].path, m_ConfigStrings[i].iniFiles[j]);
						return 0;
					}
					index++;
				}
			}
		}
	} 
    catch(CError& error) 
    {
		MessageBox(m_Window, error.GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return 0;
}

/*
** QuitRainmeter
**
** Quits Rainmeter and kills the window.
**
*/
void CMeterWindow::QuitRainmeter()
{
	// This doesn't free all allocated memory, but we are quitting anyway so it doesn't matter.

	PostQuitMessage(0);
	quitModule(m_Instance);
}

/*
** OnNcHitTest
**
** This is overwritten so that the window can be dragged
**
*/
LRESULT CMeterWindow::OnNcHitTest(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowDraggable)
	{
		return HTCAPTION;
	}
	return HTCLIENT;
}

/*
** OnWindowPosChanging
**
** Called when windows position is about to change
**
*/
LRESULT CMeterWindow::OnWindowPosChanging(WPARAM wParam, LPARAM lParam) 
{
	LPWINDOWPOS wp=(LPWINDOWPOS)lParam;

	if(m_WindowZPosition == ZPOSITION_ONBOTTOM && !m_Refreshing)
	{
		// do not change the z-order. This keeps the window on bottom.
		wp->flags|=SWP_NOZORDER;
	}

	if (m_SnapEdges && !(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000))
	{
		RECT workArea;
		GetClientRect(GetDesktopWindow(), &workArea);

		// only process movement (ignore anything without winpos values)
		if(wp->cx != 0 && wp->cy != 0)
		{
			typedef HMONITOR (WINAPI * FPMONITORFROMWINDOW)(HWND wnd, DWORD dwFlags);
			typedef BOOL (WINAPI * FPGETMONITORINFO)(HMONITOR hMonitor, LPMONITORINFO lpmi);
			FPMONITORFROMWINDOW fpMonitorFromWindow;
			FPGETMONITORINFO fpGetMonitorInfo;

			HINSTANCE lib = LoadLibrary("user32.dll");
			
			fpMonitorFromWindow = (FPMONITORFROMWINDOW)GetProcAddress(lib, "MonitorFromWindow");
			fpGetMonitorInfo = (FPGETMONITORINFO)GetProcAddress(lib, "GetMonitorInfoA");

			if (fpMonitorFromWindow && fpGetMonitorInfo)
			{
				HMONITOR hMonitor;
				MONITORINFO mi;

				hMonitor = fpMonitorFromWindow(m_Window, MONITOR_DEFAULTTONULL);

				if(hMonitor != NULL)
				{
					mi.cbSize = sizeof(mi);
					fpGetMonitorInfo(hMonitor, &mi);
					workArea = mi.rcWork;
				}
			}

			FreeLibrary(lib);

			int w = workArea.right - m_WindowW;
			int h = workArea.bottom - m_WindowH;

			if((wp->x < SNAPDISTANCE + workArea.left) && (wp->x > workArea.left - SNAPDISTANCE)) wp->x = workArea.left;
			if((wp->y < SNAPDISTANCE + workArea.top) && (wp->y > workArea.top - SNAPDISTANCE)) wp->y = workArea.top;
			if ((wp->x < SNAPDISTANCE + w) && (wp->x > -SNAPDISTANCE + w)) wp->x = w;
			if ((wp->y < SNAPDISTANCE + h) && (wp->y > -SNAPDISTANCE + h)) wp->y = h;
		}
	}

	return DefWindowProc(m_Window, m_Message, wParam, lParam);
}

/*
** OnDestroy
**
** During destruction of the window do nothing.
**
*/
LRESULT CMeterWindow::OnDestroy(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/*
** OnGetRevID
**
** Litestep revision control. This string is shown in the Litestep's about box.
** Not rcs-style but who cares
**
*/
LRESULT CMeterWindow::OnGetRevID(WPARAM wParam, LPARAM lParam) 
{
	char* Buffer=(char*)lParam;

	if(Buffer != NULL)
	{
		if(wParam==0) 
		{
			sprintf(Buffer, "Rainmeter.dll: %s", APPVERSION);
		} 
		else if(wParam==1) 
		{
			sprintf(Buffer, "Rainmeter.dll: %s %s, Rainy", APPVERSION, __DATE__);
		} 
		else
		{
			Buffer[0] = 0;
		}

		return strlen(Buffer);
	}

	return 0;
}

/*
** ExecuteCommand
**
** Runs the given command or bang
**
*/
void CMeterWindow::ExecuteCommand(const char* command) 
{
	if (command == NULL) return;

	// Check for build-ins
	if (strncmp("PLAY ", command, 5) == 0)
	{
		PlaySound(command + 5, NULL, SND_ASYNC | SND_FILENAME | SND_NODEFAULT);
		return;
	}
	else if (strncmp("PLAYSTOP", command, 8) == 0)
	{
		PlaySound(NULL, NULL, SND_PURGE);
		return;
	}
	else if (strncmp("PLAYLOOP ", command, 9) == 0)
	{
		PlaySound(command + 9, NULL, SND_ASYNC | SND_FILENAME | SND_LOOP | SND_NODEFAULT);
		return;
	}
	
	// Run the command
	if(command[0] == '!' && m_Rainmeter->GetDummyLitestep())
	{
		// Mimic WM_COPY to deliver bangs
		COPYDATASTRUCT CopyDataStruct;
		CopyDataStruct.cbData = strlen(command) + 1;
		CopyDataStruct.dwData = 1;
		CopyDataStruct.lpData = (void*)command;
		OnCopyData(NULL, (LPARAM)&CopyDataStruct);
	}
	else
	{
		// This can run bangs also
		LSExecute(NULL, command, SW_SHOWNORMAL);
	}
}

/*
** OnLeftButtonDown
**
** Runs the action when left mouse button is down
**
*/
LRESULT CMeterWindow::OnLeftButtonDown(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCLBUTTONDOWN)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	if(!DoAction(x, y, MOUSE_LMB_DOWN, false))
	{
		// Run the DefWindowProc so the dragging works
		return DefWindowProc(m_Window, m_Message, wParam, lParam);
	}

	return 0;
}

/*
** OnLeftButtonUp
**
** Runs the action when left mouse button is up
**
*/
LRESULT CMeterWindow::OnLeftButtonUp(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCLBUTTONUP)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	DoAction(x, y, MOUSE_LMB_UP, false);

	return 0;
}

/*
** OnRightButtonDown
**
** Runs the action when right mouse button is down
**
*/
LRESULT CMeterWindow::OnRightButtonDown(WPARAM wParam, LPARAM lParam) 
{
	int x = LOWORD(lParam); 
	int y = HIWORD(lParam); 

	if (m_Message == WM_NCRBUTTONDOWN)
	{
		// Transform the point to client rect
		RECT rect;
		GetWindowRect(m_Window, &rect);
		x = x - rect.left;
		y = y - rect.top;
	}

	DoAction(x, y, MOUSE_RMB_DOWN, false);

	return 0;
}

/*
** OnRightButtonUp
**
** Runs the action when right mouse button is up
**
*/
LRESULT CMeterWindow::OnRightButtonUp(WPARAM wParam, LPARAM lParam) 
{
	if (!DoAction(LOWORD(lParam), HIWORD(lParam), MOUSE_RMB_UP, false))
	{
		// Run the DefWindowProc so the contextmenu works
		return DefWindowProc(m_Window, WM_RBUTTONUP, wParam, lParam);
	}

	return 0;
}

/*
** OnContextMenu
**
** Handles the context menu. The menu is recreated every time it is shown.
**
*/
LRESULT CMeterWindow::OnContextMenu(WPARAM wParam, LPARAM lParam) 
{
	int xPos = (short int)LOWORD(lParam); 
	int yPos = (short int)HIWORD(lParam); 

	// Transform the point to client rect
	int x = (INT)(SHORT)LOWORD(lParam); 
	int y = (INT)(SHORT)HIWORD(lParam); 
	RECT rect;
	GetWindowRect(m_Window, &rect);
	x = x - rect.left;
	y = y - rect.top;

	// If RMB up or RMB down cause actions, do not show the menu!
	if (DoAction(x, y, MOUSE_RMB_UP, false) || DoAction(x, y, MOUSE_RMB_DOWN, true))
	{
		return 0;
	}

	// Show context menu, if no actions were executed
	HMENU menu = LoadMenu(m_Instance, MAKEINTRESOURCE(IDR_CONTEXT_MENU));

	if(menu)
	{
		HMENU subMenu = GetSubMenu(menu, 0);
		if(subMenu)
		{
			if(!m_Rainmeter->GetDummyLitestep())
			{
				// Disable Quit if ran as a Litestep plugin
				EnableMenuItem(subMenu, ID_CONTEXT_QUIT, MF_BYCOMMAND | MF_GRAYED);
			}
			if(m_ConfigStrings.size() > 0)
			{
				int index = 0;

				// Fill the menu with all the configs
				HMENU configMenu = CreatePopupMenu();
				if(configMenu)
				{
					InsertMenu(subMenu, 1, MF_BYPOSITION | MF_POPUP, (UINT_PTR)configMenu, "Configs");

					for(int i = 0; i < m_ConfigStrings.size(); i++)
					{
						if (m_ConfigStrings[i].iniFiles.size() > 1)
						{
							HMENU iniMenu = CreatePopupMenu();
							InsertMenu(configMenu, i, MF_BYPOSITION | MF_POPUP, (UINT_PTR)iniMenu, m_ConfigStrings[i].path.c_str());
							for(int j = 0; j < m_ConfigStrings[i].iniFiles.size(); j++)
							{
								std::string iniName = m_ConfigStrings[i].iniFiles[j].c_str();
								iniName.erase(iniName.end() - 4, iniName.end());
								InsertMenu(iniMenu, j, MF_BYPOSITION, ID_CONFIG_FIRST + index++, iniName.c_str());

								if(m_ConfigStrings[i].path == m_SkinName && m_ConfigStrings[i].iniFiles[j] == m_SkinIniFile)
								{
									CheckMenuItem(iniMenu, j, MF_BYPOSITION | MF_CHECKED);
								}
							}
						}
						else
						{
							InsertMenu(configMenu, i, MF_BYPOSITION, ID_CONFIG_FIRST + index++, m_ConfigStrings[i].path.c_str());

							if(m_ConfigStrings[i].path == m_SkinName)
							{
								CheckMenuItem(configMenu, i, MF_BYPOSITION | MF_CHECKED);
							}
						}
					}
				}
			}

			TrackPopupMenu(
			  subMenu,
			  TPM_RIGHTBUTTON | TPM_LEFTALIGN, 
			  xPos,
			  yPos,
			  0,
			  m_Window,
			  NULL
			);		
		}

		DestroyMenu(menu);
	}

	return 0;
}

/*
** DoAction
**
** Executes the action if such are defined. Returns true, if action was executed.
** If the test is true, the action is not executed.
**
*/
bool CMeterWindow::DoAction(int x, int y, MOUSE mouse, bool test) 
{
	// Check if the hitpoint was over some meter
	std::list<CMeter*>::iterator j = m_Meters.begin();
	for( ; j != m_Meters.end(); j++)
	{
		// Hidden meters are ignored
		if ((*j)->IsHidden()) continue;

		if (x >= (*j)->GetX() && x <= (*j)->GetX() + (*j)->GetW() &&
			y >= (*j)->GetY() && y <= (*j)->GetY() + (*j)->GetH())
		{
			switch (mouse)
			{
			case MOUSE_LMB_DOWN:
				if (!((*j)->GetLeftMouseDownAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetLeftMouseDownAction().c_str());
					return true;
				}
				break;

			case MOUSE_LMB_UP:
				if (!((*j)->GetLeftMouseUpAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetLeftMouseUpAction().c_str());
					return true;
				}
				break;

			case MOUSE_RMB_DOWN:
				if (!((*j)->GetRightMouseDownAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetRightMouseDownAction().c_str());
					return true;
				}
				break;

			case MOUSE_RMB_UP:
				if (!((*j)->GetRightMouseUpAction().empty()))
				{
					if (!test) ExecuteCommand((*j)->GetRightMouseUpAction().c_str());
					return true;
				}
				break;
			}
		}
	}

	// If no meters caused actions, do the default actions
	switch (mouse)
	{
	case MOUSE_LMB_DOWN:
		if (!m_LeftMouseDownAction.empty())
		{
			if (!test) ExecuteCommand(m_LeftMouseDownAction.c_str());
			return true;
		}
		break;

	case MOUSE_LMB_UP:
		if (!m_LeftMouseUpAction.empty())
		{
			if (!test) ExecuteCommand(m_LeftMouseUpAction.c_str());
			return true;
		}
		break;

	case MOUSE_RMB_DOWN:
		if (!m_RightMouseDownAction.empty())
		{
			if (!test) ExecuteCommand(m_RightMouseDownAction.c_str());
			return true;
		}
		break;

	case MOUSE_RMB_UP:
		if (!m_RightMouseUpAction.empty())
		{
			if (!test) ExecuteCommand(m_RightMouseUpAction.c_str());
			return true;
		}
		break;
	}

	return false;
}


/*
** OnMove
**
** Stores the new place of the window so that it can be written in the config file.
**
*/
LRESULT CMeterWindow::OnMove(WPARAM wParam, LPARAM lParam) 
{
	// Store the new window position
	m_WindowX = (short int)LOWORD(lParam);
	m_WindowY = (short int)HIWORD(lParam);

	return 0;
}

/* 
** WndProc
**
** The window procedure for the Meter
**
*/
LRESULT CALLBACK CMeterWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static CMeterWindow* Window = NULL;

	if (Window) Window->m_Message = uMsg;

	if(uMsg == WM_CREATE) 
	{
		// Fetch this window-object from the CreateStruct
		Window=(CMeterWindow*)((LPCREATESTRUCT)lParam)->lpCreateParams;
	}

	BEGIN_MESSAGEPROC
	MESSAGE(OnPaint, WM_PAINT)
	MESSAGE(OnMove, WM_MOVE)
	MESSAGE(OnCreate, WM_CREATE)
	MESSAGE(OnDestroy, WM_DESTROY)
	MESSAGE(OnTimer, WM_TIMER)
	MESSAGE(OnCommand, WM_COMMAND)
	MESSAGE(OnNcHitTest, WM_NCHITTEST)
	MESSAGE(OnMouseMove, WM_MOUSEMOVE)
	MESSAGE(OnMouseMove, WM_NCMOUSEMOVE)
	MESSAGE(OnContextMenu, WM_CONTEXTMENU)
	MESSAGE(OnRightButtonDown, WM_NCRBUTTONDOWN)
	MESSAGE(OnRightButtonDown, WM_RBUTTONDOWN)
	MESSAGE(OnRightButtonUp, WM_RBUTTONUP)
	MESSAGE(OnContextMenu, WM_NCRBUTTONUP)
	MESSAGE(OnLeftButtonDown, WM_NCLBUTTONDOWN)
	MESSAGE(OnLeftButtonDown, WM_LBUTTONDOWN)
	MESSAGE(OnLeftButtonUp, WM_LBUTTONUP)
	MESSAGE(OnLeftButtonUp, WM_NCLBUTTONUP)
	MESSAGE(OnWindowPosChanging, WM_WINDOWPOSCHANGING)
	MESSAGE(OnGetRevID, LM_GETREVID)
	MESSAGE(OnCopyData, WM_COPYDATA)
	END_MESSAGEPROC
}

/*
** IsNT
**
** Checks which OS you are running
**
*/
PLATFORM CMeterWindow::IsNT()
{
	// Check if you are running a real OS

	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	if(!GetVersionEx((OSVERSIONINFO*)&osvi))
	{
		// Something's wrong, lets assime Win9x
		return PLATFORM_9X;
	}

	if(osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// You got NT
		if(osvi.dwMajorVersion <= 4) return PLATFORM_NT4;
		if(osvi.dwMajorVersion == 5) return PLATFORM_2K;
		return PLATFORM_XP;
	}
	
	return PLATFORM_9X;	// Wintendo alert!
}

/*
** OnCopyData
**
** Handles bangs from the exe
**
*/
LRESULT CMeterWindow::OnCopyData(WPARAM wParam, LPARAM lParam)
{
	COPYDATASTRUCT* pCopyDataStruct = (COPYDATASTRUCT*) lParam;

	if (pCopyDataStruct && (pCopyDataStruct->dwData == 1) && (pCopyDataStruct->cbData > 0))
	{
		if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterRefresh", 17) == 0)
		{
			// This one takes arguments
			if (strlen((const char*)pCopyDataStruct->lpData) > 18)
			{
				RainmeterRefresh(m_Window, (const char*)pCopyDataStruct->lpData + 18);
			}
			else
			{
				RainmeterRefresh(m_Window, NULL);
			}
		}
		else if (stricmp((const char*)pCopyDataStruct->lpData, "!RainmeterRedraw") == 0)
		{
			RainmeterRedraw(m_Window, NULL);
		}
		else if (stricmp((const char*)pCopyDataStruct->lpData, "!RainmeterHide") == 0)
		{
			RainmeterHide(m_Window, NULL);
		}
		else if (stricmp((const char*)pCopyDataStruct->lpData, "!RainmeterShow") == 0)
		{
			RainmeterShow(m_Window, NULL);
		}
		else if (stricmp((const char*)pCopyDataStruct->lpData, "!RainmeterToggle") == 0)
		{
			RainmeterToggle(m_Window, NULL);
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterHideMeter", 19) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 20)
			{
				RainmeterHideMeter(m_Window, (const char*)pCopyDataStruct->lpData + 20);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterShowMeter", 19) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 20)
			{
				RainmeterShowMeter(m_Window, (const char*)pCopyDataStruct->lpData + 20);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterToggleMeter", 21) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 22)
			{
				RainmeterToggleMeter(m_Window, (const char*)pCopyDataStruct->lpData + 22);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterDisableMeasure", 24) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 25)
			{
				RainmeterDisableMeasure(m_Window, (const char*)pCopyDataStruct->lpData + 25);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterEnableMeasure", 23) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 24)
			{
				RainmeterEnableMeasure(m_Window, (const char*)pCopyDataStruct->lpData + 24);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterToggleMeasure", 23) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 24)
			{
				RainmeterToggleMeasure(m_Window, (const char*)pCopyDataStruct->lpData + 24);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterChangeConfig", 22) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 23)
			{
				RainmeterChangeConfig(m_Window, (const char*)pCopyDataStruct->lpData + 23);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterMove", 14) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 15)
			{
				RainmeterMove(m_Window, (const char*)pCopyDataStruct->lpData + 15);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterChangeZPos", 20) == 0)
		{
			if (strlen((const char*)pCopyDataStruct->lpData) > 21)
			{
				RainmeterZPos(m_Window, (const char*)pCopyDataStruct->lpData + 21);
			}
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterAbout", 15) == 0)
		{
			RainmeterAbout(m_Window, NULL);
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!RainmeterLsBoxHook", 19) == 0)
		{
			// Do nothing
		}
		else if (strnicmp((const char*)pCopyDataStruct->lpData, "!Execute", 8) == 0)
		{
			// Special case for multibang execution
			std::string allCommands = ((const char*)pCopyDataStruct->lpData) + 8;
			
			while (true)
			{
				std::string::size_type start = allCommands.find('[');
				std::string::size_type end = allCommands.find(']');
				if (start != -1 && end != -1)
				{
					std::string command = allCommands.substr(start + 1, end - (start + 1));
					// trim leading whitespace
					std::string::size_type notwhite = command.find_first_not_of(" \t\n");
					command.erase(0, notwhite);
					ExecuteCommand(command.c_str());
				}
				else
				{
					break;	// No more commands
				}
				allCommands = allCommands.substr(end + 1);
			}
		}
		else
		{
			std::string error = "Unknown !bang: ";
			error += (const char*)pCopyDataStruct->lpData;
			MessageBox(m_Window, error.c_str(), "Rainmeter", MB_OK);
			return FALSE;
		}
	}
	else
	{
		return FALSE;
	}
	
	return TRUE;
}
