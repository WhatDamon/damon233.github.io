//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Plugin.rc
//
#define IDR_CONTEXT_MENU                101
#define IDD_ABOUT_DIALOG                102
#define IDC_STATISTICS                  1000
#define IDC_BUILD_STRING                1001
#define IDC_VERSION_STRING              1002
#define IDC_STATISTICS_STRING           1003
#define ID_CONFIG_FIRST                 30000
#define ID_CONTEXT_REFRESH              40001
#define ID_CONTEXT_QUIT                 40002
#define ID_CONTEXT_ABOUT                40004
#define ID_CONTEXT_CONFIGS_DEFAULT      40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
