/*
  Copyright (C) 2002 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  $Header: //rainbox\\cvsroot/Rainmeter/PowerPlugin/PowerPlugin.cpp,v 1.1 2002/09/07 08:17:11 rainy Exp $

  $Log: PowerPlugin.cpp,v $
  Revision 1.1  2002/09/07 08:17:11  rainy
  Intial version

*/

#pragma warning(disable: 4786)

#include <windows.h>
#include <math.h>
#include <map>

/* The exported functions */
extern "C"
{
__declspec( dllexport ) UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id);
__declspec( dllexport ) void Finalize(HMODULE instance, UINT id);
__declspec( dllexport ) UINT Update(UINT id);
}

enum POWER_STATE
{
	POWER_UNKNOWN,
	POWER_ACLINE,
	POWER_STATUS,
	POWER_LIFETIME,
	POWER_PERCENT
};

std::map<UINT, POWER_STATE> g_States;

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	char tmpSz[4096];
	POWER_STATE state = POWER_UNKNOWN;

	/* Read our own settings from the ini-file */
	if(GetPrivateProfileString(section, "PowerState", "", tmpSz, 255, iniFile) > 0) 
	{
		if (stricmp("ACLINE", tmpSz) == 0)
		{
			state = POWER_ACLINE;
		} 
		else if (stricmp("STATUS", tmpSz) == 0)
		{
			state = POWER_STATUS;
		} 
		else if (stricmp("LIFETIME", tmpSz) == 0)
		{
			state= POWER_LIFETIME;
		} 
		else if (stricmp("PERCENT", tmpSz) == 0)
		{
			state = POWER_PERCENT;
		}

		g_States[id] = state;
	}

	switch(state)
	{
	case POWER_ACLINE:
		return 1;

	case POWER_STATUS:
		return 100;

	case POWER_LIFETIME:
		{
			SYSTEM_POWER_STATUS status;
			if (GetSystemPowerStatus(&status))
			{
				return status.BatteryFullLifeTime;
			}
		}
		break;

	case POWER_PERCENT:
		return 100;
	}

	return 0;
}

/*
  This function is called when new value should be measured.
  The function returns the new value.
*/
UINT Update(UINT id)
{
	SYSTEM_POWER_STATUS status;
	if (GetSystemPowerStatus(&status))
	{
		std::map<UINT, POWER_STATE>::iterator i = g_States.find(id);
		if (i != g_States.end())
		{
			switch((*i).second)
			{
			case POWER_ACLINE:
				return status.ACLineStatus == 1 ? 1 : 0;

			case POWER_STATUS:
				if (status.BatteryFlag & 128)
				{
					return 0;	// No battery
				}
				else if (status.BatteryFlag & 8)
				{
					return 1;	// Charging
				}
				else if (status.BatteryFlag & 4)
				{
					return 2;	// Critical
				}
				else if (status.BatteryFlag & 2)
				{
					return 3;	// Low
				}
				else if (status.BatteryFlag & 1)
				{
					return 4;	// High
				}
				break;

			case POWER_LIFETIME:
				return status.BatteryLifeTime;

			case POWER_PERCENT:
				return status.BatteryLifePercent > 100 ? 100 : status.BatteryLifePercent;
			}
		}
	}

	return 0;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	std::map<UINT, POWER_STATE>::iterator i = g_States.find(id);
	if (i != g_States.end())
	{
		g_States.erase(i);
	}
}
