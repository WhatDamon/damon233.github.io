/*
  $Header: //rainbox/cvsroot/Rainmeter/SysInfo/SysInfo.cpp,v 1.2 2002/12/23 14:24:46 rainy Exp $

  $Log: SysInfo.cpp,v $
  Revision 1.2  2002/12/23 14:24:46  rainy
  Added secondary dns server return value.

  Revision 1.1  2002/07/01 15:36:03  rainy
  Intial version

*/

#pragma warning(disable: 4786)

#include <windows.h>
#include <math.h>
#include <string>
#include <map>
#include <Ras.h>
#include <Iphlpapi.h>

/* The exported functions */
extern "C"
{
__declspec( dllexport ) UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id);
__declspec( dllexport ) LPCTSTR GetString(UINT id, UINT flags);
__declspec( dllexport ) void Finalize(HMODULE instance, UINT id);
}

BOOL CheckConnection();
void GetOSVersion(char* buffer);

enum TYPE
{
	COMPUTER_NAME,
	USER_NAME,
	WORK_AREA,
	SCREEN_SIZE,
	RAS_STATUS,
	OS_VERSION,
	ADAPTER_DESCRIPTION,
	NET_MASK,
	IP_ADDRESS,
	GATEWAY_ADDRESS,
	HOST_NAME,
	DOMAIN_NAME,
	DNS_SERVER,
};

static std::map<UINT, TYPE> g_Types;
static std::map<UINT, UINT> g_Datas;

/*
  This function is called when the measure is initialized.
  The function must return the maximum value that can be measured. 
  The return value can also be 0, which means that Rainmeter will
  track the maximum value automatically. The parameters for this
  function are:

  instance  The instance of this DLL
  iniFile   The name of the ini-file (usually Rainmeter.ini)
  section   The name of the section in the ini-file for this measure
  id        The identifier for the measure. This is used to identify the measures that use the same plugin.
*/
UINT Initialize(HMODULE instance, LPCTSTR iniFile, LPCTSTR section, UINT id)
{
	char tmpSz[4096];

	/* Read our own settings from the ini-file */
	if(GetPrivateProfileString(section, "SysInfoType", "", tmpSz, 255, iniFile) > 0) 
	{
		if (stricmp("COMPUTER_NAME", tmpSz) == 0)
		{
			g_Types[id] = COMPUTER_NAME;
		} 
		else if (stricmp("USER_NAME", tmpSz) == 0)
		{
			g_Types[id] = USER_NAME;
		} 
		else if (stricmp("WORK_AREA", tmpSz) == 0)
		{
			g_Types[id] = WORK_AREA;
		} 
		else if (stricmp("SCREEN_SIZE", tmpSz) == 0)
		{
			g_Types[id] = SCREEN_SIZE;
		} 
		else if (stricmp("RAS_STATUS", tmpSz) == 0)
		{
			g_Types[id] = RAS_STATUS;
		} 
		else if (stricmp("OS_VERSION", tmpSz) == 0)
		{
			g_Types[id] = OS_VERSION;
		} 
		else if (stricmp("ADAPTER_DESCRIPTION", tmpSz) == 0)
		{
			g_Types[id] = ADAPTER_DESCRIPTION;
		} 
		else if (stricmp("NET_MASK", tmpSz) == 0)
		{
			g_Types[id] = NET_MASK;
		} 
		else if (stricmp("IP_ADDRESS", tmpSz) == 0)
		{
			g_Types[id] = IP_ADDRESS;
		} 
		else if (stricmp("GATEWAY_ADDRESS", tmpSz) == 0)
		{
			g_Types[id] = GATEWAY_ADDRESS;
		} 
		else if (stricmp("HOST_NAME", tmpSz) == 0)
		{
			g_Types[id] = HOST_NAME;
		} 
		else if (stricmp("DOMAIN_NAME", tmpSz) == 0)
		{
			g_Types[id] = DOMAIN_NAME;
		} 
		else if (stricmp("DNS_SERVER", tmpSz) == 0)
		{
			g_Types[id] = DNS_SERVER;
		} 
		else
		{
			std::string error = "No such SysInfoType: ";
			error += tmpSz;
			MessageBox(NULL, error.c_str(), "Rainmeter", MB_OK);
		}
	}

	g_Datas[id] = GetPrivateProfileInt(section, "SysInfoData", 0, iniFile);

	return 0;
}

/*
  This function is called when the value should be
  returned as a string.
*/
LPCTSTR GetString(UINT id, UINT flags) 
{
	static char buffer[4096];
	UINT data;
	DWORD len = 4095;
	std::map<UINT, TYPE>::iterator typeIter = g_Types.find(id);
	std::map<UINT, UINT>::iterator dataIter = g_Datas.find(id);

	if(typeIter == g_Types.end()) return NULL;
	if(dataIter == g_Datas.end())
	{
		data = 0;
	}
	else
	{
		data = (*dataIter).second;
	}

	switch((*typeIter).second)
	{
	case COMPUTER_NAME:
		GetComputerName(buffer, &len);
		return buffer;

	case USER_NAME:
		GetUserName(buffer, &len);
		return buffer;

	case WORK_AREA:
		sprintf(buffer, "%i x %i", GetSystemMetrics(SM_CXFULLSCREEN), GetSystemMetrics(SM_CYFULLSCREEN));
		return buffer;

	case SCREEN_SIZE:
		sprintf(buffer, "%i x %i", GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
		return buffer;

	case RAS_STATUS:
		sprintf(buffer, "%s", CheckConnection()?"Online":"Offline");
		return buffer;

	case OS_VERSION:
		GetOSVersion(buffer);
		return buffer;

	case ADAPTER_DESCRIPTION:
		if (ERROR_SUCCESS == GetAdaptersInfo((IP_ADAPTER_INFO*)buffer, &len))
		{
			PIP_ADAPTER_INFO info = (IP_ADAPTER_INFO*)buffer;
			int i = 0;
			while (info)
			{
				if (i == data)
				{
					return info->Description;
				}
				info = info->Next;
				i++;
			}
		}
		break;

	case IP_ADDRESS:
		if (NO_ERROR == GetIpAddrTable((PMIB_IPADDRTABLE)buffer, &len, FALSE))
		{
			PMIB_IPADDRTABLE ipTable = (PMIB_IPADDRTABLE)buffer;
			if (data < ipTable->dwNumEntries)
			{
				DWORD ip = ipTable->table[data].dwAddr;
				sprintf(buffer, "%i.%i.%i.%i", ip%256, (ip>>8)%256, (ip>>16)%256, (ip>>24)%256);
				return buffer;
			}
		}
		break;

	case NET_MASK:
		if (NO_ERROR == GetIpAddrTable((PMIB_IPADDRTABLE)buffer, &len, FALSE))
		{
			PMIB_IPADDRTABLE ipTable = (PMIB_IPADDRTABLE)buffer;
			if (data < ipTable->dwNumEntries)
			{
				DWORD ip = ipTable->table[data].dwMask;
				sprintf(buffer, "%i.%i.%i.%i", ip%256, (ip>>8)%256, (ip>>16)%256, (ip>>24)%256);
				return buffer;
			}
		}
		break;

	case GATEWAY_ADDRESS:
		if (ERROR_SUCCESS == GetAdaptersInfo((IP_ADAPTER_INFO*)buffer, &len))
		{
			PIP_ADAPTER_INFO info = (IP_ADAPTER_INFO*)buffer;
			int i = 0;
			while (info)
			{
				if (i == data)
				{
					return info->GatewayList.IpAddress.String;
				}
				info = info->Next;
				i++;
			}
		}
		break;

	case HOST_NAME:
		if (ERROR_SUCCESS == GetNetworkParams((PFIXED_INFO)buffer, &len))
		{
			PFIXED_INFO info = (PFIXED_INFO)buffer;
			return info->HostName;
		}
		break;

	case DOMAIN_NAME:
		if (ERROR_SUCCESS == GetNetworkParams((PFIXED_INFO)buffer, &len))
		{
			PFIXED_INFO info = (PFIXED_INFO)buffer;
			return info->DomainName;
		}
		break;

	case DNS_SERVER:
		if (ERROR_SUCCESS == GetNetworkParams((PFIXED_INFO)buffer, &len))
		{
			PFIXED_INFO info = (PFIXED_INFO)buffer;
			if (info->CurrentDnsServer)
			{
				return info->CurrentDnsServer->IpAddress.String;
			}
			else
			{
				return info->DnsServerList.IpAddress.String;
			}
		}
		break;
	}

	return NULL;
}

/*
  If the measure needs to free resources before quitting.
  The plugin can export Finalize function, which is called
  when Rainmeter quits (or refreshes).
*/
void Finalize(HMODULE instance, UINT id)
{
	g_Types.clear();
	g_Datas.clear();
}

/*
  Fills the buffer with OS version
*/
void GetOSVersion(char* buffer)
{
	OSVERSIONINFO version;
	version.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&version);

	if (version.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		if (version.dwMajorVersion <= 4)
		{
			strcpy(buffer, "Windows NT");
		}
		else
		{
			if (version.dwMinorVersion >= 1)
			{
				strcpy(buffer, "Windows XP");
			}
			else
			{
				strcpy(buffer, "Windows 2000");
			}
		}
	}
	else
	{
		if (version.dwMinorVersion < 10)
		{
			strcpy(buffer, "Windows 95");
		}
		else if (version.dwMinorVersion < 90)
		{
			strcpy(buffer, "Windows 98");
		}
		else
		{
			strcpy(buffer, "Windows ME");
		}
	}
}


/*
  Tests if there is a RAS connection or not. Don't know
  If this works or not (especially on Win9x):-(
*/
BOOL CheckConnection()
{
	static HRASCONN g_hRasConn=NULL;
	RASCONNSTATUS rasStatus;
	LPRASCONN lpRasConn=NULL;
    DWORD cbBuf=0;
    DWORD cConn=1;
    DWORD dwRet=0;

	if(g_hRasConn==NULL) {
	    // Enumerate connections
		cbBuf=sizeof(RASCONN);
		if(((lpRasConn=(LPRASCONN)malloc((UINT)cbBuf))!= NULL)) {            
			lpRasConn->dwSize=sizeof(RASCONN);
			if(0==RasEnumConnections(lpRasConn, &cbBuf, &cConn)) {
				if(cConn!=0) {
					g_hRasConn=lpRasConn->hrasconn;
				}
			}
			free(lpRasConn);
		}
	}

	if(g_hRasConn!=NULL) {
		// get connection status
		rasStatus.dwSize=sizeof(RASCONNSTATUS);
		dwRet=RasGetConnectStatus(g_hRasConn, &rasStatus );
		if(dwRet==0) {
			// Check for connection
			if(rasStatus.rasconnstate==RASCS_Connected) return TRUE;
		} else {
			g_hRasConn=NULL;
		}
	}

    return FALSE;
}
